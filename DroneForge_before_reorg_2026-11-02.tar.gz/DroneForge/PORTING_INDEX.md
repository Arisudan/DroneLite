# DroneForge porting files (from NimbusOS 2.9.0)
Only what is needed to rebuild the Nimbus hardware and PC link. Original analysis lives in ~/nimbus-elrs-analysis.

- host/CRSF_LINK_SPEC.md   exact baud, termios, frame format, channel map, rate, failsafe, ESP32-S3 flash layout
- host/crsf_ref.py         reference encoder, `python3 -I crsf_ref.py <nimbus_core>` verifies the CRC table
- host/install-udev-rule.sh  udev rule for the ESP32-S3 (303a:1001) and STM32 (0483) devices
- firmware/elrs_tx_nimbus_esp32s3/  original TX images (bootloader, partitions, boot_app0, firmware)
- firmware/elrs_rx_drone/          original drone receiver image (ESP8285, DIY_2400_RX)
- firmware/betaflight_configs/     Betaflight CLI dumps: Air75 (G473 V2, two variants), Air75 (G473), Axis F7 AIO, LionBee V2
- reference_decompiled/   the relevant decompiled nimbus_core functions only
- firmware/elrs_tx_e28_drafts/   DRAFT ELRS layouts for your own build: ESP32 DevKit V1 or C3 Super Mini + Ebyte E28-2G4M27SX (replaces the T3-S3 plan, order cancelled); power capped, see README.md; PCB_REVIEW.md reviews your schematic; c3_supermini_pcb/BOARD_STATUS.md = your assembled board (chip checked, flash backed up); PROTOTYPE_PLAN.md = breadboard bring-up; E28-2G4M27SX_manual_facts.md = Ebyte manual facts (580 mA TX, 3.6 V max, 0 dBm drive = 27 dBm out)
- firmware/elrs_tx_t3s3_draft/   (reference only, order cancelled) DRAFT ELRS layout (hardware.json) for LilyGO T3-S3 SX1280 PA, 3 dBm cap, sources and open items in README_DRAFT.md; not built or flashed
- firmware/matek_h743_current/   your H743 FC config as read before any changes
- host/nimbus_pc/   PC side: CRSF sender, telemetry, commands/MSP, gamepad, watchdog, CLI, dongle emulator (Python, 66 tests passing; gamepad path tested on the real Boxer; never run on a real dongle). See its README.md
- firmware/betaflight_patch_0xD3/   Betaflight patch sketch that sends range+flow telemetry frame 0xD3 (host-verified only, not built as firmware; see README.md)
