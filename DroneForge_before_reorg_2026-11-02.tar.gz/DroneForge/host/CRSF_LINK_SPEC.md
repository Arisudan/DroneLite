# Nimbus PC → ELRS transmitter link (CRSF over USB-serial)

Source: NimbusOS 2.9.0 `nimbus_core` (x86-64, not stripped), decompiled with Ghidra 12.1.4.
Ghidra addresses = file vaddr + 0x100000 (PIE). Everything below was read from the binary,
not guessed, except where marked INFERRED.

## 1. Serial port (`SerialLinkConnection::ConnectByPathLocked`)

| Item | Value | Evidence |
|---|---|---|
| Baud | **115200**, the only value accepted (`param_2 == 0x1c200`) | `cfsetispeed/cfsetospeed(0x1002 = B115200)` |
| Framing | **8N1**, no flow control | `c_cflag = (old & 0x7ffff20f) \| 0x8b0` = CS8 \| CREAD \| CLOCAL; HUPCL and CRTSCTS cleared |
| Mode | raw (`cfmakeraw`) | |
| Read timing | `VMIN=0, VTIME=1` (100 ms) | c_cc[VMIN]=0, c_cc[VTIME]=1 |
| Open flags | `O_RDWR \| O_NOCTTY` (0x102) | |
| Before use | `tcflush(fd, TCIOFLUSH)`, then `ioctl(fd, TIOCMBIC, DTR\|RTS)` (0x5417, value 6), then `tcflow(fd, TCOON)` | |
| Device | Nimbus's port scanner (`SerialLinkConnection::ListPorts`) accepts `/dev/ttyUSB*` and `/dev/ttyACM*` from USB vendors **0x303a** (Espressif native USB) and **0x10c4** (Silicon Labs CP210x). Stock ELRS reads CRSF only from UART0 pins, so the real dongle most likely carries CRSF through a USB-UART bridge (10c4); native 303a is for flashing. INFERRED, not proven. | `install-udev-rule.sh` (303a rule is for flashing) |

Note: DTR and RTS are cleared on connect. On an ESP32-S3 USB-Serial-JTAG port, toggling
DTR/RTS can reset the chip into the bootloader, so do the same.

## 2. RC control frame (`CrsfTransmitEncoder::EncodeControlFrame`)

26 bytes, standard CRSF `RC_CHANNELS_PACKED`:

```
[0] 0xC8   sync / address (flight controller)
[1] 0x18   length = 24 (type + 22 payload + crc)
[2] 0x16   type RC_CHANNELS_PACKED
[3..24]    16 channels x 11 bits, little-endian bit-packed (22 bytes)
[25]       CRC-8, poly 0xD5 (DVB-S2), over bytes [2..24]
```

CRC table in the binary was verified equal to CRC-8 poly 0xD5. See `crsf_ref.py`.
Idle frame (sticks centred, throttle min, AUX at 172):
`c81816e0031f2bc0c70a56b0027ce0031ff8c0073ef0810f7c8a`

Wire time at 115200 8N1: 26 bytes x 10 bits = **2.26 ms** per frame.

## 3. Channel layout and values

Only 7 channels are driven by the software; **channels 8-16 are fixed at 992**.
Order is AETR (CrsfToThrottle01 reads the 3rd value, so channel 3 is throttle):

| Ch | Role | Notes |
|---|---|---|
| 1 | roll | stick or angle mapped |
| 2 | pitch | |
| 3 | throttle | `Throttle01ToCrsf` |
| 4 | yaw | |
| 5 | AUX1 (arm, INFERRED) | forced to 172 when not enabled or when the link/mode flag is off |
| 6 | AUX2 | |
| 7 | AUX3 | 172, or 1811 (0x713) when a flag is set |
| 8-16 | unused | 992 |

Mapping constants read from `.rodata`:

| Function | Formula |
|---|---|
| `StickToCrsf(s)` | clamp s to [-1, 1]; `round(s * 820 + 992)`, clamped to [172, 1811] |
| `Throttle01ToCrsf(t)` | clamp t to [0, 1]; `round(t * 1639 + 172)`, clamped to [172, 1811] |
| `CrsfToThrottle01(v)` | `(clamp(v, 172, 1811) - 172) / 1639` |
| `AngleDegToCrsf` | angle-to-stick curve (see `reference_decompiled/crsf_encoder_serial_mapper.c`), deadband 0.01, then the same stick mapping |

CRSF limits: min 172, mid 992, max 1811.

## 4. Frame rate (`SerialOutboundFrameLoop::Run`)

- A control frame is built and written **on every loop iteration**.
- Every iteration ends with: if `elapsed < 10 ms`, `nanosleep(10 ms - elapsed)`.
- So the loop is floored at 10 ms: **nominal 100 Hz** (one frame every 10 ms), lower only if an iteration takes longer than 10 ms.
- Not a fixed-rate scheduler: period = max(10 ms, work time), timed with a monotonic clock.

Other timed traffic from the same loop (same serial port):
- **Device ping** frames every **250 ms** (`EncodeDevicePingFrame`, called with 0xEE, 0xEC and 0xC8 as the destination argument and 0xEA as a fixed last argument; exact CRSF ping layout not yet reconstructed).
- Video-receiver scan / connect, bind and set-bind-UID frames, driven by commands from the UI.
- Several 0.5 s to 2.5 s watchdog timers (link statistics gap and reconnect logic).

## 5. Sensor failsafe (`OptrangeFailsafe::Update`, decompiled in full) — CORRECTED

An earlier version of this file said the loop zeroes throttle when the *control stream* has missing frames.
That was wrong. The rule watches the drone's **range/optical-flow telemetry** (`OptrangeData`, 28 bytes), not the RC frames:

| Rule | Value |
|---|---|
| Active only while | the vehicle is armed/active (leaving that state resets the watchdog) |
| Engages when | throttle >= **0.05** (5%), engage time recorded |
| `missing-frames` | no new sensor sample for >= **0.5 s** (from the last sample, or from engage time if none yet) |
| `payload-flatline` | a new sample byte-identical to the previous one, with no change for >= **0.5 s** |
| On trip | prints `<missing-frames|payload-flatline> throttle=zero`, latches, and forces the throttle channel to **172** |
| Reset | only when the vehicle is disarmed/deactivated |

The sensor data arrives in custom CRSF telemetry frame **0xD3** (see 5c). `OptrangeData` = 7 floats: distance, strength,
precision, velocity_forward, velocity_right, flow_quality, flow_status (+ receive timestamp). The flat-line test compares those.

## 5b. Device ping (`EncodeDevicePingFrame`)

`EE 04 28 <destination> <origin> CRC` (6 bytes, sync always 0xEE, CRC over type+dest+origin).
The loop pings destinations 0xEE (TX module), 0xEC (receiver) and 0xC8 (flight controller) with origin 0xEA,
every 250 ms, gated by internal state flags that are only partly decoded. `nimbus_pc` pings each target
every 250 ms until a DEVICE_INFO (0x29) reply arrives from it, which is an approximation of that gating.

## 5c. Custom telemetry frames (type 0xD0-0xE4), from `crsf::utils::DecodeTelemetryPayload`

Stock Betaflight master has none of these (its CRSF telemetry frames are vario, battery, baro, attitude, flight mode,
GPS, magnetometer, accel/gyro, device info, MSP-over-CRSF, heartbeat, GPS time). They come from Nimbus's custom firmware.

**0xD3 = range + optical flow (`OptrangeData`)** — payload 10 bytes, confirmed by tracing it into the telemetry message
(offset 0x1d0, timestamp 0x1f0, which is exactly what `OptrangeFailsafe` and the app schema use):

| Bytes | Field | Decoding |
|---|---|---|
| 0-1 | distance | int16 big-endian, millimetres; valid only for raw 1..5999, else 0; /1000 -> metres (matches the MTF-02P 6 m range) |
| 2 | dist_strength | u8 |
| 3 | dist_precision | u8 |
| 4-5 | flow_x | int16 big-endian (byte order inferred from vectorised code), /100 |
| 6-7 | flow_y | int16 big-endian (same), /100 |
| 8 | flow_quality | u8 |
| 9 | flow_status | u8 |

Derived: velocity_forward = distance_m * flow_x/100; velocity_right = -distance_m * flow_y/100 (the minus sign is inferred
from a sign-mask constant I did not read).

Custom frame identification (joined from decoder payload sizes, the normalizer's telemetry-message slots, the app's
FlatBuffers schema and Nimbus's own log strings). Confidence: CONFIRMED = a log string or the schema names it and the layout is
read from the binary; PROBABLE = matched by payload size and schema field list only; NOT DECODED = layout unknown.

| Type | Payload | Telemetry message | Layout / status |
|---|---|---|---|
| 0xD0 | 4 | rangefinder | u16 BE distance in cm (/100 -> m), u16 BE strength. CONFIRMED (scale read from binary) |
| 0xD1 | 12 | rawImu | 6 x int16 BE: gyro xyz, accel xyz. Scaling gyro = raw/100*180/pi, accel = raw/100 read from vectorised code: UNVERIFIED |
| 0xD2 | 13 valid / 4 invalid | mightyCam | 13-byte form = u8 + 4 x (u8, u16); 4-byte form = invalid. Quantised pose, scaling not recovered: NOT DECODED |
| 0xD3 | 10 | optrange | see above. CONFIRMED |
| 0xD4 | 18 | motorRpm (probable) | 4 x u32 + u16, probably motor PWM x4 + pole count: PROBABLE, not decoded |
| 0xD5 | 16 | motorRpm (probable) | 4 x u32, probably eRPM x4: PROBABLE, not decoded |
| 0xE1 | 48 | videoReceiverTopChannels | raw copy; 48 = 6 bands x 8 channels, treated as 48 RSSI bytes in frequency order. Frame CONFIRMED by log string, layout INFERRED |
| 0xE2 | 1 | droneLinked | non-zero = drone linked. CONFIRMED (log string) |
| 0xE3 | 12 | flightControllerUid | three u32 (little-endian inferred). CONFIRMED (log string) |
| 0xE4 | 6 | (none found) | u32 + u16, no telemetry-message slot found: NOT IDENTIFIED |

Standard types: 0x12 magnetometer = 3 x int16 BE / 3.0 (CONFIRMED scale); 0x09 baro = u16 altitude (MSB set: metres, else
(raw-10000)/10 m) + 1 vario byte with the usual exponential encoding (constant 0.026; exact formula not fully recovered);
0x02 GPS, 0x08 battery, 0x14 link statistics, 0x1E attitude, 0x21 flight mode, 0x29 device info as in the public CRSF definitions.

0xD6-0xE0 are accepted and ignored. Standard types also decoded: 0x02 GPS, 0x08 battery, 0x09 baro, 0x12, 0x14 link stats,
0x1E attitude, 0x21 flight mode, 0x29 device info.

Consequence for a replica: the drone must send 0xD3. Stock Betaflight 4.5.4 / master do not, so a replica needs a
small custom patch to Betaflight's CRSF telemetry (GPL), or another source of range/flow data on the PC.

## 5d. Command and MSP frames sent by the PC (disassembled)

Command frame (frame type 0x32), `EncodeCommandFrame`: `EE <len=n+7> 32 EE EA <command> <sub> <payload n> 00 <CRC>`.
The byte before the CRC is the command-CRC slot, always 0 in NimbusOS; the frame CRC (poly 0xD5) covers it.

| Function | Command | Sub | Payload |
|---|---|---|---|
| EncodeReceiverBindFrame | 0x10 | 0x01 | none (frame `ee0732eeea10010047`) |
| EncodeSetBindUidFrame | 0x80 | 0x42 | 6-byte UID |
| EncodeVideoReceiverScanFrame | 0x80 | 0x40 | `01` |
| EncodeVideoReceiverConnectFrame | 0x80 | 0x41 | band code, channel (band code = index*8 for A B E F R L, channel 1..8) |

MSP request (`EncodeMspRequestFrame`, 13 bytes): `C8 0B 7A C8 EA 50 00 <cmd> 00 00 00 <xor> <crc>`; status 0x50 = MSPv2, start
flag, sequence 0; `<xor>` is the XOR of the five MSPv2 header bytes (not a CRC). Used with cmd 0x04 (MSP_BOARD_INFO) and
0x58 (MSP_VTX_CONFIG).

**Set VTX channel/power** (`EncodeMspSetVtxConfigPowerFrames`, fully decoded): MSP_SET_VTX_CONFIG (0x59) written to the FC as
chunked MSP-write frames (type 0x7C).
- Inputs validated as: band code a multiple of 8 below 48 (A B E F R L), channel 1..8, power level non-zero.
- MSPv2 body, 10 bytes: `00 | 59 00 | 04 00 | <u16 LE: band_code + channel - 1> <power level u8> 00 | <xor of the previous 9 bytes>`.
- Cut into chunks of at most 7 bytes; each chunk is `C8 <n+5> 7C C8 EA <status> <chunk> <CRC>`, status = 0x40 (MSPv2) | 0x10 (first
  chunk only) | sequence (0, 1, ... mod 16). The body therefore always goes out as two frames (7 + 3 bytes).
- Example, band F channel 4 power level 2: `c80c7cc8ea5000590004001b0006` then `c8087cc8ea41020044d7`.
- Betaflight's `MSP_SET_VTX_CONFIG` (src/main/msp/msp.c) reads the u16 as band = v/8 + 1, channel = v%8 + 1 when v <= 63, then power
  (0..max levels) and pit mode, matching the 4-byte payload above. The power value is the **1-based power-level index of the drone's
  VTX table, not milliwatts**.
- The reply layout of MSP_VTX_CONFIG (0x58) is Betaflight's: type, band, channel, power, pit mode, u16 freq (LE), device ready,
  low-power-disarm, u16 pit-mode freq, table available, bands, channels, power levels.
- NOT implemented: Nimbus also contains `ResolveVideoReceiverChannelForVtxConfig` and per-board frequency tables (HGLRC Zeus 800 mW,
  BetaFPV V2), which most likely translate a video-receiver channel into the channel of that drone's own VTX table. That mapping is
  not decoded, so `band`/`channel` here are written exactly as given, and may not be the channel you expect on a VTX whose table
  differs from the standard A/B/E/F/R/L layout.
- Nimbus's function does not save settings (no EEPROM write follows in this code path).


MSP response (type 0x7B): payload = dest, origin, status, data. Status bit4 = start chunk, bits5-6 must be 0x40 (MSPv2),
bits0-3 = sequence. Start chunk carries flag, cmd(2), size(2); a response is complete at size + 8 bytes (dest, origin,
status and header included); continuation chunks must arrive in sequence (`TryBuildCompleteMspResponse`).

## 6. Receive side

`TelemetryIngestLoop` reads the same port with `CrsfFrameParser` (byte-wise, sync + length + CRC),
decodes CRSF telemetry (link statistics `elrs_link.*` with RSSI and link quality, plus battery, attitude and flight mode, with the exact field set not itemized here)
and CRSF device info, and reassembles MSP responses carried in CRSF frames.

## 7. ELRS transmitter flash layout (ESP32-S3, 8 MB, DIO, 80 MHz)

From `partitions.bin` and the image headers:

| Offset | File |
|---|---|
| 0x0 | bootloader.bin |
| 0x8000 | partitions.bin |
| 0xe000 | boot_app0.bin (blank otadata) |
| 0x10000 | firmware.bin (app0, 0x1e0000) |
| 0x1f0000 | app1 (0x1e0000) |
| 0x3d0000 | spiffs (0x20000), where ELRS keeps `hardware.json` and options |
| 0x9000 | nvs (0x5000) |

Firmware identity: ExpressLRS target `Unified_ESP32S3_2400_TX_via_UART`, ESP-IDF 4.4.5.
Product name `DIY ESP32-S3 Nimbus 2.4Ghz TX`, Lua name `Nimbus S3 LoRa`,
options `{"flash-discriminator": 3077385695, "wifi-on-interval": 60, "domain": 0}`.
Radio chip SX128X (2.4 GHz). The pin layout (`hardware.json`) is NOT in the package.

## 8. Not determined

- The TX `hardware.json` (SX1280 and ESP32-S3 pin wiring).
- The exact ELRS version (no version string in the binary).
- The exact meaning of channels 5-7 (names inferred from layout only).
- Whether the video receiver is controlled over this same CRSF link (frames exist for it: `EncodeVideoReceiverScanFrame`, `EncodeVideoReceiverConnectFrame`).
