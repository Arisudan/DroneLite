# MicoAir MTF-02P — what the raw UART stream looks like (measured, 2026-10-31)

Read through Betaflight `serialpassthrough 2 115200` (FC UART3 -> USB), 38 s, 3802 frames.

- Link: 115200 baud, frames at about 100 Hz (3802 frames / 38.0 s).
- Frame (vendor "Micolink" style, 100% checksum-valid): `EF dev sys msgid seq len payload[len] sum`,
  where `sum` = low byte of the sum of all preceding bytes.
- Only msgid 0x51 seen, always payload len 20. NO MSP v2 frames ("$X") and no separate 0x52 frames.
- Payload layout (distance part CONFIRMED by behaviour; flow part INFERRED, fits the data):
  `time_ms u32 | distance_mm u32 | strength u8 | precision u8 | tof_status u8 | rsv u8 |
   flow_x i16 | flow_y i16 | flow_quality u8 | flow_status u8 | rsv u16`
- Observed: strength always 255, tof_status 1, distance 44..449 mm, flow quality 30-34 when close (~5 cm)
  and 59-69 at 15-45 cm, flow x/y exactly 0 while the sensor was static or too close, non-zero when moved.
- Betaflight's lidar driver treats flow as valid only at >= 80 mm range (MT_OPTICALFLOW_MIN_RANGE),
  and quality threshold 30.
- Not decoded here: how Betaflight maps this onto its MSP sensor path.
