"""CRSF encode/decode helpers: RC channels frame (matches NimbusOS 2.9.0) and common telemetry frames.

Confirmed against the nimbus_core binary: RC frame layout, CRC-8 poly 0xD5, 172/992/1811 limits.
Telemetry decoders follow the public CRSF definitions and are NOT yet verified against real traffic.
"""
from __future__ import annotations

import math
import struct
from dataclasses import dataclass
from typing import Optional, Sequence

CRSF_MIN, CRSF_MID, CRSF_MAX = 172, 992, 1811

SYNC_FC = 0xC8     # sync byte NimbusOS puts on RC frames
SYNC_RADIO = 0xEA
SYNC_TX = 0xEE
SYNC_RX = 0xEC
VALID_SYNC = (SYNC_FC, SYNC_RADIO, SYNC_TX, SYNC_RX)

ADDR_FC, ADDR_RADIO, ADDR_RX, ADDR_TX = 0xC8, 0xEA, 0xEC, 0xEE   # CRSF device addresses

TYPE_VARIO = 0x07
TYPE_BATTERY = 0x08
TYPE_BARO_ALT = 0x09
TYPE_LINK_STATISTICS = 0x14
TYPE_RC_CHANNELS = 0x16
TYPE_ATTITUDE = 0x1E
TYPE_FLIGHT_MODE = 0x21
TYPE_DEVICE_PING = 0x28
TYPE_DEVICE_INFO = 0x29
TYPE_OPTRANGE = 0xD3      # custom Nimbus frame: range + optical flow from the drone (10-byte payload)
TYPE_GPS = 0x02
TYPE_MAG = 0x12
TYPE_RANGEFINDER = 0xD0   # custom: rangefinder distance + strength (4 bytes)
TYPE_RAW_IMU = 0xD1       # custom: raw gyro + accel (12 bytes)
TYPE_MIGHTY_CAM = 0xD2    # custom: MightyCam pose (13 bytes valid, 4 bytes invalid)
TYPE_MOTOR_PWM = 0xD4     # custom: motor PWM x4 + pole count (18 bytes), probable
TYPE_MOTOR_ERPM = 0xD5    # custom: motor eRPM x4 (16 bytes), probable
TYPE_VRX_TOP_CHANNELS = 0xE1   # custom: 48 bytes of video-receiver RSSI by frequency order
TYPE_DRONE_LINKED = 0xE2  # custom: 1 byte, drone link state
TYPE_FC_UID = 0xE3        # custom: flight controller UID, 12 bytes
TYPE_CUSTOM_E4 = 0xE4     # custom, 6 bytes, not identified


def _make_crc_table() -> bytes:
    table = bytearray(256)
    for i in range(256):
        crc = i
        for _ in range(8):
            crc = ((crc << 1) ^ 0xD5) & 0xFF if crc & 0x80 else (crc << 1) & 0xFF
        table[i] = crc
    return bytes(table)


_CRC = _make_crc_table()


def crc8(data: bytes, crc: int = 0) -> int:
    """CRC-8/DVB-S2 (poly 0xD5, init 0)."""
    for b in data:
        crc = _CRC[crc ^ b]
    return crc


def pack_channels(channels: Sequence[int]) -> bytes:
    """Pack 16 channels (0..2047) into 22 bytes, 11 bits each, little-endian bit order."""
    if len(channels) != 16:
        raise ValueError("CRSF RC frame needs exactly 16 channels")
    bits = 0
    for i, c in enumerate(channels):
        bits |= (int(c) & 0x7FF) << (11 * i)
    return bits.to_bytes(22, "little")


def unpack_channels(payload: bytes) -> list[int]:
    if len(payload) != 22:
        raise ValueError("RC payload must be 22 bytes")
    bits = int.from_bytes(payload, "little")
    return [(bits >> (11 * i)) & 0x7FF for i in range(16)]


def encode_frame(frame_type: int, payload: bytes, sync: int = SYNC_FC) -> bytes:
    body = bytes([frame_type]) + payload
    if len(body) + 1 > 62:
        raise ValueError("payload too long for a CRSF frame")
    return bytes([sync, len(body) + 1]) + body + bytes([crc8(body)])


def encode_rc_frame(channels: Sequence[int], sync: int = SYNC_FC) -> bytes:
    """26-byte RC_CHANNELS_PACKED frame, byte-identical to NimbusOS's EncodeControlFrame."""
    return encode_frame(TYPE_RC_CHANNELS, pack_channels(channels), sync)


def encode_device_ping(destination: int, origin: int = ADDR_RADIO) -> bytes:
    """6-byte DEVICE_PING: EE 04 28 <dest> <origin> CRC.
    Layout read from nimbus_core CrsfTransmitEncoder::EncodeDevicePingFrame (sync is always 0xEE)."""
    body = bytes([TYPE_DEVICE_PING, destination, origin])
    return bytes([SYNC_TX, len(body) + 1]) + body + bytes([crc8(body)])


@dataclass
class Frame:
    sync: int
    type: int
    payload: bytes


class FrameParser:
    """Byte-stream parser: finds sync, checks length and CRC, resynchronises after garbage."""

    def __init__(self) -> None:
        self._buf = bytearray()
        self.crc_errors = 0
        self.dropped_bytes = 0

    def feed(self, data: bytes) -> list[Frame]:
        self._buf += data
        out: list[Frame] = []
        buf = self._buf
        while len(buf) >= 4:
            if buf[0] not in VALID_SYNC:
                del buf[0]
                self.dropped_bytes += 1
                continue
            length = buf[1]
            if length < 2 or length > 62:
                del buf[0]
                self.dropped_bytes += 1
                continue
            total = length + 2
            if len(buf) < total:
                break
            body = bytes(buf[2:1 + length])
            if crc8(body) == buf[1 + length]:
                out.append(Frame(buf[0], body[0], body[1:]))
                del buf[:total]
            else:
                self.crc_errors += 1
                del buf[0]
                self.dropped_bytes += 1
        return out


def _rssi_dbm(b: int) -> int:
    """CRSF spec sends |dBm| (0..127); ELRS 4.x was seen sending the signed byte (208 -> -48 dBm). Real RSSI never exceeds 127 in magnitude."""
    return -b if b < 128 else b - 256


def decode_link_statistics(p: bytes) -> Optional[dict]:
    if len(p) < 10:
        return None
    return {"up_rssi1_dbm": _rssi_dbm(p[0]), "up_rssi2_dbm": _rssi_dbm(p[1]), "up_lq": p[2],
            "up_snr_db": struct.unpack("b", p[3:4])[0], "antenna": p[4], "rf_mode": p[5],
            "tx_power_idx": p[6], "down_rssi_dbm": _rssi_dbm(p[7]), "down_lq": p[8],
            "down_snr_db": struct.unpack("b", p[9:10])[0]}


def decode_battery(p: bytes) -> Optional[dict]:
    if len(p) < 8:
        return None
    volts, amps = struct.unpack(">HH", p[:4])
    return {"voltage_v": volts / 10.0, "current_a": amps / 10.0,
            "capacity_mah": int.from_bytes(p[4:7], "big"), "remaining_pct": p[7]}


def decode_attitude(p: bytes) -> Optional[dict]:
    if len(p) < 6:
        return None
    pitch, roll, yaw = struct.unpack(">hhh", p[:6])
    return {"pitch_rad": pitch / 10000.0, "roll_rad": roll / 10000.0, "yaw_rad": yaw / 10000.0}


def decode_flight_mode(p: bytes) -> Optional[dict]:
    return {"mode": p.split(b"\0", 1)[0].decode("ascii", "replace")}


def decode_vario(p: bytes) -> Optional[dict]:
    if len(p) < 2:
        return None
    return {"vspeed_cm_s": struct.unpack(">h", p[:2])[0]}


def decode_baro_alt(p: bytes) -> Optional[dict]:
    if len(p) < 2:
        return None
    raw = struct.unpack(">H", p[:2])[0]
    meters = float(raw & 0x7FFF) if raw & 0x8000 else (raw - 10000) / 10.0
    return {"baro_alt_m": meters}


def decode_optrange(p: bytes) -> Optional[dict]:
    """Custom frame 0xD3 -> OptrangeData, as built by nimbus_core's telemetry normalizer.

    Payload (10 bytes): distance i16 BE [mm], strength u8, precision u8, flow_x i16 BE, flow_y i16 BE,
    flow_quality u8, flow_status u8. Distance is only valid for raw 1..5999 (else 0.0), scale 1/1000 -> metres.
    Velocities: forward = distance * flow_x/100, right = -distance * flow_y/100 (sign of 'right' inferred).
    """
    if len(p) < 10:
        return None
    raw = struct.unpack(">H", p[0:2])[0]
    distance_m = (struct.unpack(">h", p[0:2])[0] / 1000.0) if 1 <= raw <= 5999 else 0.0
    flow_x, flow_y = struct.unpack(">hh", p[4:8])
    return {"distance_m": distance_m, "dist_strength": p[2], "dist_precision": p[3],
            "velocity_forward": distance_m * (flow_x / 100.0), "velocity_right": -distance_m * (flow_y / 100.0),
            "flow_quality": p[8], "flow_status": p[9], "flow_x_raw": flow_x, "flow_y_raw": flow_y}



# --- Custom Nimbus frames 0xD0-0xE4. Identification: decoder case sizes + normalizer blocks + app schema + log strings.
# Confidence is noted per decoder. Scalings read from nimbus_core constants unless stated.

def decode_rangefinder(p: bytes) -> Optional[dict]:
    """0xD0 (CONFIDENT): u16 BE distance in cm (Nimbus divides by 100 -> metres), u16 BE strength."""
    if len(p) < 4:
        return None
    dist, strength = struct.unpack(">HH", p[:4])
    return {"distance_m": dist / 100.0, "strength": strength}


def decode_raw_imu(p: bytes) -> Optional[dict]:
    """0xD1 (structure confident, scaling UNVERIFIED): 6 x int16 BE = gyro xyz, accel xyz.
    Scaling read from vectorised code: gyro = raw/100 * 180/pi (deg/s), accel = raw/100."""
    if len(p) < 12:
        return None
    g = struct.unpack(">3h", p[0:6])
    a = struct.unpack(">3h", p[6:12])
    k = 180.0 / math.pi / 100.0
    return {"gyro_forward": g[0] * k, "gyro_right": g[1] * k, "gyro_down": g[2] * k,
            "accel_forward": a[0] / 100.0, "accel_right": a[1] / 100.0, "accel_down": a[2] / 100.0,
            "raw": list(g) + list(a)}


def decode_mag(p: bytes) -> Optional[dict]:
    """0x12 (CONFIDENT on scale): 3 x int16 BE, divided by 3.0 in Nimbus (constant read from the binary)."""
    if len(p) < 6:
        return None
    x, y, z = struct.unpack(">3h", p[:6])
    return {"field_forward": x / 3.0, "field_right": y / 3.0, "field_down": z / 3.0}


def decode_drone_linked(p: bytes) -> Optional[dict]:
    """0xE2 (CONFIDENT): 1 byte, non-zero = drone linked (log string 'telemetry: droneLinked changed')."""
    return {"is_linked": p[0] != 0} if p else None


def decode_fc_uid(p: bytes) -> Optional[dict]:
    """0xE3 (frame CONFIDENT, byte order inferred): 12 bytes = three u32 (little-endian) of the MCU UID."""
    if len(p) < 12:
        return None
    u = struct.unpack("<3I", p[:12])
    return {"uid0": u[0], "uid1": u[1], "uid2": u[2], "uid_hex": "-".join(f"{x:08x}" for x in u)}


def decode_vrx_top_channels(p: bytes) -> Optional[dict]:
    """0xE1 (frame CONFIDENT, layout INFERRED): 48 raw bytes copied unmodified into 'videoReceiverTopChannels'
    (schema: rssiByFreqOrder[]). 48 = 6 bands (A B E F R L) x 8 channels, so treated as 48 RSSI bytes."""
    if len(p) != 48:
        return None
    return {"rssi_by_freq_order": list(p)}


def decode_custom_raw(frame_type: int, name: str):
    def _fn(p: bytes) -> Optional[dict]:
        return {"frame_type": f"0x{frame_type:02X}", "meaning": name, "hex": p.hex(), "decoded": False}
    return _fn


def format_device_version(sw: int) -> str:
    """Nimbus (FormatDeviceVersion) prints the top three bytes of the 32-bit value as major.minor.patch."""
    return f"{(sw >> 24) & 0xFF}.{(sw >> 16) & 0xFF}.{(sw >> 8) & 0xFF}"


def decode_device_info(p: bytes) -> Optional[dict]:
    """DEVICE_INFO (0x29) extended frame payload: dest, origin, name\0, serial u32, hw u32, sw u32, params u8, proto u8."""
    if len(p) < 3:
        return None
    dest, origin = p[0], p[1]
    end = p.find(b"\0", 2)
    if end < 0 or len(p) < end + 1 + 14:
        return {"origin": origin, "dest": dest, "name": p[2:].decode("ascii", "replace")}
    serial, hw, sw = struct.unpack(">III", p[end + 1:end + 13])
    return {"origin": origin, "dest": dest, "name": p[2:end].decode("ascii", "replace"), "serial": serial,
            "hardware_id": hw, "software_id": sw, "version": format_device_version(sw),
            "param_count": p[end + 13], "param_protocol": p[end + 14] if len(p) > end + 14 else None}


_DECODERS = {TYPE_OPTRANGE: ("optrange", decode_optrange), TYPE_RANGEFINDER: ("rangefinder", decode_rangefinder),
             TYPE_RAW_IMU: ("raw_imu", decode_raw_imu), TYPE_MAG: ("magnetometer", decode_mag),
             TYPE_DRONE_LINKED: ("drone_linked", decode_drone_linked), TYPE_FC_UID: ("fc_uid", decode_fc_uid),
             TYPE_VRX_TOP_CHANNELS: ("vrx_top_channels", decode_vrx_top_channels),
             TYPE_MIGHTY_CAM: ("custom_d2", decode_custom_raw(TYPE_MIGHTY_CAM, "MightyCam pose (not decoded)")),
             TYPE_MOTOR_PWM: ("custom_d4", decode_custom_raw(TYPE_MOTOR_PWM, "motor PWM x4 + poles (probable, not decoded)")),
             TYPE_MOTOR_ERPM: ("custom_d5", decode_custom_raw(TYPE_MOTOR_ERPM, "motor eRPM x4 (probable, not decoded)")),
             TYPE_CUSTOM_E4: ("custom_e4", decode_custom_raw(TYPE_CUSTOM_E4, "unidentified 6-byte frame")), TYPE_DEVICE_INFO: ("device_info", decode_device_info), TYPE_LINK_STATISTICS: ("link", decode_link_statistics), TYPE_BATTERY: ("battery", decode_battery),
             TYPE_ATTITUDE: ("attitude", decode_attitude), TYPE_FLIGHT_MODE: ("flight_mode", decode_flight_mode),
             TYPE_VARIO: ("vario", decode_vario), TYPE_BARO_ALT: ("baro", decode_baro_alt)}


def decode_telemetry(frame: Frame) -> Optional[tuple[str, dict]]:
    entry = _DECODERS.get(frame.type)
    if entry is None:
        return None
    name, fn = entry
    data = fn(frame.payload)
    return None if data is None else (name, data)
