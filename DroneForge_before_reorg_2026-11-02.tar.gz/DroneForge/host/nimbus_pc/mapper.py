"""Stick/throttle to CRSF mapping, constants read from the nimbus_core binary (CrsfMapper)."""
import math

from .crsf import CRSF_MAX, CRSF_MID, CRSF_MIN


def _lroundf(x: float) -> int:
    """C lroundf: round half away from zero (Python round() is banker's rounding)."""
    return int(math.floor(x + 0.5)) if x >= 0 else -int(math.floor(-x + 0.5))


def stick_to_crsf(v: float) -> int:
    """-1..1 -> 172..1811, centre 992 (CrsfMapper::StickToCrsf)."""
    v = max(-1.0, min(1.0, v))
    return _lroundf(max(CRSF_MIN, min(CRSF_MAX, v * 820.0 + 992.0)))


def throttle01_to_crsf(t: float) -> int:
    """0..1 -> 172..1811 (CrsfMapper::Throttle01ToCrsf)."""
    t = max(0.0, min(1.0, t))
    return _lroundf(max(CRSF_MIN, min(CRSF_MAX, t * 1639.0 + 172.0)))


def crsf_to_throttle01(v: int) -> float:
    """CrsfMapper::CrsfToThrottle01."""
    return (max(CRSF_MIN, min(CRSF_MAX, v)) - CRSF_MIN) / 1639.0
