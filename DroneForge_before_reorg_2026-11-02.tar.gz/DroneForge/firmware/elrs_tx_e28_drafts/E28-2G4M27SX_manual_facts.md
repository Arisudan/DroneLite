# E28-2G4M27SX facts read from Ebyte's user manual (a scanned PDF, read page by page; file metadata wrongly says E01-2G4M27D)

Title page: "E28-2G4M27SX User Manual - SX1281 2.4GHz 500mW SPI High-speed LoRa module". "A pure RF transceiver module, which needs to be driven by MCU or use a
dedicated SPI debugging tool." Driving mode is equivalent to the SX1281 chip. Size 20 x 15 mm, pad pitch 1.27 mm, IPEX connector on the module (drawing page 5).

## Limits and electrical (manual pages 4-5)
| Item | Value |
|---|---|
| Supply, absolute max | **3.6 V ("exceeding 3.6 V will permanently burn the module")** |
| Supply, working | 2.5 - 3.6 V, typ 3.3 V; >= 3.3 V guarantees the output power |
| Logic level | 3.3 V ("risk of burnout with 5 V TTL") |
| TX current | **580 mA instantaneous** (typ) |
| RX current / sleep | 14.5 mA / 2.0 uA |
| TX power | min 26, typ 26.5, max 27 dBm |
| Blocking power (RF input) | max 10 dBm |
| Sensitivity | -130 / -131 / -132 dBm (LoRa SF12, BW 203 kHz) |
| Interface | SPI up to 10 Mbps; antenna "IPEX/PCB", about 50 ohm |

## Pins (page 5-6)
1 VCC (2.5-3.6 V, add an external ceramic filter capacitor), 2 GND, 3 MISO_TX (out), 4 MOSI_RX (in), 5 SCK_RTSN (in), 6 NSS_CTS (in),
7 GND, **8 RX_EN (LNA control, active high)**, **9 TX_EN (PA control, active high)**, 10 GND, **11 NRESET (active low, built-in 50 k pull-up)**,
12 BUSY (out), 13 DIO1, 14 DIO2, 15 DIO3 (I/O), 16 GND.
Application circuit (page 8): MCU drives RXEN, TXEN, nRESET as outputs; BUSY is an input; SPI on MISO/MOSI/SCK/NSS.

## Software note (page 7, section 4.2) - the important one
"It is recommended to set the power output parameter of SX1281 to **0 dBm**. At this time, the module can output power of **27 dBm**. When the output power of SX1281 is
increased, the current will increase, and the power will not increase significantly."
=> The PA saturates: about 27 dB of gain, so drive level maps to output roughly as (drive + 27) dBm until it compresses near the top.

## Hardware design notes (pages 6-7)
- Use a DC regulated supply with small ripple; reserve **more than 30 % margin** in the supply design; check polarity; keep the module away from interference,
  keep high-frequency traces off the underside of the module, no metal shell around the antenna; antenna exposed, preferably vertical.
- FAQ: low supply voltage lowers output power; poorly matched antenna reduces range; SPI lines should not be too long.

## Estimates derived from the 0 dBm -> 27 dBm statement (UNMEASURED; the PA is not linear near the top)
| SX1281 drive (ELRS power value) | Module output (about) | EIRP with an 8 dBi patch (assumed gain) |
|---|---|---|
| -18 dBm | 9 dBm (8 mW) | 17 dBm (50 mW) |
| -15 dBm | 12 dBm (16 mW) | 20 dBm (100 mW) |
| -11 dBm | 16 dBm (40 mW) | 24 dBm (250 mW) |
| -5 dBm | 22 dBm (160 mW) | 30 dBm (1 W) |
| 0 dBm | 27 dBm (500 mW) | 35 dBm (3 W) |
ELRS's own E28 layout labels -15..-1 dBm as 10..250 mW in its Lua menu; those labels do not match Ebyte's gain figure for this module.
