# Review of the user's PCB schematic (ESP32-C3 Super Mini + E28-2G4M27SX + battery power) — read from an image

Everything below is read from a screenshot marked "FOR REVIEW ONLY". Where the image was ambiguous it is marked CONFIRM.

## Pin mapping as I read it
ESP32-C3 pin -> signal: GPIO0 NRESET, GPIO1 BUSY, GPIO2 DIO1, GPIO3 SCK, GPIO4 MISO, GPIO5 MOSI, GPIO6 unused (CONFIRM), GPIO7 NSS,
GPIO8 RXEN, GPIO9 TXEN, GPIO10 "POC_IN" -> R9 62R -> Q3 SS8050 -> connector J2 (3V3 + low-side switch), GPIO20/21 no net, 5V pin via R8 0R/DNP.
E28 pins: 1 VCC, 2 GND, 3 MISO, 4 MOSI, 5 SCK, 6 NSS, 7 GND, 8 RXEN, 9 TXEN, 10 GND, 11 nRESET, 12 BUSY, 13 DIO1, 14/15 DIO2/3 unused, 16 GND.

## Findings
| # | Severity | Finding | Fix |
|---|---|---|---|
| C1 | CRITICAL | **No CRSF input.** GPIO20/21 (UART0, where ELRS reads CRSF) are not connected to anything, and the Super Mini's USB-C cannot carry CRSF. The PC link cannot work. | Add a header or pads: GND, GPIO20 (RX), GPIO21 (TX) for a 3.3 V USB-UART adapter, or put a CP2102N/CH340 on the board wired to 20/21. |
| C2 | CRITICAL | **R9 = 62 ohm on the transistor base.** From a 3.3 V GPIO: (3.3 - 0.7)/62 = about 42 mA out of GPIO10, well beyond what a GPIO should source. | 330-470 ohm for loads near 150 mA (Ib about 6-8 mA), 1 kohm for small loads. Better: drive the AO3400A N-MOSFET (already on the BOM) through 100 ohm. |
| H1 | HIGH | **LDO is 300 mA** (AP2127K-3.3). Ebyte's manual (verified) gives **580 mA instantaneous TX current** and asks for >30 % supply margin, so about 750 mA+ just for the module. It must power the ESP32-C3 (Wi-Fi bursts, ELRS turns Wi-Fi on after 60 s idle), the E28 PA and the J2 load. Margin is thin; brownouts reset the radio mid-flight. | Use a 600 mA-1 A LDO (AP2112K-3.3 is pin-compatible: VIN, GND, EN, NC, VOUT; CONFIRM against its datasheet). Do not put a fan on this rail. |
| H2 | HIGH | **Three strapping pins carry module signals:** GPIO2 = DIO1 (a module OUTPUT), GPIO8 = RXEN, GPIO9 = TXEN (also the Super Mini's BOOT button). If the module holds one low at power-up the chip can fail to boot or enter download mode. ELRS's tested Super Mini layout uses GPIO2 only for RESET (an output). | Use the remap below (SPI/BUSY/DIO1/RST exactly as ELRS-tested, TXEN=GPIO10, RXEN=GPIO0). |
| H3 | HIGH | **E28 VCC has only 2 x 0.1 uF** (C8, C9). Ebyte's manual (pin 1 note) recommends an external ceramic filter capacitor and warns the module is destroyed above 3.6 V; a PA module pulls current in bursts. | Add 22 uF (low ESR ceramic) + 100 nF + 10 nF right at pin 1, with a short ground return. |
| M1 | MEDIUM | LDO pin 3 (shutdown/EN) appears to connect to the R2/R3 divider midpoint (about 1.65 V) CONFIRM. That is near the enable threshold. | Tie EN to VIN. For a fixed 3.3 V part, R2/R3 are not needed. |
| M2 | MEDIUM | **Two 3.3 V sources:** U1 drives the Super Mini's 3V3 pin while USB-C also powers its own regulator onto that same net. | Never connect USB-C while on battery, or feed the Super Mini's 5V pin from a 5 V rail, or add an ideal-diode/Schottky isolation. Keep R8 DNP. |
| M3 | MEDIUM | If J2 is a fan or other inductive load there is no flyback diode, and it sits on the 3.3 V rail (see H1). | Add a Schottky across the load; power big loads from the battery, not 3V3. |
| M4 | MEDIUM | RF: the Super Mini has its own 2.4 GHz antenna, and the E28 is a 27 dBm PA with an IPEX/PCB antenna. | Keep the module's PCB antenna end off the board edge with copper keepout, route a 50 ohm trace to the IPEX connector, and keep the two antennas apart. |
| M5 | MEDIUM | Power switch/latch (Q1 AO3407A, Q2 AO3400A, diodes, R1-R7, SW1) could not be verified from the image: MOSFET body-diode orientation and latch logic are not readable. LDO input max is 6 V, so 1S only. | Bench-test with a current-limited supply before connecting a battery; verify polarity protection by hand-checking the body diode direction. |

## What looks right
- E28 symbol pin functions match Ebyte's names (pin 8 RX_EN = active-high LNA control, pin 9 TX_EN = active-high PA control, pin 11 nRESET with built-in 50 k pull-up).
- RXEN/TXEN polarity matches how ELRS drives them (TX: TXEN high, RXEN low; RX: opposite; idle: both low).
- SPI wiring is consistent between the ESP32 labels and the E28 symbol (MISO/MOSI/SCK/NSS).
- R8 correctly left DNP; separate decoupling at the ESP32 3V3 pin.

## Layout files
- `c3_supermini_e28_USER_PCB_as_drawn.hardware.json` — works with the wiring exactly as drawn (but see C1, H2).
- `c3_supermini_e28_RECOMMENDED_remap.hardware.json` — ELRS-tested SPI/RST/DIO1/BUSY pins, TXEN=10, RXEN=0, fan enable on GPIO8 (its transistor base pull-down keeps GPIO8 low at boot, which is acceptable for SPI boot).

## Verified against Ebyte's manual
Pin functions (8 RX_EN, 9 TX_EN active high, 11 NRESET with 50 k pull-up), 3.3 V logic, 2.5-3.6 V supply (3.6 V = destruction), 580 mA TX current, IPEX antenna connector. See `E28-2G4M27SX_manual_facts.md`.

## Not verified
Power-latch behaviour, MOSFET orientation, current budget numbers (E28 TX current, ESP32-C3 Wi-Fi peak), the exact GPIO6/UART pin routing, and everything about the real PCB layout.
