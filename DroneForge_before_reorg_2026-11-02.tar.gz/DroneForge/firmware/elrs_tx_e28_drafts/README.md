# Own-built ELRS TX dongle: ESP32 + Ebyte E28-2G4M27SX — DRAFT, NOT BUILT, NOT FLASHED

The LilyGO order was cancelled (no stock). These two layouts replace `../elrs_tx_t3s3_draft/` (kept for reference).
Both feed the same PC software (`host/nimbus_pc`): CRSF at 115200 over a serial port into the dongle's UART.

## What was verified in ELRS's own source (2026-11-02)
- Official firmware exists for both chips: `Unified_ESP32_2400_TX_via_UART` (classic ESP32) and `Unified_ESP32C3_2400_TX_via_UART`
  (ESP32-C3, SX128x). The layout file (`hardware.json`) is loaded from the device's LittleFS.
- ELRS's chip check only rejects a firmware revision of 0 or 65535, so the SX1281 that sellers list for the E28-2G4M27SX is accepted.
- ELRS drives the PA pins as: TX mode = TXEN high, RXEN low; RX mode = RXEN high, TXEN low; idle = both low (both start low at boot).
  The module's own datasheet must confirm the same truth table before power-up (not found online, see below).
- C3 Super Mini: ELRS's repo has a tested SX1280 receiver layout for this exact board; SPI pins here are copied from it
  (SCK 6, MISO 5, MOSI 4, NSS 7, RST 2, DIO1 1, BUSY 3). GPIO 0 and 10 are the two free, non-strapping pins, used for RXEN/TXEN.
- Classic ESP32 pins are copied from ELRS's `DIY 2400 E28` layout (the E28 reference design).
- CRSF input is UART0 on `serial_rx`/`serial_tx` (stock ELRS has no USB-CDC handset input).
- Power values are SX1280/SX1281 drive in dBm. Ebyte's manual says 0 dBm drive gives 27 dBm out (about 27 dB of PA gain), so ELRS's nominal mW labels for its E28 layout understate this module's real output. These layouts use [-18,-15,-11,-8,-5] with only the first two usable (`power_max` 1).

## Which host board?
| | ESP32 DevKit V1 (you own it) | ESP32-C3 Super Mini (you own it) |
|---|---|---|
| CRSF from the PC | Over the board's own USB-UART chip on GPIO3/1, **no extra adapter** (serial pins 3/1 in the layout; UNVERIFIED on hardware) | **Needs a 3.3 V USB-UART adapter** wired to GPIO20/21; its USB-C port cannot carry CRSF |
| SPI + PA pins | ELRS's official E28 pin map | ELRS-tested SX1280 pins + 0/10 for TXEN/RXEN |
| Flashing | USB (bridge) | native USB (hold BOOT while plugging in) |
| Size | big | tiny |
Recommendation: build on the DevKit V1 first (fewest parts, proven E28 pin map). Use the C3 when you want a small dongle and have an adapter.

## Wiring (verify every module pin against the Ebyte datasheet first)
Module pins needed: VCC (3.3 V), GND, SCK, MISO, MOSI, NSS, NRST, BUSY, DIO1, TXEN, RXEN, antenna.
| Signal | C3 Super Mini | DevKit V1 |
|---|---|---|
| SCK / MISO / MOSI | GPIO6 / 5 / 4 | GPIO18 / 19 / 23 |
| NSS / NRST | GPIO7 / 2 | GPIO5 / 14 |
| DIO1 / BUSY | GPIO1 / 3 | GPIO4 / 21 |
| TXEN / RXEN | GPIO10 / 0 | GPIO26 / 27 |
| PC link (UART0) | RX=GPIO20, TX=GPIO21 to a USB-UART adapter (cross TX/RX, common GND) | GPIO3/1 via the on-board USB bridge |

## Safety (this module can output 500 mW)
1. **Antenna on the active path before any power-up.** The listing says "IPEX/PCB": check which antenna path your unit uses.
2. **Power:** all layouts set `power_max` to index 1, so ELRS can only use -18 and -15 dBm drive (roughly 8 and 16 mW at the module by Ebyte's gain figure). Do not raise it without a power meter.
3. **Supply:** the module is 2.5-3.6 V (best above 3.3 V) and draws a lot in TX: add >=100 uF plus 100 nF at the module's VCC, short wires,
   and prefer a clean 3.3 V source (the small on-board regulators of these dev boards may sag at higher power).
4. The 1.27 mm pitch SMD module needs an adapter board or careful soldering. No-return policy on many sellers once soldered.
5. Check your country's 2.4 GHz power rules (nominal 25 mW at -11 dBm; 100 mW at -5 dBm).

## Not verified
- Module truth table for TXEN/RXEN and its pinout (no datasheet found online; get Ebyte's PDF).
- That the SX1281 variant's PA gain matches the E28-2G4M27S (the ELRS values assume that module).
- `power_lna_gain` 12 is copied from ELRS's E28 layout; it only affects the RSSI readout.
- DevKit V1 CRSF over GPIO3/1: believed to work (UART0 pins, full duplex), not tested.
- Nothing has been built, flashed or transmitted.
