# Prototype first: ESP32-C3 Super Mini + E28-2G4M27SX breakout + USB-UART adapter (+ 2.4 GHz patch antenna)

Build this on perfboard or a breadboard BEFORE ordering the PCB. It proves the radio, ELRS firmware and the PC link, and it avoids the
schematic problems listed in `PCB_REVIEW.md`. Layout used: `DIY C3 SuperMini E28.json` (ELRS-tested SPI pins, TXEN=GPIO10, RXEN=GPIO0, no fan).

## 0. Check first (do not wire yet)
- [ ] Which E28 breakout is it? It MUST expose: VCC, GND, SCK, MISO, MOSI, NSS, NRESET, BUSY, DIO1, **TXEN, RXEN**. Some test boards tie TXEN/RXEN
      together or hide them: ELRS needs both pins separately.
- [ ] Does the breakout take 3.3 V directly, or does it have its own regulator/5 V input? The E28 module itself is 2.5-3.6 V only.
- [ ] Antenna path: the module lists "IPEX/PCB". Find out how the antenna is selected (jumper/0 ohm) and connect the patch antenna on the ACTIVE path.
- [ ] **Is the patch antenna 2.4 GHz?** FPV patch antennas are usually 5.8 GHz and would be badly mismatched on a 2.4 GHz PA. Also check its connector (SMA or RP-SMA)
      and use the matching IPEX pigtail.
- [ ] USB-UART adapter: 3.3 V logic, with TX, RX and GND pins. Do NOT connect its 5 V pin.


## 0b. Your board: "E28-2G4M27SX test board" (confirmed M-series, so it is the right family)
The name matches your module (SPI, raw SX1281). Ebyte's manual for the module is summarised in `E28-2G4M27SX_manual_facts.md`. I found no manual for the test board itself,
so check these with the board in hand before wiring:
1. Read the label next to every header pin. You need: VCC, GND, SCK, MISO, MOSI, NSS, NRESET, BUSY, DIO1, **TXEN, RXEN**.
2. Look for a USB-C port, a USB-serial chip or a microcontroller on the board. If one is wired to the SPI pins it will fight the ESP32: disconnect it or use a plain breakout.
3. Power: the module's absolute maximum is **3.6 V** and it draws **580 mA** in transmit (manual). Measure the module's VCC pin while powered: it must read 3.3 V. If the board
   regulates from USB-C/5 V, power it from that, with a source that can supply well over 600 mA, and share ONLY ground with the Super Mini.
   Do NOT power it from the Super Mini's 3V3 pin unless you know that regulator can carry the load (unknown).
4. Antenna: the module has an IPEX connector; if the board has an SMA connector, your 2.4 GHz patch (SMA plug) connects there. Check SMA vs RP-SMA polarity.
5. With a multimeter, confirm continuity from the TXEN/RXEN headers to module pins 9 and 8.

## 1. Wiring
| Signal | C3 Super Mini | E28 breakout | Note |
|---|---|---|---|
| SCK | GPIO6 | SCK | |
| MISO | GPIO5 | MISO | |
| MOSI | GPIO4 | MOSI | |
| NSS | GPIO7 | NSS | |
| NRESET | GPIO2 | NRESET | ELRS-tested pin; module has an internal 50 k pull-up |
| DIO1 | GPIO1 | DIO1 | |
| BUSY | GPIO3 | BUSY | |
| TXEN | GPIO10 | TXEN | active high = PA on |
| RXEN | GPIO0 | RXEN | active high = LNA on |
| 3V3 | 3V3 | VCC | add 22 uF + 100 nF right at the module VCC, wires as short as possible |
| GND | GND | GND (all GND pins) | common ground with the adapter |
| CRSF in | GPIO20 (RX) <- adapter TX | | |
| CRSF out | GPIO21 (TX) -> adapter RX | | |
Power the Super Mini from its own USB-C only (it also flashes through that port). Do not power it from the adapter's 5 V.

## 2. Get the firmware and add the target (CORRECTED, UNVERIFIED on hardware)
GitHub's ELRS releases only attach the Lua script (checked: 4.1.0, 4.0.1, 3.6.4 list just `elrs.lua`), so there is no "release zip" to download from there. Two documented routes:
- **A. ExpressLRS Configurator** (docs call it the recommended route; Linux/Windows/Mac builds on its GitHub releases). Check whether it can use a custom layout for a DIY target; if not, use B.
- **B. Build from source with PlatformIO** (docs: "development toolchain"): clone ExpressLRS, copy `DIY C3 SuperMini E28.json` into the `hardware/TX/` layouts, add the entry from
  `targets_entry_c3_supermini_e28.json` to `hardware/targets.json`, build `Unified_ESP32C3_2400_TX_via_UART`, then patch and flash with `src/python/binary_configurator.py --target diy.tx_2400.c3_supermini_e28 --tx --flash uart --port <port> --phrase "..."`.
**Version rule:** the transmitter and receiver must run the same ELRS major version (3.x vs 4.x do not interoperate; latest tags seen: 4.1.0, 4.0.1, 3.6.4). Read your receiver's version first.
Also needed before building: which pin mapping your PCB uses (as drawn or the remap), and how the PC link reaches GPIO20/21.

## 3. First power-up (antenna connected first)
- [ ] Patch antenna attached before power. Keep it a few metres from the receiver, pointed at it. The layout only allows drive levels -18 and -15 dBm (see EIRP note: roughly 8 mW and 16 mW module output by Ebyte's gain figure). Start at -18 only (set `power_max` to 0 for the very first test).
- [ ] The E28 may warm slightly; if it becomes hot, unplug immediately.
- [ ] Connect the adapter. Run `python3 -m nimbus_pc send --port /dev/ttyUSB0 --duration 15` (disarmed). ELRS cycles baud rates until it locks onto 115200.
- [ ] Expect `[telemetry] ...` lines (device info answers) once the transmitter is talking; link stats appear after the receiver binds.
- [ ] Bind to your receiver using the same bind phrase, then verify channels in Betaflight like the Boxer test, props off.

## EIRP note (corrected)
Ebyte says 0 dBm of drive gives 27 dBm out, i.e. about 27 dB of PA gain. So a drive of -18 dBm is roughly 9 dBm (8 mW) at the module, and -15 dBm roughly 12 dBm (16 mW).
My earlier note used ELRS's "nominal" 10 mW label and underestimated this. A 2.4 GHz patch adds gain (often 6-9 dBi, check yours) and is directional: with an assumed 8 dBi,
-18 dBm drive is about 50 mW EIRP and -15 dBm about 100 mW EIRP. These are estimates: the PA is not linear near the top and nothing was measured. Check your local 2.4 GHz limits.

## Not verified
Breakout pinout and whether it exposes TXEN/RXEN; ELRS release contents; that `Unified_ESP32C3_2400_TX` and a custom `diy` entry work with `binary_configurator.py`
and the layout path; C3 native-USB download behaviour with that tool; everything about real RF performance.
