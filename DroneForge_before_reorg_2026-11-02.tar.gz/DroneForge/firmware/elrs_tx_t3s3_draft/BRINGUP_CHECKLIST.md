# T3-S3 (SX1280 PA) arrival and bring-up checklist

Everything here is a plan. Nothing has been tried on the real board yet. Steps marked (UNVERIFIED) rest on reading
ELRS/LilyGO sources, not on a test.

## 0. Before it arrives
- [ ] Also have: 3.3 V USB-UART adapter (CP2102 preferred), 2.4 GHz antenna (if not in the box), 3 jumper wires.
- [ ] Know your receiver's ELRS version (Boxer: System > Tools > ExpressLRS). The transmitter must be the same major version (3.x).
- [ ] Decide the bind phrase (same on TX and RX) or plan to bind with the receiver's bind mode.
- [ ] Hubtronics policy: claims within 48 h of delivery with an unboxing video; warranty void once programmed.

## 1. Unboxing (film it)
- [ ] Label/silkscreen: board version V1.2 or V1.3, "SX1280" + PA marking, 2.4 GHz.
- [ ] Antenna present and screws onto the SMA connector.
- [ ] If anything is missing or wrong: stop, do not flash, claim within 48 h.

## 2. First power-up (antenna ON first)
- [ ] Attach the antenna BEFORE connecting USB. The board may run LilyGO's factory firmware and transmit.
- [ ] Plug in USB-C. Expect `lsusb` to show an Espressif device `303a:1001` and a /dev/ttyACM*.
- [ ] Do not connect the UART adapter yet.

## 3. Read-only chip checks (esptool v5, no writes)
```
esptool --port /dev/ttyACM0 chip-id
esptool --port /dev/ttyACM0 flash-id
```
Expect: ESP32-S3, 4 MB flash. If flash is not 4 MB, STOP and re-check the board version.

## 4. Back up the factory firmware (4 MB)
```
esptool --port /dev/ttyACM0 read-flash 0 0x400000 t3s3-factory-4MB.bin
```
Keep this file. It is your way back to the stock board.

## 5. Flash ELRS (UNVERIFIED)
- Target: `Unified_ESP32S3_2400_TX_via_UART`, ELRS 3.x matching the receiver, domain for your country.
- Flash with the header rewritten for 4 MB (esptool `--flash-size 4MB`) because that target's image says 8 MB.
- The partition table (min_spiffs) ends at 0x400000, so it fits.

## 6. Load the layout and confirm the power cap (UNVERIFIED)
- After boot ELRS opens a WiFi access point (the Nimbus build has a 60 s auto-on interval); the web UI is at 10.0.0.1 and has a
  `/hardware.html` page that takes `hardware.json`.
- Upload `hardware.json` from this folder (SX1280 pins 5/3/6/7/8/9/36, PA TX=10 RX=21, power_values [3]).
- Antenna ON. After the radio starts, the PA area may get warm, but not hot. If hot: unplug immediately.
- Output power must stay at one level, 3 dBm at the SX1280. Never add a higher value.

## 7. Wire the UART adapter (3.3 V only)
adapter TX -> T3-S3 GPIO44 (RX), adapter RX -> T3-S3 GPIO43 (TX), GND -> GND. No 5 V, no DTR/RTS.

## 8. PC link test (props off)
```
cd ~/Music/DroneForge/host
python3 -m nimbus_pc.sender --port /dev/ttyUSB0 --duration 15
```
- ELRS cycles baud rates until it finds 115200, so lock can take several seconds.
- Expect `[telemetry] ...` lines once the transmitter answers pings and (after binding) a receiver is linked.
- The sender is disarmed by default. Arming needs `--arm --allow-arm` and props removed.

## 9. Bind and end-to-end check
- [ ] Bind to your receiver (shared bind phrase, or receiver bind mode; the sender does not send bind frames yet).
- [ ] With the FC on USB and props off, send frames from the PC and read the FC's channels (MSP_RC, read-only) like the Boxer test:
      values should follow the PC's roll/pitch/yaw/throttle.
- [ ] Failsafe: stop the sender; the FC should show the receiver-loss value, then (if armed) disarm within about 1.5 s.

## Known unknowns
ELRS PA-pin handling on this exact board; baud lock time; whether the 3 dBm cap gives usable range for your use;
local 2.4 GHz power rules (about 100 mW at the module output).
