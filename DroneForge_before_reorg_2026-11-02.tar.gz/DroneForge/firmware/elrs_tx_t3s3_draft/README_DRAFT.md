# ELRS TX layout for LilyGO T3-S3 (SX1280 with PA) — DRAFT, NOT FLASHED, NOT TESTED

Target: ExpressLRS `Unified_ESP32S3_2400_TX_via_UART` (the same target Nimbus's firmware was built from).

## Where every value comes from
| Key | Value | Source |
|---|---|---|
| radio_sck / miso / mosi | 5 / 3 / 6 | LilyGO T3-S3 SX1280PA doc, pin map |
| radio_nss (CS) | 7 | same |
| radio_rst | 8 | same |
| radio_dio1 | 9 | same (NOT 33; 33 belongs to other LilyGO boards) |
| radio_busy | 36 | same |
| power_txen | 10 | same ("LoRa TX" = PA enable) |
| power_rxen | 21 | same ("LoRa RX" = LNA enable). Truth table: TX=1 -> PA; TX=0,RX=1 -> LNA |
| power_values | [3] | LilyGO: SX1280 output must stay 2-5 dBm; 3 dBm gives ~20 dBm module output; higher can destroy the FEM |
| serial_rx / serial_tx | 44 / 43 | UART0 pins on the QWIIC socket. **Stock ELRS reads CRSF only from UART0 on these pins** (CRSFHandset.cpp); the T3-S3's USB-C port does NOT carry CRSF. A 3.3 V USB-UART adapter is needed (see below). |

## Safety rules (from LilyGO + our own caution)
1. Antenna connected BEFORE any transmit. Always.
2. power_values has ONE entry, 3 dBm, on purpose: ELRS cannot select a higher level from this layout. Never add values above 5.
3. Power from USB only (do not also feed VBAT/VBUS pins).
4. Check local 2.4 GHz power rules; the module outputs about 20 dBm (100 mW) at this setting.

## Verified in ELRS master source (2026-10-31)
- `hardware.cpp` loads `/hardware.json` from LittleFS and knows every key used here (`power_high` is not a key any more, so it was removed).
- CRSF input is `HardwareSerial(0)` = UART0 on `serial_rx`/`serial_tx`; baud list includes 115200 (limits packet rate to 250 Hz).
- `power_values` are SX1280 output in dBm (`Radio.SetOutputPower`), so `[3]` = +3 dBm.
- The code that can raise the SX1280 output by up to 3 dB (`incSX1280Output`) is only driven by the power-detector device,
  which stays off unless a PDET pin is defined. This layout defines none, so output stays at exactly 3 dBm.

## Wiring needed for the PC link (3 wires + ground)
USB-UART adapter (3.3 V logic; a CP2102 is recommended: Nimbus's PC software only lists ports from USB vendors 0x10c4 and 0x303a):
adapter TX -> T3-S3 GPIO44 (RX), adapter RX -> T3-S3 GPIO43 (TX), GND -> GND. Do not connect the adapter's 5 V or DTR/RTS.
Power the T3-S3 from its own USB-C port.

## Open items (unverified)
- power_lna_gain = 0 is a placeholder (the real LNA gain of the T3-S3 front end is not documented); it only affects RSSI readout.
- Whether radio uses LDO or DC-DC (ELRS key radio_dcdc, default off = LDO). Left off.
- PA TX/RX pins should be input-pull-down while the radio sleeps (LilyGO FAQ). ELRS behavior here is untested; check the PA does not get warm when idle.
- LilyGO's board has 4 MB flash. ELRS's esp32-s3-devkitc-1 build writes an 8 MB flash-size header (the Nimbus image has it too). Flash with the header rewritten, e.g. esptool `--flash-size 4MB`, or the first boot may warn/fail. The partition table (min_spiffs) ends exactly at 0x400000, so it fits.
- Nothing here has been built, flashed or run on a real board.

## Suggested first bring-up (when the board arrives)
1. esptool: `chip-id`, `flash-id` -> expect ESP32-S3, 4 MB flash.
2. Build ELRS with this hardware.json for the target above, with power limited as drafted.
3. Flash with header rewritten to 4 MB. Antenna attached.
4. Bind to your existing 2.4 GHz receiver, then send frames with host/crsf_ref.py at 115200 baud, ~100 Hz.
