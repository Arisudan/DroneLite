#include <Arduino.h>
// Read-only pin diagnostics for the SX1281 wiring (no TX enable, no SPI traffic).
static const int PINS[] = {1, 2, 4, 0};
static const char *NAMES[] = {"BUSY(GPIO1)", "DIO1(GPIO2)", "MISO(GPIO4)", "NRESET(GPIO0)"};

void setup() { Serial.begin(115200); delay(3000); pinMode(7, OUTPUT); digitalWrite(7, HIGH); pinMode(8, OUTPUT); digitalWrite(8, LOW); pinMode(9, OUTPUT); digitalWrite(9, LOW); }

static int rd(int p, int mode) { pinMode(p, mode); delay(20); return digitalRead(p); }

void loop() {
  Serial.println("\n--- pin diagnostics (NSS high, RXEN/TXEN low) ---");
  for (int i = 0; i < 3; i++) {
    int pd = rd(PINS[i], INPUT_PULLDOWN), pu = rd(PINS[i], INPUT_PULLUP), fl = rd(PINS[i], INPUT);
    Serial.printf("%-14s pulldown->%d  pullup->%d  float->%d  => %s\n", NAMES[i], pd, pu, fl,
                  (pd == 1 && pu == 1) ? "DRIVEN HIGH by something" : (pd == 0 && pu == 1) ? "FLOATING (nothing driving it)" : (pd == 0 && pu == 0) ? "DRIVEN LOW by something" : "odd");
  }
  // NRESET: hold low and check BUSY; then release and check BUSY
  pinMode(0, OUTPUT); digitalWrite(0, LOW); delay(50);
  int b_low = rd(1, INPUT_PULLDOWN);
  pinMode(0, OUTPUT); digitalWrite(0, HIGH); delay(50);
  int b_high = rd(1, INPUT_PULLDOWN);
  Serial.printf("BUSY with NRESET held LOW: %d | NRESET released HIGH: %d\n", b_low, b_high);
  pinMode(0, INPUT_PULLDOWN); delay(20);
  Serial.printf("NRESET pin pulled down reads: %d (1 means module/test board pulls it up)\n", digitalRead(0));
  delay(4000);
}
