# Your assembled PCB: ESP32-C3 Super Mini + E28-2G4M27SX (status 2026-11-02)

## Verified on the real board
- First USB cable carried power but no data (no device appeared). A second cable works: `lsusb` shows `303a:1001 Espressif USB JTAG/serial debug unit`, `/dev/ttyACM0`,
  stable path `/dev/serial/by-id/usb-Espressif_USB_JTAG_serial_debug_unit_AC:27:6E:46:55:B4-if00`. No driver is needed on Linux.
- esptool v5.6.0 `flash-id`: ESP32-C3 (QFN32) revision v0.4, 160 MHz, 40 MHz crystal, embedded flash **4 MB (XMC, manufacturer 0x46, device 0x4016)**,
  USB mode USB-Serial/JTAG, MAC `ac:27:6e:46:55:b4`.
- Full 4 MB flash read to `c3-factory-flash-4MB.bin` (sha256 starts `3501df7e63899c8862f3767b`). The flash is blank (24 non-0xFF bytes): no firmware on the board.
  Restore with `esptool --port <port> write-flash 0 c3-factory-flash-4MB.bin` (this just writes the blank image back).
- The board boots and talks USB with the E28 and PCB attached (at least on this power-up).

## Not yet known / not tested
- Is the E28 fitted, and is the antenna connected? Nothing has been transmitted (no firmware is running).
- Which pin mapping was built: as drawn in the schematic (RXEN GPIO8, TXEN GPIO9, DIO1 GPIO2, NRESET GPIO0, BUSY GPIO1, SCK GPIO3, MISO GPIO4, MOSI GPIO5, NSS GPIO7, fan/POC GPIO10)
  or the recommended remap.
- How GPIO20/21 (UART0, CRSF input) are reachable for the USB-UART adapter (the schematic had no header: finding C1).
- E28 supply: with USB only, the Super Mini's own regulator feeds the 3V3 rail (U1's output is not powered); its current rating is unknown against the module's 580 mA transmit peak.
- Cold-boot repeatability (unplug and replug several times), since three strapping pins carry module signals.
- ELRS version on your receiver.

## Flashed 2026-11-02: ELRS 4.1.0 TX (Unified_ESP32C3_2400_TX_via_UART)
- Built from ExpressLRS tag 4.1.0 (commit a9d4a9cb, same as your Boxer/BR3 hash) with PlatformIO; patched with the as-drawn layout
  (`c3_supermini_e28_USER_PCB_as_drawn.hardware.json`) and binding phrase `dronefalcon`
  (a 2.4 GHz receiver must use this phrase). Files in `elrs_4.1.0_flashed/` (bootloader 0x0, partitions 0x8000, boot_app0 0xe000, firmware 0x10000; flash hash verified).
- Not tested: radio chip init, RF output, link. Link to your BR3 is impossible: it is 900 MHz, this radio is 2.4 GHz.
- Restore blank: `esptool --chip esp32c3 --port <port> write-flash 0 ../c3-factory-flash-4MB.bin`

## 2026-11-02 bring-up result: SX1281 not answering
- ELRS TX boots and answers CRSF ping over GPIO20/21 (UART OK), but the TX hotspot appears within ~7 s of every boot = ELRS `radioFailed` state
  (devWIFI starts Wi-Fi for connectionState > FAILURE_STATES regardless of the auto-on interval). The Wi-Fi interval setting is not the cause.
- Read-only SPI probe (as-drawn pins, NSS7 SCK3 MISO4 MOSI5 RST0 BUSY1 DIO1 2): after hardware reset BUSY never goes low, GetStatus = 00 00,
  ReadRegister 0x0153 = 00 00 00 00 00 00 (expected 0xA9B5/0xA9B7).
- Pin diagnostics: BUSY(GPIO1) floating (not driven), DIO1(GPIO2) low, MISO floating with NSS high. BUSY did not respond to NRESET.
- Conclusion: the module is not powered, or BUSY/NRESET/SPI wires are not reaching a live SX1281. Needs multimeter checks (VCC at E28, continuity).
- Probe source: `sx1281_probe_src/`. ELRS TX firmware restored after the probe.
- Brute-force pin search (every assignment of RST/NSS/SCK/MOSI/MISO over GPIO 0,1,2,3,4,5,7; bit-banged, weakest drive): chip found on 0 of 2520 assignments.
  So the SX1281 does not answer on any wiring of those pins: strongest suspect is that the E28 is unpowered (VCC/GND not reaching the module) or the module/breakout is dead.
  Next: measure VCC-GND at the E28 pins with a multimeter.

## 2026-11-02 RESOLVED: link up (my pin mapping was wrong)
- Schematic net labels sit ABOVE their wires. Real mapping: NRESET=GPIO1, BUSY=GPIO2, DIO1=GPIO3, SCK=GPIO4, MISO=GPIO5, MOSI=GPIO6, NSS=7, RXEN=8, TXEN=9 (GPIO0 unconnected stub).
  The earlier "as drawn" file (rst0 busy1 dio1 2 sck3 miso4 mosi5) was off by one row; `c3_supermini_e28_USER_PCB_as_drawn.hardware.json` now holds the corrected values.
- Probe with the corrected mapping: SX1281 version reg 0xA9B7, status 0x40 (standby). Re-flashed ELRS 4.1.0 with phrase `dronefalcon`.
- Result: no TX hotspot, link LQ 100%, SNR 13 dB, telemetry from the FC (attitude, flight mode, battery, 0xD3 optrange, 0xD4 motor). PC sender: 250 Hz class, max interval 11 ms, 0 CRC errors.
- Receiver (GEPRC True Diversity 2.4GHz, 4.1.0) uses the same UID 28,105,148,129,1,68, CRSF 420000.
- `decode_link_statistics` fixed: ELRS 4.x sends signed RSSI bytes (208 -> -48 dBm).
