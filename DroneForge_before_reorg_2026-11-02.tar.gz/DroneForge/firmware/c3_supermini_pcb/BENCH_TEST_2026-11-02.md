# Bench test 2026-11-02 (props OFF, FC on USB read-only MSP, DIY C3+E28 TX -> GEPRC 2.4 GHz RX -> Matek H743)

1. Channel check (disarmed sweep): FC received roll/pitch/yaw 1244..1756 us following the PC sender, throttle 988 (min), arm channel low. PASS.
2. Arming: first attempts did NOT arm. Arming-disable flags (MSP_STATUS_EX) showed BADRX (post-failsafe recovery) + ARMSWITCH (arm switch went high while blocked).
   With arm held low the blockers cleared in about 4 s (mask 0). Added `--arm-after SECONDS` to `nimbus_pc send` demo modes.
3. Armed with `send --demo idle --arm --arm-after 10 --allow-arm`: armed=1 about 12 s in, motors idle 1056..1079.
4. Failsafe: sender killed with SIGKILL at 22.3 s (hard link loss, no safe frame): FC still armed at 23.2 s, disarmed by 25.1 s (<= ~2.8 s), motors back to 1000, throttle channel 885/1000. PASS.
- Not tested: real flight; 0xD3 sensor watchdog trigger (`--watch-optrange`) with a blocked sensor; RSSI/LQ at range; TX power levels; E28 PA output.
- Scripts used live in the job tmp dir (bench_rc.py, bench_arm.py, bench_flags2.py): read-only MSP 101/104/105/150 only.
