// nimbus_core 2.9.0 (Ghidra 12.1.4). Addresses are Ghidra-based (file vaddr + 0x100000).
// ==== 001b38c0 droneforge::core::control::CrsfMapper::StickToCrsf size=73

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* droneforge::core::control::CrsfMapper::StickToCrsf(float) */

void droneforge::core::control::CrsfMapper::StickToCrsf(float param_1)

{
  float fVar1;
  float fVar2;
  
  fVar2 = DAT_007a9860;
  if (DAT_007a9860 <= param_1) {
    fVar2 = param_1;
  }
  fVar1 = DAT_007a9864;
  if (fVar2 <= DAT_007a9864) {
    fVar1 = fVar2;
  }
  fVar1 = fVar1 * _DAT_007a98f0 + DAT_007a98f4;
  fVar2 = DAT_007a98d8;
  if (DAT_007a98d8 <= fVar1) {
    fVar2 = fVar1;
  }
  fVar1 = DAT_007a98e4;
  if (fVar2 <= DAT_007a98e4) {
    fVar1 = fVar2;
  }
  (*(code *)PTR_lroundf_008cac30)(fVar1);
  return;
}


// ==== 001b3910 droneforge::core::control::CrsfMapper::Throttle01ToCrsf size=64

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* droneforge::core::control::CrsfMapper::Throttle01ToCrsf(float) */

void droneforge::core::control::CrsfMapper::Throttle01ToCrsf(float param_1)

{
  float fVar1;
  float fVar2;
  
  fVar2 = 0.0;
  if (0.0 <= param_1) {
    fVar2 = param_1;
  }
  fVar1 = DAT_007a9864;
  if (fVar2 <= DAT_007a9864) {
    fVar1 = fVar2;
  }
  fVar1 = fVar1 * _DAT_007a98e0 + DAT_007a98d8;
  fVar2 = DAT_007a98d8;
  if (DAT_007a98d8 <= fVar1) {
    fVar2 = fVar1;
  }
  fVar1 = DAT_007a98e4;
  if (fVar2 <= DAT_007a98e4) {
    fVar1 = fVar2;
  }
  (*(code *)PTR_lroundf_008cac30)(fVar1);
  return;
}


// ==== 001b3950 droneforge::core::control::CrsfMapper::CrsfToThrottle01 size=49

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* droneforge::core::control::CrsfMapper::CrsfToThrottle01(unsigned short) */

float droneforge::core::control::CrsfMapper::CrsfToThrottle01(ushort param_1)

{
  uint uVar1;
  uint uVar2;
  undefined2 in_register_0000003a;
  
  uVar1 = 0xac;
  if (0xac < CONCAT22(in_register_0000003a,param_1)) {
    uVar1 = CONCAT22(in_register_0000003a,param_1);
  }
  uVar2 = 0x713;
  if (uVar1 < 0x713) {
    uVar2 = uVar1;
  }
  return (float)(int)(short)((short)uVar2 + -0xac) / _DAT_007a98e0;
}


// ==== 001b3990 droneforge::core::control::CrsfMapper::AngleDegToCrsf size=260

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* droneforge::core::control::CrsfMapper::AngleDegToCrsf(float) */

void droneforge::core::control::CrsfMapper::AngleDegToCrsf(float param_1)

{
  float fVar1;
  float fVar2;
  
  fVar2 = DAT_007a98f4;
  if ((float)(_DAT_007a5240 & (uint)param_1) < DAT_007a98ec) goto LAB_001b3a74;
  fVar1 = 0.0;
  fVar2 = ((DAT_007a9900 * param_1) / DAT_007a9904) * _DAT_007a9908;
  if (param_1 <= 0.0) {
    fVar2 = DAT_007a990c - fVar2;
    if (0.0 <= fVar2) {
      if (fVar2 < 0.0) {
        fVar2 = (float)(*(code *)PTR_sqrtf_008caee0)(fVar2);
      }
      else {
        fVar2 = SQRT(fVar2);
      }
      fVar1 = DAT_007a9910 - fVar2;
      goto LAB_001b3a44;
    }
  }
  else {
    fVar2 = fVar2 + DAT_007a990c;
    if (fVar2 < 0.0) {
      fVar1 = (float)(*(code *)PTR_sqrtf_008caee0)(fVar2);
      fVar1 = fVar1 + _LAB_007a9917_1;
    }
    else {
      fVar1 = SQRT(fVar2) + _LAB_007a9917_1;
    }
LAB_001b3a44:
    fVar1 = fVar1 / _DAT_007a9914;
  }
  fVar2 = DAT_007a9860;
  if (DAT_007a9860 <= fVar1) {
    fVar2 = fVar1;
  }
  fVar1 = DAT_007a9864;
  if (fVar2 <= DAT_007a9864) {
    fVar1 = fVar2;
  }
  fVar2 = fVar1 * _DAT_007a98f0 + DAT_007a98f4;
LAB_001b3a74:
  fVar1 = DAT_007a98d8;
  if (DAT_007a98d8 <= fVar2) {
    fVar1 = fVar2;
  }
  fVar2 = DAT_007a98e4;
  if (fVar1 <= DAT_007a98e4) {
    fVar2 = fVar1;
  }
  (*(code *)PTR_lroundf_008cac30)(fVar2);
  return;
}


// ==== 001b3aa0 droneforge::core::control::CrsfMapper::AngleDegToCrsf size=386

/* WARNING: Removing unreachable block (ram,0x001b3b7c) */
/* WARNING: Removing unreachable block (ram,0x001b3ba9) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* droneforge::core::control::CrsfMapper::AngleDegToCrsf(float,
   droneforge::core::control::CrsfMapper::AngleCurveConfig const&) */

void droneforge::core::control::CrsfMapper::AngleDegToCrsf(float param_1,AngleCurveConfig *param_2)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  
  fVar2 = DAT_007a98f4;
  if (DAT_007a98ec <= (float)(_DAT_007a5240 & (uint)param_1)) {
    fVar3 = *(float *)param_2 * _DAT_007a9874;
    fVar2 = *(float *)(param_2 + 8);
    if (*(float *)(param_2 + 8) <= DAT_007a98f8) {
      fVar2 = DAT_007a98f8;
    }
    fVar2 = (param_1 * *(float *)(param_2 + 4) * _DAT_007a9874) / fVar2;
    fVar1 = 0.0;
    fVar4 = *(float *)(param_2 + 4) * _DAT_007a9874 - fVar3;
    if (param_1 <= 0.0) {
      if ((DAT_007a98b0 < (float)(_DAT_007a5240 & (uint)fVar4)) &&
         (fVar2 = fVar3 * fVar3 - DAT_007a98fc * fVar4 * fVar2, 0.0 <= fVar2)) {
        fVar1 = (fVar3 - SQRT(fVar2)) / (fVar4 + fVar4);
      }
    }
    else if ((DAT_007a98b0 < (float)(_DAT_007a5240 & (uint)fVar4)) &&
            (fVar2 = fVar3 * fVar3 + DAT_007a98fc * fVar4 * fVar2, 0.0 <= fVar2)) {
      fVar1 = (SQRT(fVar2) - fVar3) / (fVar4 + fVar4);
    }
    fVar2 = DAT_007a9860;
    if (DAT_007a9860 <= fVar1) {
      fVar2 = fVar1;
    }
    fVar3 = DAT_007a9864;
    if (fVar2 <= DAT_007a9864) {
      fVar3 = fVar2;
    }
    fVar2 = fVar3 * _DAT_007a98f0 + DAT_007a98f4;
  }
  fVar3 = DAT_007a98d8;
  if (DAT_007a98d8 <= fVar2) {
    fVar3 = fVar2;
  }
  fVar2 = DAT_007a98e4;
  if (fVar3 <= DAT_007a98e4) {
    fVar2 = fVar3;
  }
  (*(code *)PTR_lroundf_008cac30)(fVar2);
  return;
}


// ==== 002d2000 droneforge::core::io::SerialLinkConnection::ConnectByPathLocked size=1889

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* droneforge::core::io::SerialLinkConnection::ConnectByPathLocked(std::__cxx11::string const&, int)
    */

undefined8 __thiscall
droneforge::core::io::SerialLinkConnection::ConnectByPathLocked
          (SerialLinkConnection *this,string *param_1,int param_2)

{
  ulong uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined8 uVar5;
  int iVar6;
  int iVar7;
  pthread_mutex_t *ppVar8;
  undefined1 *puVar9;
  undefined8 uVar10;
  ulong uVar11;
  long lVar12;
  long in_FS_OFFSET;
  bool bVar13;
  allocator local_179;
  long *local_178 [2];
  long local_168 [2];
  long *local_158 [2];
  long local_148 [2];
  long *local_138 [2];
  long local_128 [2];
  long *local_118 [2];
  long local_108 [2];
  pthread_mutex_t *local_f8;
  ulong uStack_f0;
  undefined1 local_e8 [56];
  long *local_b0 [2];
  long local_a0 [2];
  pthread_mutex_t *local_90;
  ulong local_88;
  undefined1 local_80 [16];
  undefined8 local_70 [2];
  undefined8 local_60 [2];
  pthread_mutex_t *local_50;
  undefined8 local_48;
  undefined8 local_40;
  undefined8 local_30;
  undefined4 extraout_var;
  
  local_30 = *(long *)(in_FS_OFFSET + 0x28);
  ppVar8 = (pthread_mutex_t *)(this + 0x28);
  if ((PTR___pthread_key_create_008cae00 != (undefined *)0x0) &&
     (iVar6 = pthread_mutex_lock(ppVar8), iVar6 != 0)) {
    if (*(long *)(in_FS_OFFSET + 0x28) != local_30) goto LAB_002d26df;
    (*(code *)PTR___throw_system_error_008ca858)(iVar6);
LAB_002d26ff:
    if (*(long *)(in_FS_OFFSET + 0x28) == local_30) {
      uVar10 = (*(code *)PTR___throw_length_error_008ca788)("basic_string::append");
      if (PTR___pthread_key_create_008cae00 != (undefined *)0x0) {
        pthread_mutex_unlock(local_90);
      }
      if (*(long *)(in_FS_OFFSET + 0x28) == local_30) {
                    /* WARNING: Subroutine does not return */
        _Unwind_Resume(uVar10);
      }
    }
    goto LAB_002d26df;
  }
  if (-1 < *(int *)(this + 0x50)) {
    (*(code *)PTR_close_008cafb8)();
    *(undefined4 *)(this + 0x50) = 0xffffffff;
  }
  bVar13 = PTR___pthread_key_create_008cae00 != (undefined *)0x0;
  *(undefined8 *)(this + 0x80) = 0;
  **(undefined1 **)(this + 0x78) = 0;
  *(undefined4 *)(this + 0x98) = 0x1c200;
  if (bVar13) {
    pthread_mutex_unlock(ppVar8);
  }
  if (param_2 == 0x1c200) {
    iVar6 = (*(code *)PTR_open_008ca8b8)(*(undefined8 *)param_1,0x102);
    if (-1 < iVar6) {
      iVar7 = (*(code *)PTR_tcflush_008cad58)(iVar6,2);
      if (iVar7 == 0) {
        local_e8._32_4_ = 0;
        local_e8._36_8_ = 0;
        local_e8._16_8_ = 0;
        local_e8._24_4_ = 0;
        local_e8._28_4_ = 0;
        local_e8._0_8_ = 0;
        local_e8._8_8_ = 0;
                    /* try { // try from 002d2297 to 003d2314 has its CatchHandler @ 002d1780 */
        local_f8 = (pthread_mutex_t *)0x0;
        uStack_f0 = 0;
        iVar7 = (*(code *)PTR_tcgetattr_008caaf8)(iVar6,&local_f8);
        if (iVar7 == 0) {
          (*(code *)PTR_cfmakeraw_008cac70)(&local_f8);
          uStack_f0 = uStack_f0 & 0xffffffff7ffff20f | 0x8b0;
          local_e8._6_2_ = 1;
          iVar7 = (*(code *)PTR_cfsetispeed_008ca7d0)(&local_f8,0x1002);
          if ((iVar7 != 0) ||
             (iVar7 = (*(code *)PTR_cfsetospeed_008caac8)(&local_f8,0x1002), iVar7 != 0)) {
            ppVar8 = (pthread_mutex_t *)(*(code *)PTR_operator_new_008caa38)(0x15);
            uVar10 = uRam00000000007b2e72;
            ppVar8->__align = _LAB_007b2e6a;
            uVar5 = uRam00000000007b2e72;
            uRam00000000007b2e72._0_4_ = (undefined4)uVar10;
            uRam00000000007b2e72._4_4_ = SUB84(uVar10,4);
            uVar2 = uRam00000000007b2e72._4_4_;
            *(undefined4 *)((long)ppVar8 + 8) = (undefined4)uRam00000000007b2e72;
            uRam00000000007b2e72 = uVar5;
            *(undefined4 *)((long)ppVar8 + 0xc) = uVar2;
            (ppVar8->__data).__kind = 0x29303032;
            ppVar8->__size[0x14] = '\0';
            io::(anonymous_namespace)::ErrnoString((string *)local_138);
            SetLastError(this,local_138);
            if (local_138[0] != local_128) {
              (*(code *)PTR_operator_delete_008caa50)(local_138[0],local_128[0] + 1);
            }
            lVar12 = 0x15;
            goto LAB_002d2138;
          }
          iVar7 = (*(code *)PTR_tcsetattr_008cab88)(iVar6,0,&local_f8);
          if (iVar7 == 0) {
            local_90 = (pthread_mutex_t *)CONCAT44(local_90._4_4_,6);
            (*(code *)PTR_ioctl_008caca8)(iVar6,0x5417,&local_90);
            iVar7 = (*(code *)PTR_tcflow_008cae98)(iVar6,1);
            if (iVar7 == 0) {
              std::lock_guard<std::mutex>::lock_guard
                        ((lock_guard<std::mutex> *)&local_90,(mutex *)&ppVar8->__data);
              *(int *)(this + 0x50) = iVar6;
              std::__cxx11::string::_M_assign((string *)(this + 0x78),param_1);
              bVar13 = PTR___pthread_key_create_008cae00 != (undefined *)0x0;
              *(undefined4 *)(this + 0x98) = 0x1c200;
              *(undefined8 *)(this + 0x60) = 0;
              puVar9 = *(undefined1 **)(this + 0x58);
              *puVar9 = 0;
              if (bVar13) {
                iVar6 = pthread_mutex_unlock(local_90);
                puVar9 = (undefined1 *)CONCAT44(extraout_var,iVar6);
              }
              if (*(long *)(in_FS_OFFSET + 0x28) == local_30) {
                return CONCAT71((int7)((ulong)puVar9 >> 8),1);
              }
              goto LAB_002d26df;
            }
            std::__cxx11::string::string<std::allocator<char>>
                      ((string *)&local_90,"tcflow(TCOON)",&local_179);
            io::(anonymous_namespace)::ErrnoString((string *)local_178);
            SetLastError(this,local_178);
            if (local_178[0] != local_168) goto LAB_002d264d;
          }
          else {
            std::__cxx11::string::string<std::allocator<char>>
                      ((string *)&local_90,"tcsetattr",&local_179);
            io::(anonymous_namespace)::ErrnoString((string *)local_158);
            SetLastError(this,local_158);
            local_168[0] = local_148[0];
            local_178[0] = local_158[0];
            if (local_158[0] != local_148) {
LAB_002d264d:
              (*(code *)PTR_operator_delete_008caa50)(local_178[0],local_168[0] + 1);
            }
          }
          if (local_90 != (pthread_mutex_t *)local_80) goto LAB_002d233b;
        }
        else {
          local_80._0_8_ = 0x7474617465676374;
          local_80._8_2_ = 0x72;
          local_88 = 9;
          local_90 = (pthread_mutex_t *)local_80;
          io::(anonymous_namespace)::ErrnoString((string *)local_118);
          SetLastError(this,local_118);
                    /* try { // try from 002d2315 to 003d231a has its CatchHandler @ 002d2ad6 */
          if (local_118[0] != local_108) {
                    /* try { // try from 002d231b to 003d23ef has its CatchHandler @ 002d1780 */
            (*(code *)PTR_operator_delete_008caa50)(local_118[0],local_108[0] + 1);
          }
          if (local_90 != (pthread_mutex_t *)local_80) {
LAB_002d233b:
            lVar12 = local_80._0_8_ + 1;
            ppVar8 = local_90;
            goto LAB_002d2138;
          }
        }
      }
      else {
        ppVar8 = (pthread_mutex_t *)(*(code *)PTR_operator_new_008caa38)(0x13);
        uVar10 = uRam00000000007b2e55;
        ppVar8->__align = _LAB_007b2e4d;
        uVar5 = uRam00000000007b2e55;
        uRam00000000007b2e55._0_4_ = (undefined4)uVar10;
        _UNK_007b2e59 = SUB84(uVar10,4);
        uVar2 = _UNK_007b2e59;
        *(undefined4 *)((long)ppVar8 + 8) = (undefined4)uRam00000000007b2e55;
        uRam00000000007b2e55 = uVar5;
        *(undefined4 *)((long)ppVar8 + 0xc) = uVar2;
        *(undefined2 *)&(ppVar8->__data).__kind = 0x2948;
        ppVar8->__size[0x12] = '\0';
        io::(anonymous_namespace)::ErrnoString((string *)local_b0);
        SetLastError(this,local_b0);
        if (local_b0[0] != local_a0) {
          (*(code *)PTR_operator_delete_008caa50)(local_b0[0],local_a0[0] + 1);
        }
        lVar12 = 0x13;
LAB_002d2138:
        (*(code *)PTR_operator_delete_008caa50)(ppVar8,lVar12);
      }
      (*(code *)PTR_close_008cafb8)(iVar6);
      if (*(long *)(in_FS_OFFSET + 0x28) == local_30) {
        return 0;
      }
      goto LAB_002d26df;
    }
    std::__str_concat<std::__cxx11::string>
              (&local_90,&LAB_007b2e46_1,5,*(undefined8 *)param_1,*(undefined8 *)(param_1 + 8),
               &local_179);
    if (local_88 == 0x7fffffffffffffff) goto LAB_002d26ff;
    uVar1 = local_88 + 1;
    uVar11 = 0xf;
    if (local_90 != (pthread_mutex_t *)local_80) {
      uVar11 = local_80._0_8_;
    }
    if (uVar11 < uVar1) {
      std::__cxx11::string::_M_mutate((string *)&local_90,local_88,0,")",1);
    }
    else {
      local_90->__size[local_88] = ')';
    }
    local_90->__size[uVar1] = '\0';
    if (local_90 == (pthread_mutex_t *)local_80) {
      lVar12 = local_88 + 2;
      local_f8 = (pthread_mutex_t *)local_e8;
      local_88 = uVar1;
      (*(code *)PTR_memcpy_008ca960)((pthread_mutex_t *)local_e8,(pthread_mutex_t *)local_80,lVar12)
      ;
    }
    else {
      local_f8 = local_90;
      local_e8._0_8_ = local_80._0_8_;
    }
    local_88 = 0;
    local_80._0_8_ = local_80._0_8_ & 0xffffffffffffff00;
    uStack_f0 = uVar1;
    local_90 = (pthread_mutex_t *)local_80;
                    /* try { // try from 002d23f0 to 003d23ff has its CatchHandler @ 002d2a38 */
    io::(anonymous_namespace)::ErrnoString((string *)local_70);
                    /* try { // try from 002d2400 to 003d292d has its CatchHandler @ 002d1780 */
    SetLastError(this,local_70);
    if ((undefined8 *)local_70[0] != local_60) {
      (*(code *)PTR_operator_delete_008caa50)
                (local_70[0],
                 (undefined1 *)((long)&((__pthread_internal_list *)local_60[0])->__prev + 1));
    }
    if (local_f8 != (pthread_mutex_t *)local_e8) {
      (*(code *)PTR_operator_delete_008caa50)(local_f8,local_e8._0_8_ + 1);
    }
    uVar10 = local_80._0_8_;
    ppVar8 = local_90;
    if (local_90 != (pthread_mutex_t *)local_80) goto LAB_002d245c;
  }
  else {
    local_50 = (pthread_mutex_t *)(*(code *)PTR_operator_new_008caa38)(0x24);
    uVar10 = _UNK_007b2e2b;
    local_50->__align = _DAT_007b2e23;
    uVar5 = _UNK_007b2e2b;
    _UNK_007b2e2b = (undefined4)uVar10;
    _UNK_007b2e2f = SUB84(uVar10,4);
    uVar2 = _UNK_007b2e2f;
    *(undefined4 *)((long)local_50 + 8) = _UNK_007b2e2b;
    _UNK_007b2e2b = uVar5;
    uVar4 = _LAB_007b2e3f;
    uVar3 = _UNK_007b2e3b;
    iVar6 = _UNK_007b2e37;
    *(undefined4 *)((long)local_50 + 0xc) = uVar2;
    (local_50->__data).__kind = _DAT_007b2e33;
    (local_50->__data).__spins = iVar6;
    *(undefined4 *)&(local_50->__data).__list.__prev = uVar3;
    *(undefined4 *)((long)&(local_50->__data).__list.__prev + 4) = uVar4;
    local_40 = 0x23;
    *(undefined4 *)((long)&(local_50->__data).__list.__prev + 7) = 0x3176206e;
    local_48 = 0x23;
    local_50->__size[0x23] = '\0';
    SetLastError(this,&local_50);
    uVar10 = local_40;
    ppVar8 = local_50;
    if (local_50 != (pthread_mutex_t *)&stack0xffffffffffffffc0) {
LAB_002d245c:
      (*(code *)PTR_operator_delete_008caa50)(ppVar8,uVar10 + 1);
    }
  }
  if (*(long *)(in_FS_OFFSET + 0x28) == local_30) {
    return 0;
  }
LAB_002d26df:
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail();
}


// ==== 002e3430 droneforge::core::crsf::CrsfTransmitEncoder::EncodeControlFrame size=758

/* droneforge::core::crsf::CrsfTransmitEncoder::EncodeControlFrame(droneforge::core::runtime::RcChannelsCommand
   const&, std::vector<unsigned char, std::allocator<unsigned char> >*) const */

undefined8 __thiscall
droneforge::core::crsf::CrsfTransmitEncoder::EncodeControlFrame
          (CrsfTransmitEncoder *this,RcChannelsCommand *param_1,vector *param_2)

{
  byte *pbVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  long lVar4;
  uint uVar5;
  uint uVar6;
  ulong uVar7;
  long lVar8;
  int iVar9;
  uint uVar10;
  ulong uVar11;
  long in_FS_OFFSET;
  undefined8 local_40;
  undefined4 local_38;
  undefined4 local_34;
  undefined2 local_30;
  undefined8 local_2e;
  undefined4 local_26;
  undefined2 local_22;
  long local_20;
  
  lVar4 = *(long *)(in_FS_OFFSET + 0x28);
  local_20 = lVar4;
  if (param_2 != (vector *)0x0) {
    local_34 = 0x3e003e0;
    local_2e = 0x3e003e003e003e0;
    local_26 = 0x3e003e0;
    local_22 = 0x3e0;
    local_40 = *(undefined8 *)param_1;
    local_38 = *(undefined4 *)(param_1 + 8);
    local_30 = *(undefined2 *)(param_1 + 0xc);
    puVar2 = *(undefined8 **)param_2;
    if ((ulong)(*(long *)(param_2 + 0x10) - (long)puVar2) < 0x1a) {
      puVar3 = (undefined8 *)(*(code *)PTR_operator_new_008caa38)(0x1a);
      *puVar3 = 0;
      puVar3[1] = 0;
      *(undefined8 *)((long)puVar3 + 10) = 0;
      *(undefined8 *)((long)puVar3 + 0x12) = 0;
      *(undefined8 **)param_2 = puVar3;
      *(long *)(param_2 + 8) = (long)puVar3 + 0x1a;
      *(long *)(param_2 + 0x10) = (long)puVar3 + 0x1a;
      if (puVar2 != (undefined8 *)0x0) {
        (*(code *)PTR_operator_delete_008caa50)(puVar2);
      }
    }
    else {
      puVar3 = *(undefined8 **)(param_2 + 8);
      uVar7 = (long)puVar3 - (long)puVar2;
      if (uVar7 < 0x1a) {
        if (puVar3 != puVar2) {
          (*(code *)PTR_memset_008ca790)(puVar2,0,uVar7);
          puVar3 = *(undefined8 **)(param_2 + 8);
        }
        (*(code *)PTR_memset_008ca790)();
        *(ulong *)(param_2 + 8) = (long)puVar3 + (0x1a - uVar7);
      }
      else {
        *(undefined8 *)((long)puVar2 + 10) = 0;
        *(undefined8 *)((long)puVar2 + 0x12) = 0;
        *puVar2 = 0;
        puVar2[1] = 0;
        if (*(long *)(param_2 + 8) != (long)puVar2 + 0x1a) {
          *(long *)(param_2 + 8) = (long)puVar2 + 0x1a;
        }
      }
    }
    **(undefined1 **)param_2 = 200;
    *(undefined1 *)(*(long *)param_2 + 1) = 0x18;
    *(undefined1 *)(*(long *)param_2 + 2) = 0x16;
    lVar4 = *(long *)param_2;
    *(undefined8 *)(lVar4 + 3) = 0;
    *(undefined8 *)(lVar4 + 0xb) = 0;
    *(undefined8 *)(lVar4 + 0x11) = 0;
    uVar7 = 0xb;
    lVar8 = 0;
    do {
      uVar11 = uVar7 - 0xb >> 3;
      uVar5 = (uint)(uVar7 - 0xb) & 6;
      iVar9 = (*(ushort *)((long)&local_40 + lVar8) & 0x7ff) << (sbyte)uVar5;
      pbVar1 = (byte *)(lVar4 + 3 + uVar11);
      *pbVar1 = *pbVar1 | (byte)iVar9;
      pbVar1 = (byte *)(lVar4 + 4 + uVar11);
      *pbVar1 = *pbVar1 | (byte)((uint)iVar9 >> 8);
      if (uVar5 == 6) {
        pbVar1 = (byte *)(lVar4 + 5 + uVar11);
        *pbVar1 = *pbVar1 | (byte)((uint)iVar9 >> 0x10);
      }
      uVar11 = uVar7 >> 3;
      uVar6 = (uint)uVar7 & 7;
      uVar10 = (*(ushort *)((long)&local_40 + lVar8 + 2) & 0x7ff) << (sbyte)uVar6;
      pbVar1 = (byte *)(lVar4 + 3 + uVar11);
      *pbVar1 = *pbVar1 | (byte)uVar10;
      pbVar1 = (byte *)(lVar4 + 4 + uVar11);
      *pbVar1 = *pbVar1 | (byte)(uVar10 >> 8);
      uVar5 = uVar10;
      if (5 < uVar6) {
        uVar5 = uVar10 >> 0x10;
        pbVar1 = (byte *)(lVar4 + 5 + uVar11);
        *pbVar1 = *pbVar1 | (byte)(uVar10 >> 0x10);
      }
      this = (CrsfTransmitEncoder *)(ulong)uVar5;
      lVar8 = lVar8 + 4;
      uVar7 = uVar7 + 0x16;
    } while (lVar8 != 0x20);
    lVar4 = *(long *)param_2;
    *(undefined *)(lVar4 + 0x19) =
         (&DAT_007f00f0)
         [*(byte *)(lVar4 + 0x18) ^
          (&DAT_007f00f0)
          [*(byte *)(lVar4 + 0x17) ^
           (&DAT_007f00f0)
           [*(byte *)(lVar4 + 0x16) ^
            (&DAT_007f00f0)
            [*(byte *)(lVar4 + 0x15) ^
             (&DAT_007f00f0)
             [*(byte *)(lVar4 + 0x14) ^
              (&DAT_007f00f0)
              [*(byte *)(lVar4 + 0x13) ^
               (&DAT_007f00f0)
               [*(byte *)(lVar4 + 0x12) ^
                (&DAT_007f00f0)
                [*(byte *)(lVar4 + 0x11) ^
                 (&DAT_007f00f0)
                 [*(byte *)(lVar4 + 0x10) ^
                  (&DAT_007f00f0)
                  [*(byte *)(lVar4 + 0xf) ^
                   (&DAT_007f00f0)
                   [*(byte *)(lVar4 + 0xe) ^
                    (&DAT_007f00f0)
                    [*(byte *)(lVar4 + 0xd) ^
                     (&DAT_007f00f0)
                     [*(byte *)(lVar4 + 0xc) ^
                      (&DAT_007f00f0)
                      [*(byte *)(lVar4 + 0xb) ^
                       (&DAT_007f00f0)
                       [*(byte *)(lVar4 + 10) ^
                        (&DAT_007f00f0)
                        [*(byte *)(lVar4 + 9) ^
                         (&DAT_007f00f0)
                         [*(byte *)(lVar4 + 8) ^
                          (&DAT_007f00f0)
                          [*(byte *)(lVar4 + 7) ^
                           (&DAT_007f00f0)
                           [*(byte *)(lVar4 + 6) ^
                            (&DAT_007f00f0)
                            [*(byte *)(lVar4 + 5) ^
                             (&DAT_007f00f0)
                             [*(byte *)(lVar4 + 4) ^
                              (&DAT_007f00f0)
                              [*(byte *)(lVar4 + 3) ^ (&DAT_007f00f0)[*(byte *)(lVar4 + 2)]]]]]]]]]]
                     ]]]]]]]]]]]]];
  }
  if (*(long *)(in_FS_OFFSET + 0x28) == local_20) {
    return CONCAT71((int7)((ulong)lVar4 >> 8),param_2 != (vector *)0x0);
  }
                    /* WARNING: Subroutine does not return */
  __stack_chk_fail(this);
}


// ==== 002e3730 droneforge::core::crsf::CrsfTransmitEncoder::EncodeReceiverBindFrame size=22

/* droneforge::core::crsf::CrsfTransmitEncoder::EncodeReceiverBindFrame(std::vector<unsigned char,
   std::allocator<unsigned char> >*) const */

void __thiscall
droneforge::core::crsf::CrsfTransmitEncoder::EncodeReceiverBindFrame
          (CrsfTransmitEncoder *this,vector *param_1)

{
  utils::EncodeCommandFrame((utils *)&working_state_cur_put_buffer_simd,1,0,0,param_1);
  return;
}


// ==== 002e3750 droneforge::core::crsf::utils::EncodeCommandFrame size=605

/* droneforge::core::crsf::utils::EncodeCommandFrame(droneforge::core::crsf::CommandType,
   droneforge::core::crsf::SubCommandType, std::span<unsigned char const, 18446744073709551615ul>,
   std::vector<unsigned char, std::allocator<unsigned char> >*) */

bool __thiscall
droneforge::core::crsf::utils::EncodeCommandFrame
          (undefined1 param_1,undefined1 param_2,undefined1 *param_3,long param_4,long *param_5)

{
  long lVar1;
  ulong uVar2;
  long lVar3;
  byte *pbVar4;
  ulong uVar5;
  ulong uVar6;
  byte bVar7;
  long lVar8;
  uint uVar9;
  
  if (param_5 == (long *)0x0) goto LAB_002e397a;
  uVar9 = (int)param_4 + 7;
  uVar2 = (ulong)uVar9 & 0xff;
  uVar6 = uVar2 + 2;
  lVar1 = *param_5;
  lVar8 = param_5[2];
  if ((ulong)(lVar8 - lVar1) < uVar6) {
    lVar3 = (*(code *)PTR_operator_new_008caa38)(uVar6);
    (*(code *)PTR_memset_008ca790)(lVar3,0,uVar6);
    *param_5 = lVar3;
    param_5[1] = lVar3 + uVar6;
    param_5[2] = lVar3 + uVar6;
    if (lVar1 != 0) {
      (*(code *)PTR_operator_delete_008caa50)(lVar1,lVar8 - lVar1);
    }
  }
  else {
    lVar8 = param_5[1];
    lVar3 = uVar6 - (lVar8 - lVar1);
    if (uVar6 < (ulong)(lVar8 - lVar1) || lVar3 == 0) {
      (*(code *)PTR_memset_008ca790)(lVar1,0,uVar6);
      if (param_5[1] != uVar6 + lVar1) {
        param_5[1] = uVar6 + lVar1;
      }
    }
    else {
      if (lVar8 != lVar1) {
        (*(code *)PTR_memset_008ca790)(lVar1,0);
        lVar8 = param_5[1];
      }
      (*(code *)PTR_memset_008ca790)(lVar8,0,lVar3);
      param_5[1] = lVar8 + lVar3;
    }
  }
  *(undefined1 *)*param_5 = 0xee;
  *(char *)(*param_5 + 1) = (char)uVar9;
  *(undefined1 *)(*param_5 + 2) = 0x32;
  *(undefined1 *)(*param_5 + 3) = 0xee;
  *(undefined1 *)(*param_5 + 4) = 0xea;
  *(undefined1 *)(*param_5 + 5) = param_1;
  *(undefined1 *)(*param_5 + 6) = param_2;
                    /* catch() { ... } // from try @ 002e393a with catch @ 002e3880 */
  if (param_4 < 2) {
    if (param_4 == 1) {
                    /* catch() { ... } // from try @ 002e392d with catch @ 002e39a4 */
      *(undefined1 *)(*param_5 + 7) = *param_3;
    }
  }
  else {
    (*(code *)PTR_memmove_008cade0)((undefined1 *)(*param_5 + 7),param_3,param_4);
  }
  uVar6 = uVar2 - 1;
  if (uVar6 == 0) {
    bVar7 = 0;
  }
  else {
    pbVar4 = (byte *)(*param_5 + 2);
    uVar5 = (ulong)((uint)uVar6 & 7);
    if ((byte)((char)param_4 + 5U) < 7) {
      bVar7 = 0;
    }
    else {
      uVar6 = uVar6 & 0xfffffffffffffff8;
      bVar7 = 0;
      do {
                    /* try { // try from 002e392d to 003e3939 has its CatchHandler @ 002e39a4 */
                    /* try { // try from 002e393a to 003e39d4 has its CatchHandler @ 002e3880 */
        bVar7 = (&DAT_007f00f0)
                [pbVar4[7] ^
                 (&DAT_007f00f0)
                 [pbVar4[6] ^
                  (&DAT_007f00f0)
                  [pbVar4[5] ^
                   (&DAT_007f00f0)
                   [pbVar4[4] ^
                    (&DAT_007f00f0)
                    [pbVar4[3] ^
                     (&DAT_007f00f0)
                     [pbVar4[2] ^ (&DAT_007f00f0)[pbVar4[1] ^ (&DAT_007f00f0)[bVar7 ^ *pbVar4]]]]]]]
                ];
        pbVar4 = pbVar4 + 8;
        uVar6 = uVar6 - 8;
      } while (uVar6 != 0);
      if (uVar5 == 0) goto LAB_002e3975;
    }
    uVar6 = 0;
    do {
      bVar7 = (&DAT_007f00f0)[bVar7 ^ pbVar4[uVar6]];
      uVar6 = uVar6 + 1;
    } while (uVar5 != uVar6);
  }
LAB_002e3975:
  *(byte *)(*param_5 + 1 + uVar2) = bVar7;
LAB_002e397a:
  return param_5 != (long *)0x0;
}


