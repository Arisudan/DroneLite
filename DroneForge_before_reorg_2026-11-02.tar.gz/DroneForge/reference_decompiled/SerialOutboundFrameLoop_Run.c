// ==== 002dacd0 droneforge::core::runtime::SerialOutboundFrameLoop::Run size=20905

/* WARNING: Removing unreachable block (ram,0x002df202) */
/* WARNING: Type propagation algorithm not settling */
/* droneforge::core::runtime::SerialOutboundFrameLoop::Run(std::atomic<bool>&) */

void __thiscall
droneforge::core::runtime::SerialOutboundFrameLoop::Run
          (SerialOutboundFrameLoop *this,atomic *param_1)

{
  undefined1 *puVar1;
  short sVar2;
  undefined8 *puVar3;
  long lVar4;
  long lVar5;
  undefined8 uVar6;
  bool bVar7;
  undefined1 auVar8 [16];
  undefined1 auVar9 [16];
  undefined1 auVar10 [16];
  undefined1 auVar11 [16];
  undefined1 auVar12 [16];
  undefined1 auVar13 [16];
  bool bVar14;
  bool bVar15;
  bool bVar16;
  bool bVar17;
  bool bVar18;
  bool bVar19;
  bool bVar20;
  undefined2 uVar21;
  char *pcVar22;
  undefined *puVar23;
  char *pcVar24;
  byte bVar25;
  _Optional_payload_base _Var26;
  undefined1 *puVar27;
  uint uVar28;
  bool bVar29;
  bool bVar30;
  char cVar31;
  byte bVar32;
  undefined1 uVar33;
  byte bVar34;
  int iVar35;
  uint uVar36;
  undefined *puVar37;
  undefined *puVar38;
  undefined *puVar39;
  ulong uVar40;
  undefined8 uVar41;
  undefined8 *puVar42;
  undefined *puVar43;
  char *pcVar44;
  undefined8 uVar45;
  long lVar46;
  undefined1 **ppuVar47;
  long *plVar48;
  long lVar49;
  long *plVar50;
  undefined8 uVar51;
  int *piVar52;
  undefined8 uVar53;
  byte bVar54;
  byte bVar55;
  undefined1 *puVar56;
  byte bVar57;
  undefined8 extraout_RDX;
  undefined8 extraout_RDX_00;
  undefined1 *puVar58;
  code *pcVar59;
  long lVar60;
  int iVar61;
  ulong uVar62;
  long lVar63;
  long *plVar64;
  char *pcVar65;
  undefined1 auVar66 [8];
  char cVar67;
  long in_FS_OFFSET;
  bool bVar68;
  float fVar69;
  undefined1 auVar70 [16];
  undefined1 auVar71 [16];
  undefined1 auVar72 [16];
  undefined1 auVar73 [16];
  undefined1 auVar74 [16];
  undefined1 auVar75 [16];
  uint local_cb4;
  uint local_ca8;
  uint local_ca4;
  bool local_c85;
  long local_c80;
  ulong local_c78;
  long local_c50;
  long local_c40;
  ulong local_c38;
  _Optional_payload_base local_c30;
  long local_c28;
  long local_c20;
  ulong local_c18;
  long local_c10;
  long local_c08;
  long local_c00;
  ulong local_bf8;
  long local_be8;
  ulong local_bd8;
  undefined1 *local_bd0;
  long local_bc8;
  undefined1 *local_bc0;
  long local_bb0;
  long local_b68;
  long lStack_b60;
  long local_b58;
  undefined4 local_b50;
  ushort uStack_b4c;
  undefined2 uStack_b4a;
  ushort local_b48;
  undefined2 uStack_b46;
  undefined2 local_b44;
  char local_b41;
  long local_b40;
  long local_b38;
  long local_b30;
  undefined1 local_b24;
  char local_b23;
  char local_b22;
  char local_b21;
  undefined1 *local_b20;
  long local_b18;
  undefined1 local_b10 [16];
  undefined4 local_b00;
  undefined1 local_af8 [16];
  _Optional_payload_base local_ae2;
  byte local_ae1;
  long local_ae0;
  undefined8 local_ad8;
  uint local_ad0;
  undefined2 local_acc;
  byte local_aca;
  byte local_ac9;
  undefined8 local_ac8;
  undefined4 local_ac0;
  undefined2 local_abc;
  undefined1 local_ab8 [16];
  undefined8 local_aa8;
  undefined1 local_a98 [16];
  char local_a88;
  undefined4 local_a87;
  undefined2 local_a83;
  undefined8 local_a78;
  ulong uStack_a70;
  _Optional_payload_base local_a68;
  byte bStack_a67;
  char cStack_a66;
  char cStack_a65;
  char cStack_a64;
  char cStack_a63;
  char cStack_a62;
  char cStack_a61;
  char cStack_a60;
  undefined8 local_a58;
  undefined8 uStack_a50;
  undefined8 local_a48;
  undefined8 uStack_a40;
  ulong local_a38;
  ulong uStack_a30;
  undefined1 local_a28 [16];
  undefined1 *local_a18 [2];
  undefined1 local_a08 [16];
  undefined1 *local_9f8;
  long local_9f0;
  undefined1 local_9e8;
  undefined7 uStack_9e7;
  undefined2 local_9d8;
  DeviceInfoMessage local_9c8 [16];
  _Optional_payload_base local_9b8 [24];
  undefined1 local_9a0;
  undefined1 local_988;
  undefined1 local_968;
  char local_960;
  ulong local_958;
  char local_950;
  undefined1 local_948;
  _Optional_payload_base local_940 [4];
  long local_93c;
  int local_934;
  ulong local_930;
  byte local_928;
  long *local_920;
  long local_910 [3];
  char local_8f8;
  undefined1 local_8d0;
  _Optional_payload_base local_8c8 [32];
  long *local_8a8;
  long local_898 [5];
  char local_870;
  undefined1 local_858;
  undefined1 local_850;
  undefined1 local_818;
  undefined1 local_800;
  undefined8 local_7f8;
  undefined8 uStack_7f0;
  undefined8 local_7e8;
  undefined8 uStack_7e0;
  ulong local_7d8;
  char cStack_7d0;
  undefined7 uStack_7cf;
  undefined1 local_7a8;
  undefined1 local_770;
  undefined1 local_730;
  DeviceInfoMessage local_728 [8];
  ulong uStack_720;
  _Optional_payload_base local_718 [112];
  undefined1 local_6a8;
  _Optional_payload_base local_6a0 [112];
  undefined1 local_630;
  _Optional_payload_base local_628 [112];
  undefined1 local_5b8;
  NimbusConnectionMessage local_5a8 [8];
  ulong uStack_5a0;
  char local_598;
  undefined1 *local_590;
  undefined8 local_588;
  undefined1 local_580;
  undefined7 uStack_57f;
  undefined1 *local_570;
  undefined8 local_568;
  undefined1 local_560;
  undefined7 uStack_55f;
  long local_548;
  int local_540;
  byte local_53c;
  DeviceInfoMessage local_538 [16];
  _Optional_payload_base<droneforge::core::runtime::CrsfDeviceInfoData> local_528 [112];
  byte local_4b8;
  _Optional_payload_base<droneforge::core::runtime::CrsfDeviceInfoData> local_4b0 [112];
  byte local_440;
  _Optional_payload_base<droneforge::core::runtime::CrsfDeviceInfoData> local_438 [80];
  char *local_3e8;
  char *local_3e0;
  byte local_3c8;
  OptrangeFailsafe local_3b8 [4];
  int local_3b4;
  undefined8 local_3b0;
  undefined1 local_3a8 [16];
  undefined1 local_390;
  undefined1 local_36c;
  long local_368;
  long *local_360;
  long local_350 [2];
  long local_340;
  long *local_338;
  long local_328 [2];
  long local_318;
  long *local_310;
  long local_300 [2];
  long local_2f0;
  long *local_2e8;
  long local_2d8 [2];
  long local_2c8;
  long *local_2c0;
  long local_2b0 [2];
  long local_2a0;
  long *local_298;
  long local_288 [2];
  long local_278;
  long *local_270;
  long local_260 [2];
  long local_250;
  long *local_248;
  long local_238 [2];
  long local_228;
  long *local_220;
  long local_210 [2];
  long local_200;
  long *local_1f8;
  long local_1e8 [2];
  undefined1 **local_1d8;
  undefined1 *puStack_1d0;
  undefined1 *local_1c8 [2];
  undefined1 local_1b8 [16];
  undefined1 local_1a8 [2];
  undefined1 auStack_1a6 [10];
  undefined2 uStack_19c;
  char cStack_19a;
  undefined1 uStack_199;
  undefined1 local_198 [8];
  undefined1 **ppuStack_190;
  undefined1 local_188 [16];
  long *local_178;
  long *local_170;
  SerialOutboundFrameLoop *local_168;
  undefined1 *local_160;
  long *local_158;
  _Optional_payload_base *local_150;
  undefined *local_148 [2];
  undefined1 local_138;
  _Optional_payload_base local_130 [88];
  char acStack_d8 [16];
  long lStack_c8;
  undefined1 local_c0;
  _Optional_payload_base local_b8 [72];
  undefined8 local_70;
  undefined2 local_68;
  undefined1 local_60 [16];
  undefined1 local_50 [16];
  long local_38;
  
  local_38 = *(long *)(in_FS_OFFSET + 0x28);
  Topic<droneforge::core::runtime::ControlsMessage,512ul>::Subscribe(false);
  Topic<droneforge::core::runtime::NimbusCommandMessage,32ul>::Subscribe(SUB81(&local_228,0));
  Topic<droneforge::core::runtime::VrxChannelRequestMessage,32ul>::Subscribe(SUB81(&local_250,0));
  Topic<droneforge::core::runtime::TelemetryMessage,512ul>::Subscribe(SUB81(&local_278,0));
                    /* try { // try from 002dad5a to 003dadab has its CatchHandler @ 002deb27 */
  Topic<droneforge::core::runtime::DeviceInfoMessage,128ul>::Subscribe(SUB81(&local_2a0,0));
  Topic<droneforge::core::runtime::ArmMessage,32ul>::Subscribe(SUB81(&local_2c8,0));
  Topic<droneforge::core::runtime::VrxChannelRequestMessage,32ul>::Subscribe(SUB81(&local_2f0,0));
  Topic<droneforge::core::runtime::VtxPowerConfigMessage,32ul>::Subscribe(SUB81(&local_318,0));
                    /* try { // try from 002dadac to 003daeee has its CatchHandler @ 002dabf0 */
  Topic<droneforge::core::runtime::NimbusConnectionMessage,32ul>::Subscribe(SUB81(&local_340,0));
  Topic<droneforge::core::runtime::ArmMessage,64ul>::Subscribe(SUB81(&local_368,0));
  auVar75 = DisarmCommand();
  local_ac8 = auVar75._0_8_;
  local_ac0 = auVar75._8_4_;
  local_abc = auVar75._12_2_;
  local_3b8[0] = (OptrangeFailsafe)0x0;
  local_3b4 = 0;
  local_3b0 = 500000000;
  local_390 = 0;
  local_36c = 0;
  local_3a8 = (undefined1  [16])0x0;
  uStack_a30 = uStack_a30 & 0xffffffffffffff00;
  local_4b8 = 0;
  local_440 = 0;
  local_3c8 = 0;
  local_538[0] = (DeviceInfoMessage)0x0;
  local_538[1] = (DeviceInfoMessage)0x0;
  local_538[2] = (DeviceInfoMessage)0x0;
  local_538[3] = (DeviceInfoMessage)0x0;
  local_538[4] = (DeviceInfoMessage)0x0;
  local_538[5] = (DeviceInfoMessage)0x0;
  local_538[6] = (DeviceInfoMessage)0x0;
  local_538[7] = (DeviceInfoMessage)0x0;
  local_538[8] = (DeviceInfoMessage)0x0;
  local_538[9] = (DeviceInfoMessage)0x0;
  local_538[10] = (DeviceInfoMessage)0x0;
  local_538[0xb] = (DeviceInfoMessage)0x0;
  local_538[0xc] = (DeviceInfoMessage)0x0;
  local_538[0xd] = (DeviceInfoMessage)0x0;
  local_538[0xe] = (DeviceInfoMessage)0x0;
  local_538[0xf] = (DeviceInfoMessage)0x0;
  local_ac9 = 0;
  local_aca = 0;
  auVar75 = DisarmCommand();
  puVar23 = PTR_operator_delete_008caa50;
  local_ad8 = auVar75._0_8_;
  local_ad0 = auVar75._8_4_;
  local_acc = auVar75._12_2_;
  local_ae0 = 0;
  local_ae1 = 0;
  local_b20 = local_af8 + 8;
  local_b18 = 1;
  local_b10 = (undefined1  [16])0x0;
  local_ae2 = (_Optional_payload_base)0x0;
  local_b00 = 0x3f800000;
  local_af8 = (undefined1  [16])0x0;
  local_53c = 0;
                    /* try { // try from 002daeef to 003daefb has its CatchHandler @ 002deada */
  cStack_a60 = '\0';
                    /* try { // try from 002daefc to 003db007 has its CatchHandler @ 002dabf0 */
  local_b21 = '\0';
  local_b23 = '\0';
  local_b30 = 0;
  local_b38 = 0;
  if (*param_1 != (atomic)0x0) {
LAB_002daf32:
    puVar23 = PTR_operator_delete_008caa50;
    puVar42 = (undefined8 *)local_b10._0_8_;
    while (puVar42 != (undefined8 *)0x0) {
      puVar3 = (undefined8 *)*puVar42;
      if ((long *)puVar42[7] != puVar42 + 9) {
        (*(code *)puVar23)((long *)puVar42[7],puVar42[9] + 1);
      }
      if ((long *)puVar42[1] != puVar42 + 3) {
        (*(code *)puVar23)((long *)puVar42[1],puVar42[3] + 1);
      }
      (*(code *)puVar23)(puVar42,0x68);
      puVar42 = puVar3;
    }
    (*(code *)PTR_memset_008ca790)(local_b20,0,local_b18 << 3);
    local_b10 = (undefined1  [16])0x0;
    if (local_b20 != local_af8 + 8) {
      (*(code *)PTR_operator_delete_008caa50)(local_b20,local_b18 << 3);
    }
    DeviceInfoMessage::~DeviceInfoMessage(local_538);
    if (local_368 != 0) {
      (*(code *)PTR_zmq_close_008cacf8)();
                    /* try { // try from 002db008 to 003db014 has its CatchHandler @ 002deb22 */
      local_368 = 0;
    }
                    /* try { // try from 002db015 to 003db0d0 has its CatchHandler @ 002dabf0 */
    if (local_360 != local_350) {
      (*(code *)PTR_operator_delete_008caa50)(local_360,local_350[0] + 1);
    }
    if (local_340 != 0) {
      (*(code *)PTR_zmq_close_008cacf8)();
      local_340 = 0;
    }
    if (local_338 != local_328) {
      (*(code *)PTR_operator_delete_008caa50)(local_338,local_328[0] + 1);
    }
    if (local_318 != 0) {
      (*(code *)PTR_zmq_close_008cacf8)();
      local_318 = 0;
    }
    if (local_310 != local_300) {
      (*(code *)PTR_operator_delete_008caa50)(local_310,local_300[0] + 1);
    }
    if (local_2f0 != 0) {
      (*(code *)PTR_zmq_close_008cacf8)();
                    /* try { // try from 002db0d1 to 003db0e4 has its CatchHandler @ 002de961 */
      local_2f0 = 0;
    }
    if (local_2e8 != local_2d8) {
      (*(code *)PTR_operator_delete_008caa50)(local_2e8,local_2d8[0] + 1);
    }
    if (local_2c8 != 0) {
      (*(code *)PTR_zmq_close_008cacf8)();
      local_2c8 = 0;
    }
    if (local_2c0 != local_2b0) {
      (*(code *)PTR_operator_delete_008caa50)(local_2c0,local_2b0[0] + 1);
    }
    if (local_2a0 != 0) {
      (*(code *)PTR_zmq_close_008cacf8)();
      local_2a0 = 0;
    }
    if (local_298 != local_288) {
      (*(code *)PTR_operator_delete_008caa50)(local_298,local_288[0] + 1);
    }
    if (local_278 != 0) {
      (*(code *)PTR_zmq_close_008cacf8)();
      local_278 = 0;
    }
                    /* try { // try from 002db1ad to 003db1b9 has its CatchHandler @ 002de963 */
    if (local_270 != local_260) {
      (*(code *)PTR_operator_delete_008caa50)(local_270,local_260[0] + 1);
    }
    if (local_250 != 0) {
      (*(code *)PTR_zmq_close_008cacf8)();
      local_250 = 0;
    }
    if (local_248 != local_238) {
      (*(code *)PTR_operator_delete_008caa50)(local_248,local_238[0] + 1);
    }
    if (local_228 != 0) {
      (*(code *)PTR_zmq_close_008cacf8)();
      local_228 = 0;
    }
                    /* try { // try from 002db240 to 003db247 has its CatchHandler @ 002deaf8 */
    if (local_220 != local_210) {
      (*(code *)PTR_operator_delete_008caa50)(local_220,local_210[0] + 1);
    }
    if (local_200 != 0) {
      (*(code *)PTR_zmq_close_008cacf8)();
      local_200 = 0;
    }
    if (local_1f8 != local_1e8) {
      (*(code *)PTR_operator_delete_008caa50)(local_1f8,local_1e8[0] + 1);
    }
    if (*(long *)(in_FS_OFFSET + 0x28) == local_38) {
      return;
    }
LAB_002e0448:
                    /* WARNING: Subroutine does not return */
    __stack_chk_fail();
  }
  lVar4 = *(long *)PTR_VTT_008caab8;
  lVar5 = *(long *)(PTR_VTT_008caab8 + 8);
  uVar53 = *(undefined8 *)(PTR_VTT_008caab8 + 0x10);
  uVar6 = *(undefined8 *)(PTR_VTT_008caab8 + 0x18);
  local_c85 = true;
  puVar37 = PTR_vtable_008ca5b8 + 0x10;
                    /* try { // try from 002db316 to 003db32b has its CatchHandler @ 002de96d */
  puVar38 = PTR_vtable_008ca828 + 0x10;
  puVar39 = PTR_vtable_008cafd0 + 0x10;
  local_c18 = 0;
  local_bc0 = &LAB_007aa400_2;
  local_bf8 = 0;
  local_bd8 = 0;
  bVar17 = false;
  bVar16 = false;
  bVar15 = false;
  bVar19 = false;
  bVar18 = false;
  iVar61 = 0;
  local_bd0 = (undefined1 *)0x0;
  local_c78 = 0;
  local_ca4 = 0;
  local_cb4 = 0;
  bVar68 = false;
  local_be8 = 0;
                    /* try { // try from 002db3e8 to 003db3f4 has its CatchHandler @ 002de957 */
  bVar20 = false;
                    /* try { // try from 002db3f5 to 003db47c has its CatchHandler @ 002dabf0 */
  local_c40 = 0;
  local_c00 = 0;
  local_bc8 = 0;
  local_bb0 = 0;
  local_c28 = 0;
  local_c80 = 0;
  local_c50 = 0;
  bVar7 = false;
  local_c38 = 0;
  local_c20 = 0;
  local_c10 = 0;
                    /* try { // try from 002db47d to 003db482 has its CatchHandler @ 002de95c */
  local_c08 = 0;
  plVar64 = (long *)PTR_cout_008cab98;
  pcVar59 = (code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00;
  bVar34 = 0;
  bVar55 = 0;
LAB_002db4b8:
  local_b40 = (*(code *)PTR_now_008cabf0)();
  _local_5a8 = (undefined1  [16])0x0;
  local_598 = '\0';
  local_590 = &local_580;
  local_588 = 0;
  local_580 = 0;
  local_570 = &local_560;
  local_568 = 0;
  local_560 = 0;
  cVar31 = Topic<droneforge::core::runtime::NimbusConnectionMessage,32ul>::Subscription::ReadLatest
                     ((Subscription *)&local_340,local_5a8,(ulong *)0x0);
                    /* try { // try from 002db550 to 003db555 has its CatchHandler @ 002de977 */
                    /* try { // try from 002db556 to 003db669 has its CatchHandler @ 002dabf0 */
  if ((cVar31 != '\0') && ((bool)local_ac9 != (local_598 == '\x01'))) {
    local_bd8 = uStack_5a0;
    local_53c = 0;
    local_ae0 = 0;
    local_948 = 0;
    local_8d0 = 0;
    local_858 = 0;
    local_9c8[0] = (DeviceInfoMessage)0x0;
    local_9c8[1] = (DeviceInfoMessage)0x0;
    local_9c8[2] = (DeviceInfoMessage)0x0;
    local_9c8[3] = (DeviceInfoMessage)0x0;
    local_9c8[4] = (DeviceInfoMessage)0x0;
    local_9c8[5] = (DeviceInfoMessage)0x0;
    local_9c8[6] = (DeviceInfoMessage)0x0;
    local_9c8[7] = (DeviceInfoMessage)0x0;
    local_9c8[8] = (DeviceInfoMessage)0x0;
    local_9c8[9] = (DeviceInfoMessage)0x0;
    local_9c8[10] = (DeviceInfoMessage)0x0;
    local_9c8[0xb] = (DeviceInfoMessage)0x0;
    local_9c8[0xc] = (DeviceInfoMessage)0x0;
    local_9c8[0xd] = (DeviceInfoMessage)0x0;
    local_9c8[0xe] = (DeviceInfoMessage)0x0;
    local_9c8[0xf] = (DeviceInfoMessage)0x0;
    local_538[0] = (DeviceInfoMessage)0x0;
    local_538[1] = (DeviceInfoMessage)0x0;
    local_538[2] = (DeviceInfoMessage)0x0;
    local_538[3] = (DeviceInfoMessage)0x0;
    local_538[4] = (DeviceInfoMessage)0x0;
    local_538[5] = (DeviceInfoMessage)0x0;
    local_538[6] = (DeviceInfoMessage)0x0;
    local_538[7] = (DeviceInfoMessage)0x0;
    local_538[8] = (DeviceInfoMessage)0x0;
    local_538[9] = (DeviceInfoMessage)0x0;
    local_538[10] = (DeviceInfoMessage)0x0;
    local_538[0xb] = (DeviceInfoMessage)0x0;
    local_538[0xc] = (DeviceInfoMessage)0x0;
    local_538[0xd] = (DeviceInfoMessage)0x0;
    local_538[0xe] = (DeviceInfoMessage)0x0;
    local_538[0xf] = (DeviceInfoMessage)0x0;
    local_ac9 = local_598 == '\x01';
    std::_Optional_payload_base<droneforge::core::runtime::CrsfDeviceInfoData>::_M_move_assign
              (local_528,local_9b8);
    std::_Optional_payload_base<droneforge::core::runtime::CrsfDeviceInfoData>::_M_move_assign
              (local_4b0,local_940);
    std::_Optional_payload_base<droneforge::core::runtime::CrsfDeviceInfoData>::_M_move_assign
              (local_438,local_8c8);
    DeviceInfoMessage::~DeviceInfoMessage(local_9c8);
    local_aca = 0;
    local_ae1 = 0;
    cStack_a60 = '\0';
    local_b21 = '\0';
    local_b23 = '\0';
    local_b30 = 0;
    local_b38 = 0;
    local_c08 = 0;
    local_c10 = 0;
                    /* try { // try from 002db66a to 003db66e has its CatchHandler @ 002dea02 */
    local_c20 = 0;
    bVar7 = false;
    local_c50 = 0;
    local_c80 = 0;
    local_c28 = 0;
    bVar68 = false;
    local_cb4 = 0;
                    /* try { // try from 002db6a7 to 003db6af has its CatchHandler @ 002dea2e */
    local_ca4 = 0;
    local_c78 = 0;
    iVar61 = 0;
    bVar18 = false;
    bVar19 = false;
    bVar15 = false;
    local_bf8 = 0;
    local_c18 = local_bd8;
  }
  local_6a8 = 0;
  local_630 = 0;
  local_5b8 = 0;
  _local_728 = (undefined1  [16])0x0;
  if (local_ac9 != 0) {
    bVar32 = Topic<droneforge::core::runtime::DeviceInfoMessage,128ul>::Subscription::ReadLatest
                       ((Subscription *)&local_2a0,local_728,(ulong *)0x0);
    if ((bVar32 & local_c18 <= uStack_720) == 1) {
      local_538[0] = local_728[0];
      local_538[1] = local_728[1];
      local_538[2] = local_728[2];
      local_538[3] = local_728[3];
      local_538[4] = local_728[4];
      local_538[5] = local_728[5];
      local_538[6] = local_728[6];
      local_538[7] = local_728[7];
      local_538[8] = (DeviceInfoMessage)(undefined1)uStack_720;
      local_538[9] = (DeviceInfoMessage)uStack_720._1_1_;
      local_538[10] = (DeviceInfoMessage)uStack_720._2_1_;
      local_538[0xb] = (DeviceInfoMessage)uStack_720._3_1_;
      local_538[0xc] = (DeviceInfoMessage)uStack_720._4_1_;
      local_538[0xd] = (DeviceInfoMessage)uStack_720._5_1_;
      local_538[0xe] = (DeviceInfoMessage)uStack_720._6_1_;
      local_538[0xf] = (DeviceInfoMessage)uStack_720._7_1_;
      std::_Optional_payload_base<droneforge::core::runtime::CrsfDeviceInfoData>::_M_move_assign
                (local_528,local_718);
      std::_Optional_payload_base<droneforge::core::runtime::CrsfDeviceInfoData>::_M_move_assign
                (local_4b0,local_6a0);
      std::_Optional_payload_base<droneforge::core::runtime::CrsfDeviceInfoData>::_M_move_assign
                (local_438,local_628);
    }
  }
  local_9a0 = 0;
  local_988 = 0;
  local_968 = 0;
  local_950 = '\0';
  local_928 = 0;
  local_8f8 = '\0';
  local_8c8[0] = (_Optional_payload_base)0x0;
  local_870 = '\0';
  local_850 = 0;
  local_818 = 0;
  local_800 = 0;
  cStack_7d0 = '\0';
  local_7a8 = 0;
  local_770 = 0;
  local_730 = 0;
  local_9c8[0] = (DeviceInfoMessage)0x0;
  local_9c8[1] = (DeviceInfoMessage)0x0;
  local_9c8[2] = (DeviceInfoMessage)0x0;
  local_9c8[3] = (DeviceInfoMessage)0x0;
  local_9c8[4] = (DeviceInfoMessage)0x0;
  local_9c8[5] = (DeviceInfoMessage)0x0;
  local_9c8[6] = (DeviceInfoMessage)0x0;
  local_9c8[7] = (DeviceInfoMessage)0x0;
  local_9c8[8] = (DeviceInfoMessage)0x0;
  local_9c8[9] = (DeviceInfoMessage)0x0;
  local_9c8[10] = (DeviceInfoMessage)0x0;
  local_9c8[0xb] = (DeviceInfoMessage)0x0;
  local_9c8[0xc] = (DeviceInfoMessage)0x0;
  local_9c8[0xd] = (DeviceInfoMessage)0x0;
  local_9c8[0xe] = (DeviceInfoMessage)0x0;
  local_9c8[0xf] = (DeviceInfoMessage)0x0;
  lVar63 = local_c50;
  uVar62 = local_bf8;
  if ((local_ac9 == 1) &&
     (cVar31 = Topic<droneforge::core::runtime::TelemetryMessage,512ul>::Subscription::ReadLatest
                         ((Subscription *)&local_278,(TelemetryMessage *)local_9c8,(ulong *)0x0),
     cVar31 != '\0')) {
    if ((cStack_7d0 == '\x01') && (local_c18 <= local_7d8)) {
      uStack_a30 = CONCAT71(uStack_7cf,1);
      local_a38 = local_7d8;
      local_a48 = local_7e8;
      uStack_a40 = uStack_7e0;
      local_a58 = local_7f8;
      uStack_a50 = uStack_7f0;
    }
    if ((local_950 != '\x01') || (local_958 < local_c18)) goto LAB_002db8b3;
                    /* try { // try from 002dba12 to 003dba17 has its CatchHandler @ 002de9ec */
    if (local_960 != '\x01') {
      uVar62 = local_958;
      if ((local_aca == 1) && (uVar62 = local_bf8, local_ae1 == 0)) {
        local_ae1 = 1;
        local_c20 = local_b40;
        local_c78 = local_958;
      }
      goto LAB_002db8b3;
    }
                    /* try { // try from 002dba18 to 003dbbd0 has its CatchHandler @ 002dabf0 */
    local_c50 = local_b40;
    uVar40 = local_958;
    if (local_ae1 == 1) {
      (*pcVar59)(plVar64,&DAT_007b30d1,0x2c);
      (*pcVar59)(plVar64,&LAB_007b30fa_4,0xd);
      uVar41 = (*(code *)PTR__M_insert<long>_008ca9e8)(plVar64,(local_b40 - local_c20) / 1000000);
      (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)(uVar41,&LAB_007b3615_5,5)
      ;
      uVar41 = (*(code *)PTR__M_insert<unsigned_long>_008ca870)(uVar41,local_958);
      (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)(uVar41,&LAB_007be511,1);
      local_53c = 0;
      local_ae1 = 0;
      cStack_a60 = '\0';
      local_b21 = '\0';
      local_b23 = '\0';
      local_b30 = 0;
      local_b38 = 0;
      local_c20 = 0;
      local_c50 = 0;
      local_c80 = 0;
      local_c78 = 0;
      iVar61 = 0;
      bVar18 = false;
      bVar19 = false;
      bVar15 = false;
      local_bd8 = local_958;
      pcVar59 = (code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00;
      lVar63 = local_c50;
      local_c28 = local_b40;
      local_c50 = local_b40;
      local_ae0 = local_b40;
      uVar40 = local_958;
    }
    local_b40 = local_c50;
    local_958 = uVar40;
    if (local_aca != 0) goto LAB_002db8b3;
                    /* try { // try from 002dbbd1 to 003dbc3d has its CatchHandler @ 002dead6 */
    if (local_53c != 0) {
      local_c80 = local_c50 + 1000000000;
    }
    local_aca = 1;
    cStack_a60 = '\0';
    local_b21 = '\0';
    local_b23 = '\0';
    local_b30 = 0;
    local_b38 = 0;
    iVar61 = 0;
    bVar18 = false;
                    /* try { // try from 002dbc3e to 003dbd00 has its CatchHandler @ 002dabf0 */
    bVar19 = false;
    bVar15 = false;
    local_c28 = local_c50;
    local_ae0 = local_c50;
    if (local_ae1 == 1) goto LAB_002db8ce;
LAB_002dbc60:
    uVar62 = local_c78;
    local_c78 = uVar40;
    if (local_ac9 != 1) goto LAB_002dbe86;
LAB_002dbc7a:
    uVar40 = local_930;
    lVar63 = local_b40;
    if ((local_928 & 1) == 0) goto LAB_002dbe86;
    plVar64 = (long *)PTR_cout_008cab98;
    uVar28 = local_ca4;
    bVar29 = bVar15;
    bVar30 = bVar7;
    if ((local_c18 <= local_930) && (local_c78 <= local_930)) {
      if ((local_aca == 0) && (local_bf8 < local_930)) {
        local_aca = 1;
        local_ae0 = local_b40;
        (*pcVar59)(PTR_cout_008cab98,&LAB_007b3136_4,0x3b);
        local_c50 = lVar63;
                    /* try { // try from 002dbd01 to 003dbd75 has its CatchHandler @ 002dead4 */
        local_c28 = lVar63;
        iVar61 = 0;
        bVar18 = false;
        bVar19 = false;
        local_c78 = uVar40;
      }
      local_1b8._8_4_ = local_934;
      local_1b8._0_8_ = local_93c;
      plVar64 = (long *)PTR_cout_008cab98;
      if (local_53c == 1) {
                    /* try { // try from 002dbd76 to 003dbe30 has its CatchHandler @ 002dabf0 */
        if (local_540 == local_934 && local_548 == local_93c) goto LAB_002dbe86;
      }
      else {
        local_53c = 1;
      }
      local_540 = local_934;
      local_548 = local_93c;
      local_c80 = local_c28;
      if (local_c28 < local_b40) {
        local_c80 = local_b40;
      }
      if (local_c28 == 0) {
        local_c80 = local_b40;
      }
      if (local_aca != 0) {
        local_c50 = local_c80;
      }
      if ((local_ae0 == 0) || (local_ae0 < local_c80)) {
        local_ae0 = local_c80;
      }
                    /* try { // try from 002dbe31 to 003dbe9d has its CatchHandler @ 002dead8 */
      local_c78 = local_930;
      cStack_a60 = '\0';
      local_b21 = '\0';
      local_b23 = '\0';
      local_b30 = 0;
      local_b38 = 0;
      bVar18 = false;
      bVar19 = false;
      bVar15 = false;
      goto LAB_002dbe86;
    }
LAB_002dc044:
    bVar7 = bVar30;
    bVar15 = bVar29;
    local_ca4 = uVar28;
    lVar63 = local_c80;
    if (local_c80 == 0) {
      lVar63 = local_b40;
    }
    if (bVar15) {
      lVar63 = local_c80;
    }
    if (local_53c != 0) {
      local_c80 = lVar63;
    }
    lVar63 = local_b40;
    if (local_c50 != 0) {
      lVar63 = local_c50;
    }
    if (local_aca != 0) {
      local_c50 = lVar63;
    }
    local_bd8 = local_c78;
    local_ca8 = local_cb4;
    local_c78 = uVar62;
    iVar35 = iVar61;
    bVar14 = bVar68;
  }
  else {
LAB_002db8b3:
    local_bf8 = uVar62;
    local_c50 = lVar63;
    uVar40 = local_bd8;
    if (local_ae1 != 1) goto LAB_002dbc60;
LAB_002db8ce:
    if (local_b40 - local_c20 < 2000000000) goto LAB_002dbc60;
    local_ae0 = 0;
    local_53c = 0;
    local_aca = 0;
    local_ae1 = 0;
    cStack_a60 = '\0';
    local_b21 = '\0';
    local_b23 = '\0';
    local_b30 = 0;
    local_b38 = 0;
    (*pcVar59)(plVar64,&LAB_007b310b_1,0x2d);
    (*pcVar59)(plVar64,&LAB_007b3615_5,5);
    uVar41 = (*(code *)PTR__M_insert<unsigned_long>_008ca870)(plVar64,local_c78);
    (*pcVar59)(uVar41,&LAB_007be511,1);
    local_c10 = 0;
    local_c20 = 0;
    bVar7 = false;
    local_c50 = 0;
    local_c80 = 0;
    local_c28 = 0;
    bVar68 = false;
    local_cb4 = 0;
    local_ca4 = 0;
    uVar62 = 0;
    iVar61 = 0;
    bVar18 = false;
    bVar19 = false;
    bVar15 = false;
    local_bf8 = local_c78;
    if (local_ac9 == 1) goto LAB_002dbc7a;
LAB_002dbe86:
    uVar28 = local_ca4;
    bVar29 = bVar15;
    bVar30 = bVar7;
    if (local_ac9 != 0) goto LAB_002dc044;
    local_138 = 0;
    local_c0 = 0;
                    /* try { // try from 002dbe9e to 003dbf42 has its CatchHandler @ 002dabf0 */
    local_50[8] = 0;
    local_1b8 = (undefined1  [16])0x0;
    local_538[0] = (DeviceInfoMessage)0x0;
    local_538[1] = (DeviceInfoMessage)0x0;
    local_538[2] = (DeviceInfoMessage)0x0;
    local_538[3] = (DeviceInfoMessage)0x0;
    local_538[4] = (DeviceInfoMessage)0x0;
    local_538[5] = (DeviceInfoMessage)0x0;
    local_538[6] = (DeviceInfoMessage)0x0;
    local_538[7] = (DeviceInfoMessage)0x0;
    local_538[8] = (DeviceInfoMessage)0x0;
    local_538[9] = (DeviceInfoMessage)0x0;
    local_538[10] = (DeviceInfoMessage)0x0;
    local_538[0xb] = (DeviceInfoMessage)0x0;
    local_538[0xc] = (DeviceInfoMessage)0x0;
    local_538[0xd] = (DeviceInfoMessage)0x0;
    local_538[0xe] = (DeviceInfoMessage)0x0;
    local_538[0xf] = (DeviceInfoMessage)0x0;
    std::_Optional_payload_base<droneforge::core::runtime::CrsfDeviceInfoData>::_M_move_assign
              (local_528,(_Optional_payload_base *)local_1a8);
    std::_Optional_payload_base<droneforge::core::runtime::CrsfDeviceInfoData>::_M_move_assign
              (local_4b0,local_130);
    std::_Optional_payload_base<droneforge::core::runtime::CrsfDeviceInfoData>::_M_move_assign
              (local_438,local_b8);
    DeviceInfoMessage::~DeviceInfoMessage((DeviceInfoMessage *)local_1b8);
    local_aca = 0;
    local_ae0 = 0;
    local_53c = 0;
    local_ae1 = 0;
    cStack_a60 = '\0';
    local_b21 = '\0';
                    /* try { // try from 002dbf43 to 003dbf4b has its CatchHandler @ 002de9b0 */
    local_b23 = '\0';
    local_b30 = 0;
    local_bf8 = 0;
    local_b38 = 0;
    local_c78 = 0;
    bVar19 = false;
    bVar18 = false;
    iVar61 = 0;
    uVar62 = 0;
    local_cb4 = 0;
    bVar68 = false;
    local_c28 = 0;
    local_c80 = 0;
    local_c50 = 0;
    local_c20 = 0;
    local_c10 = 0;
    local_c08 = 0;
    local_bd8 = 0;
    bVar15 = false;
    local_ca4 = 0;
    local_ca8 = 0;
    bVar7 = false;
    uVar28 = 0;
    iVar35 = 0;
    bVar14 = false;
    bVar29 = false;
    bVar30 = false;
    if (local_ac9 == 1) goto LAB_002dc044;
  }
  iVar61 = iVar35;
  if (local_ae0 == 0) {
                    /* try { // try from 002dc0e1 to 003dc0e6 has its CatchHandler @ 002dead2 */
                    /* try { // try from 002dc0e7 to 003dc1db has its CatchHandler @ 002dabf0 */
    local_ae0 = local_b40;
  }
  local_a08 = (undefined1  [16])0x0;
  local_9f8 = &local_9e8;
  local_9f0 = 0;
  local_9e8 = 0;
  local_9d8 = 0x401;
  cVar31 = Topic<droneforge::core::runtime::VtxPowerConfigMessage,32ul>::Subscription::ReadLatest
                     ((Subscription *)&local_318,(VtxPowerConfigMessage *)local_a08,(ulong *)0x0);
  puVar58 = local_9f8;
  if (cVar31 != '\0') {
    if (local_9f0 == 0x18) {
      puStack_1d0 = (undefined1 *)0x0;
      local_1d8 = (undefined1 **)(*(code *)PTR_operator_new_008caa38)(0x1f);
      *(undefined1 *)local_1d8 = 0;
      local_1c8[0] = (undefined1 *)0x1e;
      lVar63 = 0;
      do {
        uVar33 = puVar58[lVar63];
        iVar35 = (*(code *)PTR_isxdigit_008ca5e8)(uVar33);
        if (iVar35 == 0) {
          auVar8[0xf] = 0;
          auVar8._0_15_ = stack0xfffffffffffffe69;
          _local_198 = auVar8 << 8;
          plVar64 = (long *)PTR_cout_008cab98;
          pcVar59 = (code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00;
          if (local_1d8 == local_1c8) goto LAB_002dc530;
          (*(code *)puVar23)(local_1d8,local_1c8[0] + 1);
          plVar64 = (long *)PTR_cout_008cab98;
          pcVar59 = (code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00;
          if (local_198[0] == '\0') goto LAB_002dc530;
          uVar21 = local_9d8;
          goto joined_r0x002dc2ae;
        }
                    /* try { // try from 002dc1dc to 003dc1e4 has its CatchHandler @ 002de9e2 */
        uVar33 = (*(code *)PTR_tolower_008cace8)(uVar33);
        puVar27 = puStack_1d0;
        puVar56 = (undefined1 *)0xf;
        if (local_1d8 != local_1c8) {
          puVar56 = local_1c8[0];
        }
        puVar1 = puStack_1d0 + 1;
        if (puVar56 < puVar1) {
          std::__cxx11::string::_M_mutate((string *)&local_1d8,(ulong)puStack_1d0,0,(char *)0x0,1);
        }
        *(undefined1 *)((long)local_1d8 + (long)puVar27) = uVar33;
        ((undefined1 *)((long)local_1d8 + 1))[(long)puVar27] = 0;
        plVar64 = (long *)PTR_cout_008cab98;
        pcVar59 = (code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00;
        lVar63 = lVar63 + 1;
        puStack_1d0 = puVar1;
      } while (lVar63 != 0x18);
      local_1b8._0_8_ = local_1a8;
      if (local_1d8 == local_1c8) {
        (*(code *)PTR_memcpy_008ca960)(local_1a8,local_1c8,puVar27 + 2);
      }
      else {
        local_1b8._0_8_ = local_1d8;
        _local_1a8 = (long)local_1c8[0];
      }
      local_1b8._8_8_ = puVar1;
      local_198[0] = 1;
                    /* try { // try from 002dc359 to 003dc35e has its CatchHandler @ 002deae4 */
                    /* try { // try from 002dc35f to 003dc4c7 has its CatchHandler @ 002dabf0 */
      uVar21 = local_9d8;
joined_r0x002dc2ae:
      bVar32 = (byte)local_9d8 - 1;
      local_9d8 = uVar21;
      if ((3 < bVar32) ||
         (local_9d8._1_1_ = (byte)((ushort)uVar21 >> 8), bVar32 = local_9d8._1_1_ - 1,
         bVar68 = local_9d8._1_1_ < (byte)local_9d8, bVar68 || 3 < bVar32)) goto LAB_002dc530;
      std::__cxx11::string::_M_assign((string *)&local_9f8,(string *)local_1b8);
      lVar63 = std::
               _Hashtable<std::__cxx11::string,std::pair<std::__cxx11::string_const,droneforge::core::runtime::VtxPowerConfigMessage>,std::allocator<std::pair<std::__cxx11::string_const,droneforge::core::runtime::VtxPowerConfigMessage>>,std::__detail::_Select1st,std::equal_to<std::__cxx11::string>,std::hash<std::__cxx11::string>,std::__detail::_Mod_range_hashing,std::__detail::_Default_ranged_hash,std::__detail::_Prime_rehash_policy,std::__detail::_Hashtable_traits<true,false,true>>
               ::find((_Hashtable<std::__cxx11::string,std::pair<std::__cxx11::string_const,droneforge::core::runtime::VtxPowerConfigMessage>,std::allocator<std::pair<std::__cxx11::string_const,droneforge::core::runtime::VtxPowerConfigMessage>>,std::__detail::_Select1st,std::equal_to<std::__cxx11::string>,std::hash<std::__cxx11::string>,std::__detail::_Mod_range_hashing,std::__detail::_Default_ranged_hash,std::__detail::_Prime_rehash_policy,std::__detail::_Hashtable_traits<true,false,true>>
                       *)&local_b20,(string *)local_1b8);
      bVar68 = true;
      if ((lVar63 != 0) && (*(char *)(lVar63 + 0x58) == (byte)local_9d8)) {
        bVar68 = *(char *)(lVar63 + 0x59) != local_9d8._1_1_;
      }
      puVar42 = (undefined8 *)
                std::__detail::
                _Map_base<std::__cxx11::string,std::pair<std::__cxx11::string_const,droneforge::core::runtime::VtxPowerConfigMessage>,std::allocator<std::pair<std::__cxx11::string_const,droneforge::core::runtime::VtxPowerConfigMessage>>,std::__detail::_Select1st,std::equal_to<std::__cxx11::string>,std::hash<std::__cxx11::string>,std::__detail::_Mod_range_hashing,std::__detail::_Default_ranged_hash,std::__detail::_Prime_rehash_policy,std::__detail::_Hashtable_traits<true,false,true>,true>
                ::operator[]((_Map_base<std::__cxx11::string,std::pair<std::__cxx11::string_const,droneforge::core::runtime::VtxPowerConfigMessage>,std::allocator<std::pair<std::__cxx11::string_const,droneforge::core::runtime::VtxPowerConfigMessage>>,std::__detail::_Select1st,std::equal_to<std::__cxx11::string>,std::hash<std::__cxx11::string>,std::__detail::_Mod_range_hashing,std::__detail::_Default_ranged_hash,std::__detail::_Prime_rehash_policy,std::__detail::_Hashtable_traits<true,false,true>,true>
                              *)&local_b20,(string *)local_1b8);
      *puVar42 = local_a08._0_8_;
      puVar42[1] = local_a08._8_8_;
      std::__cxx11::string::_M_assign((string *)(puVar42 + 2),(string *)&local_9f8);
      *(undefined2 *)(puVar42 + 6) = local_9d8;
      (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                (plVar64,&LAB_007b31bb_1,0x1e);
      uVar41 = (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                         (plVar64,local_1b8._0_8_,local_1b8._8_8_);
      (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                (uVar41,&LAB_007b3192_3,0x14);
      uVar41 = (*(code *)PTR_operator<<_008cae78)(uVar41,(byte)local_9d8);
      (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                (uVar41,&LAB_007b31a9_1,0x11);
      uVar41 = (*(code *)PTR_operator<<_008cae78)(uVar41,local_9d8._1_1_);
      (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)(uVar41,&LAB_007be511,1);
      pcVar59 = (code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00;
      if ((bVar68 & local_53c) == 1) {
                    /* try { // try from 002dc4c8 to 003dc4cd has its CatchHandler @ 002deae4 */
        runtime::(anonymous_namespace)::FormatFlightControllerUid_abi_cxx11_((array *)&local_1d8);
        ppuVar47 = local_1d8;
        if (puStack_1d0 == (undefined1 *)local_1b8._8_8_) {
          if (puStack_1d0 == (undefined1 *)0x0) {
            bVar68 = true;
          }
          else {
            iVar35 = (*(code *)PTR_bcmp_008caa88)(local_1d8,local_1b8._0_8_);
            bVar68 = iVar35 == 0;
          }
        }
        else {
          bVar68 = false;
        }
        if (ppuVar47 != local_1c8) {
          (*(code *)puVar23)(ppuVar47,local_1c8[0] + 1);
        }
        if (bVar68) {
          local_b21 = '\0';
          local_b23 = '\0';
          local_b30 = local_b40;
          local_b38 = 0;
        }
      }
    }
    else {
      auVar75[0xf] = 0;
      auVar75._0_15_ = stack0xfffffffffffffe69;
      _local_198 = auVar75 << 8;
LAB_002dc530:
      (*pcVar59)(plVar64,&LAB_007b3172_4,0x1e);
      uVar41 = (*pcVar59)(plVar64,local_9f8,local_9f0);
      (*pcVar59)(uVar41,&LAB_007b3192_3,0x14);
      uVar41 = (*(code *)PTR_operator<<_008cae78)(uVar41,(byte)local_9d8);
      (*pcVar59)(uVar41,&LAB_007b31a9_1,0x11);
      uVar41 = (*(code *)PTR_operator<<_008cae78)(uVar41,local_9d8._1_1_);
      (*pcVar59)(uVar41,&LAB_007be511,1);
    }
    cVar31 = local_198[0];
    auVar9[0xf] = 0;
    auVar9._0_15_ = stack0xfffffffffffffe69;
    _local_198 = auVar9 << 8;
    if ((cVar31 == '\x01') && ((undefined1 *)local_1b8._0_8_ != local_1a8)) {
      (*(code *)puVar23)(local_1b8._0_8_,_local_1a8 + 1);
    }
  }
  local_1b8 = (undefined1  [16])0x0;
  auVar10[0xf] = 0;
  auVar10._0_15_ = stack0xfffffffffffffe59;
  _local_1a8 = auVar10 << 8;
  cVar31 = Topic<droneforge::core::runtime::ArmMessage,64ul>::Subscription::TryRead
                     ((Subscription *)&local_368,(ArmMessage *)local_1b8);
  if (cVar31 != '\0') {
    do {
      cVar31 = Topic<droneforge::core::runtime::ArmMessage,64ul>::Subscription::TryRead
                         ((Subscription *)&local_368,(ArmMessage *)local_1b8);
    } while (cVar31 != '\0');
    bVar68 = local_1a8[0] != local_ae2;
    local_ae2 = local_1a8[0];
    if (bVar68) {
      local_b30 = local_b40;
      lVar63 = local_b40;
      if (local_c80 < local_b40) {
        lVar63 = local_c80;
      }
      if (cStack_a60 == '\0') {
        local_c80 = lVar63;
      }
    }
  }
  if (local_ac9 == 1) {
    local_1b8 = (undefined1  [16])0x0;
    auVar11._14_2_ = 0;
    auVar11._0_14_ = _auStack_1a6;
    _local_1a8 = auVar11 << 0x10;
    cVar31 = Topic<droneforge::core::runtime::VrxChannelRequestMessage,32ul>::Subscription::TryRead
                       ((Subscription *)&local_2f0,(VrxChannelRequestMessage *)local_1b8);
    if (cVar31 != '\0') {
      do {
        cVar31 = Topic<droneforge::core::runtime::VrxChannelRequestMessage,32ul>::Subscription::
                 TryRead((Subscription *)&local_2f0,(VrxChannelRequestMessage *)local_1b8);
        lVar63 = local_b40;
      } while (cVar31 != '\0');
      if (local_c18 <= (ulong)local_1b8._8_8_) {
        _Var26 = local_1a8[0];
        bVar32 = local_1a8[1];
                    /* try { // try from 002dc702 to 003dc707 has its CatchHandler @ 002deaa3 */
        uVar62 = (ulong)local_1a8[1];
                    /* try { // try from 002dc708 to 003dc7ce has its CatchHandler @ 002dabf0 */
        local_a78 = local_1b8._0_8_;
        uStack_a70 = local_1b8._8_8_;
        local_a68 = local_1a8[0];
        bStack_a67 = local_1a8[1];
        if (cStack_a60 == '\0') {
          cStack_a60 = '\x01';
        }
        local_b30 = local_b40;
        if (!bVar15) {
          if (bVar7) {
            bVar7 = true;
          }
          else {
            bVar7 = local_b40 <= local_c08;
            local_ca8 = 1;
            if (bVar7 && local_c08 != 0) {
              local_ca8 = 8;
            }
            (*pcVar59)(plVar64,&LAB_007b31d8_3,0x2b);
            uVar41 = (*(code *)PTR_operator<<_008cae78)(PTR_cout_008cab98,_Var26);
            (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                      (uVar41,&LAB_007aae40_4,9);
            (*(code *)PTR_operator<<_008cae78)(uVar41);
            if (bVar7 && local_c08 != 0) {
              (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                        (PTR_cout_008cab98,&LAB_007b3203_4,10);
              (*(code *)PTR_operator<<_008cae78)(PTR_cout_008cab98,8);
            }
            if (((byte)(bVar32 - 1) < 8 && (byte)((char)_Var26 << 5 | (byte)_Var26 >> 3) < 6) &&
               ((byte)_Var26 < 0x30)) {
              bVar54 = (byte)_Var26 >> 3;
              sVar2 = *(short *)((ulong)bVar54 * 0x10 + 0x7f007a + (ulong)bVar32 * 2);
              if (sVar2 != 0) {
                cVar31 = "ABEFRL"[bVar54];
                uVar41 = *(undefined8 *)(crsf::utils::kVideoReceiverBandNames + (ulong)bVar54 * 8);
                (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                          (PTR_cout_008cab98,&LAB_007aae4c_2,5);
                puVar43 = PTR_cout_008cab98;
                local_1b8[0] = cVar31;
                if (*(long *)(PTR_cout_008cab98 +
                             *(long *)(*(long *)PTR_cout_008cab98 + -0x18) + 0x10) == 0) {
                  (*(code *)PTR_put_008ca520)(PTR_cout_008cab98,(int)cVar31);
                }
                else {
                  puVar43 = (undefined *)
                            (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                                      (PTR_cout_008cab98,local_1b8,1);
                }
                uVar45 = (*(code *)PTR_operator<<_008cae78)(puVar43,bVar32);
                    /* try { // try from 002dca8e to 003dca93 has its CatchHandler @ 002dea9f */
                (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                          (uVar45,&LAB_007aae53_1,6);
                uVar51 = (*(code *)PTR_strlen_008ca708)(uVar41);
                (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                          (uVar45,uVar41,uVar51);
                (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                          (uVar45,&LAB_007aae5b,9);
                uVar41 = (*(code *)PTR__M_insert<unsigned_long>_008ca870)(uVar45,sVar2);
                (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                          (uVar41,&LAB_007aae64_1,7);
                    /* try { // try from 002dcb00 to 003dcb05 has its CatchHandler @ 002dea0f */
                (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                          (uVar41,&LAB_007ab014_4,8);
              }
            }
            (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                      (PTR_cout_008cab98,&LAB_007be511,1);
            local_c08 = 0;
            bVar7 = true;
            bVar14 = false;
            plVar64 = (long *)PTR_cout_008cab98;
            pcVar59 = (code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00;
            local_ca4 = local_ca8;
            local_c38 = uVar62;
            local_c10 = lVar63;
            local_c30 = _Var26;
          }
        }
      }
    }
  }
  if (local_ac9 == 1) {
    local_1b8 = (undefined1  [16])0x0;
    auVar12[0xf] = 0;
    auVar12._0_15_ = stack0xfffffffffffffe59;
    _local_1a8 = auVar12 << 8;
    cVar31 = Topic<droneforge::core::runtime::ArmMessage,32ul>::Subscription::TryRead
                       ((Subscription *)&local_2c8,(ArmMessage *)local_1b8);
    if (cVar31 != '\0') {
      do {
        cVar31 = Topic<droneforge::core::runtime::ArmMessage,32ul>::Subscription::TryRead
                           ((Subscription *)&local_2c8,(ArmMessage *)local_1b8);
      } while (cVar31 != '\0');
                    /* try { // try from 002dc7cf to 003dc7d4 has its CatchHandler @ 002deaa7 */
      if (((local_1a8[0] == (_Optional_payload_base)0x1) &&
          (uVar41 = local_1b8._8_8_, local_c18 <= (ulong)local_1b8._8_8_)) &&
         (local_bd8 <= (ulong)local_1b8._8_8_)) {
        if (!bVar18) {
          (*pcVar59)(plVar64,&LAB_007b3211_1,0x2a);
          uVar41 = (*(code *)PTR__M_insert<unsigned_long>_008ca870)(plVar64,uVar41);
                    /* try { // try from 002dc82e to 003dc836 has its CatchHandler @ 002de9a6 */
          (*pcVar59)(uVar41,&LAB_007be511,1);
        }
        if (local_b40 < local_ae0) {
          local_ae0 = local_b40;
        }
        lVar63 = local_b40;
        if (local_c80 < local_b40) {
          lVar63 = local_c80;
        }
        if (!bVar15) {
          local_c80 = lVar63;
        }
        bVar18 = true;
        bVar19 = true;
      }
    }
  }
  bVar25 = local_3c8;
  pcVar24 = local_3e0;
  pcVar65 = local_3e8;
  bVar57 = local_ac9;
  bVar54 = local_aca;
  bVar32 = local_ae1;
  lVar63 = local_b40;
  if (local_ac9 == 0) {
                    /* try { // try from 002dcbb4 to 003dcc82 has its CatchHandler @ 002dabf0 */
    bVar20 = false;
  }
  else if ((local_4b8 & 1) == 0) {
    if (!bVar20) {
      local_be8 = local_b40;
    }
    bVar20 = true;
  }
  else {
    bVar20 = false;
  }
  bVar68 = true;
  if ((local_3c8 == 1) && (pcVar22 = local_3e8, pcVar44 = local_3e0, local_3e0 != (char *)0x0)) {
    while( true ) {
      if ((pcVar44 < (char *)0x10) ||
         (pcVar44 = (char *)(*(code *)PTR_memchr_008caaf0)(pcVar22,0x4c,pcVar44 + -0xf),
         plVar64 = (long *)PTR_cout_008cab98, pcVar44 == (char *)0x0)) goto LAB_002dccc0;
      auVar70[0] = -(*pcVar44 == DAT_007a5c80);
      auVar70[1] = -(pcVar44[1] == UNK_007a5c81);
      auVar70[2] = -(pcVar44[2] == UNK_007a5c82);
      auVar70[3] = -(pcVar44[3] == UNK_007a5c83);
      auVar70[4] = -(pcVar44[4] == UNK_007a5c84);
      auVar70[5] = -(pcVar44[5] == UNK_007a5c85);
      auVar70[6] = -(pcVar44[6] == LAB_007a5c86);
      auVar70[7] = -(pcVar44[7] == cRam00000000007a5c87);
      auVar70[8] = -(pcVar44[8] == cRam00000000007a5c88);
      auVar70[9] = -(pcVar44[9] == cRam00000000007a5c89);
      auVar70[10] = -(pcVar44[10] == cRam00000000007a5c8a);
      auVar70[0xb] = -(pcVar44[0xb] == LAB_007a5c8a_1);
      auVar70[0xc] = -(pcVar44[0xc] == cRam00000000007a5c8c);
      auVar70[0xd] = -(pcVar44[0xd] == cRam00000000007a5c8d);
      auVar70[0xe] = -(pcVar44[0xe] == cRam00000000007a5c8e);
      auVar70[0xf] = -(pcVar44[0xf] == cRam00000000007a5c8f);
      if ((ushort)((ushort)(SUB161(auVar70 >> 7,0) & 1) |
                   (ushort)(SUB161(auVar70 >> 0xf,0) & 1) << 1 |
                   (ushort)(SUB161(auVar70 >> 0x17,0) & 1) << 2 |
                   (ushort)(SUB161(auVar70 >> 0x1f,0) & 1) << 3 |
                   (ushort)(SUB161(auVar70 >> 0x27,0) & 1) << 4 |
                   (ushort)(SUB161(auVar70 >> 0x2f,0) & 1) << 5 |
                   (ushort)(SUB161(auVar70 >> 0x37,0) & 1) << 6 |
                   (ushort)(SUB161(auVar70 >> 0x3f,0) & 1) << 7 |
                   (ushort)(SUB161(auVar70 >> 0x47,0) & 1) << 8 |
                   (ushort)(SUB161(auVar70 >> 0x4f,0) & 1) << 9 |
                   (ushort)(SUB161(auVar70 >> 0x57,0) & 1) << 10 |
                   (ushort)(SUB161(auVar70 >> 0x5f,0) & 1) << 0xb |
                   (ushort)(SUB161(auVar70 >> 0x67,0) & 1) << 0xc |
                   (ushort)(SUB161(auVar70 >> 0x6f,0) & 1) << 0xd |
                   (ushort)(SUB161(auVar70 >> 0x77,0) & 1) << 0xe |
                  (ushort)(auVar70[0xf] >> 7) << 0xf) == 0xffff) break;
                    /* try { // try from 002dcc83 to 003dcc88 has its CatchHandler @ 002de9f9 */
                    /* try { // try from 002dcc89 to 003dcd23 has its CatchHandler @ 002dabf0 */
      pcVar22 = pcVar44 + 1;
      pcVar44 = pcVar65 + ((long)pcVar24 - (long)(pcVar44 + 1));
    }
    bVar68 = (long)pcVar44 - (long)pcVar65 == -1;
  }
LAB_002dccc0:
  auVar75 = _local_1a8;
  bVar32 = (bVar32 ^ 1) & bVar57 & bVar54;
  bVar54 = (local_440 ^ 1) & bVar68 & bVar32;
  lVar60 = lVar63;
  if (bVar34 != 0) {
    lVar60 = local_c40;
  }
  if (bVar54 == 0) {
    lVar60 = local_c40;
  }
  bVar32 = (bVar25 ^ 1) & bVar32;
  if ((bVar55 & 1) != 0) {
    lVar63 = local_c00;
  }
  if (bVar32 == 0) {
    lVar63 = local_c00;
  }
                    /* try { // try from 002dcd24 to 003dcd29 has its CatchHandler @ 002de997 */
  local_1b8 = (undefined1  [16])0x0;
  auStack_1a6._6_4_ = 0xac00ac;
  _local_1a8 = 0x3e000ac03e003e0;
  uStack_19c = 0xac;
  uStack_199 = auVar75[0xf];
  cStack_19a = 0xc;
  cVar31 = Topic<droneforge::core::runtime::ControlsMessage,512ul>::Subscription::TryRead
                     ((Subscription *)&local_200,(ControlsMessage *)local_1b8);
  if (cVar31 != '\0') {
    do {
      cVar31 = Topic<droneforge::core::runtime::ControlsMessage,512ul>::Subscription::TryRead
                         ((Subscription *)&local_200,(ControlsMessage *)local_1b8);
    } while (cVar31 != '\0');
    local_ac8 = _local_1a8;
    local_ac0 = auStack_1a6._6_4_;
    local_abc = uStack_19c;
    local_c85 = cStack_19a != '\x01';
  }
  local_a98 = (undefined1  [16])0x0;
  local_a88 = '@';
  local_a83 = 0;
  local_a87 = 0;
  while (cVar31 = Topic<droneforge::core::runtime::NimbusCommandMessage,32ul>::Subscription::TryRead
                            ((Subscription *)&local_228,(NimbusCommandMessage *)local_a98),
        puVar43 = PTR___ostream_insert<char,std_char_traits<char>>_008cab00, cVar31 != '\0') {
    local_ab8 = (undefined1  [16])0x0;
    local_aa8 = 0;
    local_1d8 = local_1c8;
    puStack_1d0 = (undefined1 *)0x0;
    local_1c8[0] = (undefined1 *)((ulong)local_1c8[0] & 0xffffffffffffff00);
    bVar68 = true;
    pcVar65 = (char *)0x0;
    switch(local_a88) {
    case '@':
      cVar31 = crsf::CrsfTransmitEncoder::EncodeVideoReceiverScanFrame
                         (*(CrsfTransmitEncoder **)(this + 0x58),(vector *)local_ab8);
      pcVar65 = "scan";
joined_r0x002dcfe9:
      if (cVar31 == '\0') {
        bVar68 = false;
        goto switchD_002dce92_caseD_41;
      }
      cVar31 = io::SerialLinkWriter::Transmit
                         (*(undefined8 *)(this + 0x50),local_ab8._0_8_,
                          local_ab8._8_8_ - local_ab8._0_8_);
      if (cVar31 == '\0') {
        (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                  (PTR_cerr_008caf98,&LAB_007b3356_1,0x23);
                    /* try { // try from 002dd6af to 003dd6ea has its CatchHandler @ 002de9b5 */
        uVar41 = (*(code *)PTR__M_insert<unsigned_long>_008ca870)(PTR_cerr_008caf98,local_a98._0_8_)
        ;
        (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)(uVar41," command=",9);
        uVar45 = (*(code *)PTR_strlen_008ca708)(pcVar65);
        (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)(uVar41,pcVar65,uVar45);
                    /* try { // try from 002dd6eb to 003ddbd0 has its CatchHandler @ 002dabf0 */
        if (puStack_1d0 != (undefined1 *)0x0) {
          (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                    (PTR_cerr_008caf98,&LAB_007b318f,5);
          (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                    (PTR_cerr_008caf98,local_1d8,puStack_1d0);
        }
        (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                  (PTR_cerr_008caf98,&LAB_007b36c0_2,7);
        io::SerialLinkWriter::LastError_abi_cxx11_();
        plVar48 = (long *)(*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                                    (PTR_cerr_008caf98,local_1b8._0_8_,local_1b8._8_8_);
        plVar50 = *(long **)((long)plVar48 + *(long *)(*plVar48 + -0x18) + 0xf0);
        if (plVar50 != (long *)0x0) {
          if ((char)plVar50[7] == '\0') {
            (*(code *)PTR__M_widen_init_008cab08)(plVar50);
            cVar31 = (**(code **)(*plVar50 + 0x30))(plVar50,10);
          }
          else {
            cVar31 = *(char *)((long)plVar50 + 0x43);
          }
          uVar41 = (*(code *)PTR_put_008ca520)(plVar48,(int)cVar31);
          (*(code *)PTR_flush_008ca878)(uVar41);
          if ((undefined1 *)local_1b8._0_8_ != local_1a8) {
            (*(code *)puVar23)(local_1b8._0_8_,_local_1a8 + 1);
          }
          goto LAB_002ddf44;
        }
        goto LAB_002dfab2;
      }
      (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                (PTR_cerr_008caf98,&DAT_007b337b,0x1f);
      uVar41 = (*(code *)PTR__M_insert<unsigned_long>_008ca870)(PTR_cerr_008caf98,local_a98._0_8_);
      (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)(uVar41," command=",9);
      uVar45 = (*(code *)PTR_strlen_008ca708)(pcVar65);
      (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)(uVar41,pcVar65,uVar45);
      if (puStack_1d0 != (undefined1 *)0x0) {
        (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                  (PTR_cerr_008caf98,&LAB_007b318f,5);
        (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                  (PTR_cerr_008caf98,local_1d8,puStack_1d0);
      }
      plVar50 = *(long **)(PTR_cerr_008caf98 + *(long *)(*(long *)PTR_cerr_008caf98 + -0x18) + 0xf0)
      ;
      if (plVar50 == (long *)0x0) goto LAB_002dfa95;
      if ((char)plVar50[7] == '\0') {
        (*(code *)PTR__M_widen_init_008cab08)(plVar50);
        cVar31 = (**(code **)(*plVar50 + 0x30))(plVar50,10);
      }
      else {
        cVar31 = *(char *)((long)plVar50 + 0x43);
      }
      uVar41 = (*(code *)PTR_put_008ca520)(PTR_cerr_008caf98,(int)cVar31);
      (*(code *)PTR_flush_008ca878)(uVar41);
      if (local_a88 == '\x01') {
        local_c08 = local_b40 + 30000000000;
      }
      goto LAB_002ddf44;
    case 'A':
      goto switchD_002dce92_caseD_41;
    case 'B':
      (*(code *)PTR_ios_base_008ca628)(local_148);
      puVar43 = PTR_init_008cac18;
      local_70 = 0;
      local_68 = 0;
      local_50 = (undefined1  [16])0x0;
      local_60 = (undefined1  [16])0x0;
      local_148[0] = puVar37;
      local_1b8._0_8_ = lVar5;
      *(undefined8 *)(local_1b8 + *(long *)(lVar5 + -0x18)) = uVar53;
      (*(code *)PTR_init_008cac18)(local_1b8 + *(long *)(local_1b8._0_8_ + -0x18),0);
      local_148[0] = PTR_vtable_008caa08 + 0x40;
      local_1b8._8_8_ = puVar38;
      local_1b8._0_8_ = PTR_vtable_008caa08 + 0x18;
      local_188 = (undefined1  [16])0x0;
      _local_198 = (undefined1  [16])0x0;
      _local_1a8 = (undefined1  [16])0x0;
      (*(code *)PTR_locale_008cafe0)(&local_178);
      local_1b8._8_8_ = puVar39;
      local_170 = (long *)CONCAT44(local_170._4_4_,0x10);
      local_168 = (SerialOutboundFrameLoop *)&local_158;
      local_160 = (undefined1 *)0x0;
      local_158 = (long *)((ulong)local_158 & 0xffffffffffffff00);
      (*(code *)puVar43)(local_1b8 + *(long *)(local_1b8._0_8_ + -0x18),local_1b8 + 8);
      puVar43 = PTR___ostream_insert<char,std_char_traits<char>>_008cab00;
      *(uint *)(auStack_1a6 + *(long *)(local_1b8._0_8_ + -0x18) + 6) =
           *(uint *)(auStack_1a6 + *(long *)(local_1b8._0_8_ + -0x18) + 6) & 0xffffffb5 | 8;
      lVar49 = *(long *)(local_1b8._0_8_ + -0x18);
      lVar46 = local_1b8._0_8_;
      if (acStack_d8[lVar49 + 1] == '\0') {
        plVar50 = *(long **)((long)&lStack_c8 + lVar49);
        if (plVar50 != (long *)0x0) {
          if ((char)plVar50[7] == '\0') {
            (*(code *)PTR__M_widen_init_008cab08)(plVar50);
            (**(code **)(*plVar50 + 0x30))(plVar50,0x20);
          }
          acStack_d8[lVar49 + 1] = '\x01';
          lVar46 = local_1b8._0_8_;
          goto LAB_002dd396_1;
        }
        goto LAB_002dfacf;
      }
LAB_002dd396_1:
      acStack_d8[lVar49] = '0';
                    /* try { // try from 002dd39b to 003dd5fb has its CatchHandler @ 002dabf0 */
      *(undefined8 *)(local_1a8 + *(long *)(lVar46 + -0x18)) = 2;
      (*(code *)PTR_operator<<_008cae78)(local_1b8,local_a87._0_1_);
      (*(code *)puVar43)(local_1b8,&LAB_007b6e07_1,1);
      *(undefined8 *)(local_1a8 + *(long *)(local_1b8._0_8_ + -0x18)) = 2;
      (*(code *)PTR_operator<<_008cae78)(local_1b8,local_a87._1_1_);
      (*(code *)puVar43)(local_1b8,&LAB_007b6e07_1,1);
      *(undefined8 *)(local_1a8 + *(long *)(local_1b8._0_8_ + -0x18)) = 2;
      (*(code *)PTR_operator<<_008cae78)(local_1b8,local_a87._2_1_);
      (*(code *)puVar43)(local_1b8,&LAB_007b6e07_1,1);
      *(undefined8 *)(local_1a8 + *(long *)(local_1b8._0_8_ + -0x18)) = 2;
      (*(code *)PTR_operator<<_008cae78)(local_1b8,local_a87._3_1_);
      (*(code *)puVar43)(local_1b8,&LAB_007b6e07_1,1);
      *(undefined8 *)(local_1a8 + *(long *)(local_1b8._0_8_ + -0x18)) = 2;
      (*(code *)PTR_operator<<_008cae78)(local_1b8,(undefined1)local_a83);
      (*(code *)puVar43)(local_1b8,&LAB_007b6e07_1,1);
      *(undefined8 *)(local_1a8 + *(long *)(local_1b8._0_8_ + -0x18)) = 2;
      (*(code *)PTR_operator<<_008cae78)(local_1b8);
      puVar56 = local_160;
      puVar58 = local_a18[0];
      local_a28._0_8_ = local_a18;
      local_a28._8_8_ = 0;
      local_a18[0] = (undefined1 *)((ulong)local_a18[0] & 0xffffffffffffff00);
      puVar27 = local_a18[0];
      auVar66 = local_198;
      if ((ulong)local_198 < (ulong)local_188._0_8_) {
        auVar66 = (undefined1  [8])local_188._0_8_;
      }
      local_a18[0]._1_7_ = SUB87(puVar58,1);
      local_a18[0] = puVar27;
      if ((local_188._0_8_ != 0) && (auVar66 != (undefined1  [8])0x0)) {
        uVar62 = (long)auVar66 - (long)ppuStack_190;
        if (-1 < (long)uVar62) {
          if (uVar62 < 0x10) {
            if (local_a18 == ppuStack_190) {
                    /* try { // try from 002ddf9e to 003ddfa6 has its CatchHandler @ 002dea19 */
              (*(code *)PTR__M_replace_cold_008cac68)(local_a28,local_a18,0,ppuStack_190,uVar62);
              puVar27 = local_a18[0];
            }
            else if (uVar62 != 0) {
              if (uVar62 == 1) {
                local_a18[0] = (undefined1 *)
                               CONCAT71(local_a18[0]._1_7_,*(undefined1 *)ppuStack_190);
                puVar27 = local_a18[0];
              }
              else {
                (*(code *)PTR_memcpy_008ca960)(local_a18,ppuStack_190,uVar62);
                puVar27 = local_a18[0];
              }
            }
          }
          else {
            std::__cxx11::string::_M_mutate((string *)local_a28,0,0,(char *)ppuStack_190,uVar62);
            puVar27 = local_a18[0];
          }
          local_a18[0] = puVar27;
          local_a28._8_8_ = uVar62;
          *(undefined1 *)(local_a28._0_8_ + uVar62) = 0;
          puVar27 = local_a18[0];
          goto LAB_002ddc35;
        }
        goto LAB_002dfafb;
      }
      if (local_160 < &working_state_cur_put_buffer_simd) {
        if (local_160 == (undefined1 *)0x0) goto LAB_002ddc35;
        if (local_160 != (undefined1 *)0x1) {
          ppuVar47 = local_a18;
          goto LAB_002ddc1c;
        }
        local_a18[0] = (undefined1 *)CONCAT71(local_a18[0]._1_7_,*local_168);
        ppuVar47 = local_a18;
LAB_002ddc28:
        local_a28._8_8_ = puVar56;
        *(undefined1 *)((long)ppuVar47 + (long)puVar56) = 0;
        puVar27 = local_a18[0];
LAB_002ddc35:
        local_a18[0] = puVar27;
        local_1b8._0_8_ = lVar4;
        *(undefined8 *)(local_1b8 + *(long *)(lVar4 + -0x18)) = uVar6;
        local_1b8._8_8_ = puVar39;
        if (local_168 != (SerialOutboundFrameLoop *)&local_158) {
          (*(code *)puVar23)(local_168,(long)local_158 + 1);
        }
        local_1b8._8_8_ = puVar38;
        (*(code *)PTR__locale_008cacb0)(&local_178);
        (*(code *)PTR__ios_base_008ca658)(local_148);
        puVar58 = local_1c8[0];
        ppuVar47 = local_1d8;
        if (local_1d8 == local_1c8) {
          if ((undefined1 **)local_a28._0_8_ == local_a18) goto LAB_002ddd5a;
LAB_002ddd45:
          local_1c8[0] = local_a18[0];
          puStack_1d0 = (undefined1 *)local_a28._8_8_;
          local_1d8 = (undefined1 **)local_a28._0_8_;
          local_a28._0_8_ = local_a18;
                    /* try { // try from 002ddd4d to 003ddd5c has its CatchHandler @ 002deb1b */
        }
        else if ((undefined1 **)local_a28._0_8_ == local_a18) {
LAB_002ddd5a:
          if ((undefined1 *)local_a28._8_8_ != (undefined1 *)0x0) {
            if ((undefined1 *)local_a28._8_8_ == (undefined1 *)0x1) {
              *(undefined1 *)local_1d8 = *(undefined1 *)local_a28._0_8_;
            }
            else {
                    /* try { // try from 002ddd78 to 003ddd8c has its CatchHandler @ 002deb20 */
              (*(code *)PTR_memcpy_008ca960)();
            }
          }
          puStack_1d0 = (undefined1 *)local_a28._8_8_;
          *(undefined1 *)((long)local_1d8 + local_a28._8_8_) = 0;
        }
        else {
          local_1d8 = (undefined1 **)local_a28._0_8_;
          puStack_1d0 = (undefined1 *)local_a28._8_8_;
          local_1c8[0] = local_a18[0];
          if (ppuVar47 == (undefined1 **)0x0) goto LAB_002ddd45;
          local_a28._0_8_ = ppuVar47;
          local_a18[0] = puVar58;
        }
                    /* try { // try from 002dddaf to 003dde7b has its CatchHandler @ 002dabf0 */
        local_a28._8_8_ = 0;
        *(undefined1 *)local_a28._0_8_ = 0;
        if ((undefined1 **)local_a28._0_8_ != local_a18) {
          (*(code *)puVar23)(local_a28._0_8_,local_a18[0] + 1);
        }
        cVar31 = crsf::CrsfTransmitEncoder::EncodeSetBindUidFrame
                           (*(CrsfTransmitEncoder **)(this + 0x58),(array *)&local_a87,
                            (vector *)local_ab8);
        pcVar65 = "set bind uid";
        goto joined_r0x002dcfe9;
      }
      if ((long)local_160 < 0) goto LAB_002dfaec;
      puVar58 = (undefined1 *)0x1e;
      if ((undefined1 *)0x1e < local_160) {
        puVar58 = local_160;
      }
      if (-1 < (long)(puVar58 + 1)) {
        ppuVar47 = (undefined1 **)(*(code *)PTR_operator_new_008caa38)();
        local_a28._0_8_ = ppuVar47;
        local_a18[0] = puVar58;
LAB_002ddc1c:
        (*(code *)PTR_memcpy_008ca960)(ppuVar47,local_168,puVar56);
        goto LAB_002ddc28;
      }
      if (*(long *)(in_FS_OFFSET + 0x28) == local_38) {
        (*(code *)PTR___throw_bad_alloc_008ca690)();
        goto LAB_002dfa95;
      }
      goto LAB_002e0448;
    case 'C':
      if ((ushort)local_ac0 < 0x1f5) {
        DisarmCommand();
        local_ad0 = (uint)extraout_RDX & 0xffff0000 | 0xac;
        local_ad8 = 0xac00ac00ac03e0;
        local_acc = (undefined2)((ulong)extraout_RDX >> 0x20);
        local_bc8 = local_b40 + 1000000000;
        (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                  (PTR_cerr_008caf98,&LAB_007b3297_1,0x24);
        uVar41 = (*(code *)PTR__M_insert<unsigned_long>_008ca870)(PTR_cerr_008caf98,local_a98._0_8_)
        ;
        (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)(uVar41," command=",9);
        (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                  (uVar41,&LAB_007b324e_1,0xe);
        (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                  (uVar41,&LAB_007b30fa_4,0xd);
        plVar48 = (long *)(*(code *)PTR__M_insert<long>_008ca9e8)(uVar41,1000);
        plVar50 = *(long **)((long)plVar48 + *(long *)(*plVar48 + -0x18) + 0xf0);
        if (plVar50 == (long *)0x0) goto LAB_002dfa95;
        if ((char)plVar50[7] == '\0') {
          (*(code *)PTR__M_widen_init_008cab08)(plVar50);
          cVar31 = (**(code **)(*plVar50 + 0x30))(plVar50,10);
        }
        else {
          cVar31 = *(char *)((long)plVar50 + 0x43);
        }
        uVar41 = (*(code *)PTR_put_008ca520)(plVar48,(int)cVar31);
        bVar17 = true;
        (*(code *)PTR_flush_008ca878)(uVar41);
        local_bd0 = &LAB_007b324e_1;
        goto LAB_002ddf44;
      }
      (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                (PTR_cerr_008caf98,&LAB_007b325d_1,0x1c);
      plVar48 = (long *)(*(code *)PTR__M_insert<unsigned_long>_008ca870)
                                  (PTR_cerr_008caf98,local_a98._0_8_);
      (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)(plVar48," command=",9);
      (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                (plVar48,&LAB_007b324e_1,0xe);
      (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                (plVar48,&LAB_007b327a_1,0x1c);
      plVar50 = *(long **)((long)plVar48 + *(long *)(*plVar48 + -0x18) + 0xf0);
      if (plVar50 == (long *)0x0) goto LAB_002dfa95;
      if ((char)plVar50[7] == '\0') {
        (*(code *)PTR__M_widen_init_008cab08)(plVar50);
        cVar31 = (**(code **)(*plVar50 + 0x30))(plVar50,10);
        goto LAB_002ddf2f;
      }
      goto LAB_002ddf11;
    case 'D':
      if ((ushort)local_ac0 < 0x1f5) {
        DisarmCommand();
        local_ad0 = (uint)extraout_RDX_00 & 0xffff0000 | 0xac;
        local_ad8 = 0xac070800ac03e0;
        local_acc = (undefined2)((ulong)extraout_RDX_00 >> 0x20);
        local_bc8 = local_b40 + 1000000000;
        (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                  (PTR_cerr_008caf98,&LAB_007b3297_1,0x24);
        uVar41 = (*(code *)PTR__M_insert<unsigned_long>_008ca870)(PTR_cerr_008caf98,local_a98._0_8_)
        ;
        (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)(uVar41," command=",9);
        (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                  (uVar41,&LAB_007b32bc_1,0x17);
        (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                  (uVar41,&LAB_007b30fa_4,0xd);
        plVar48 = (long *)(*(code *)PTR__M_insert<long>_008ca9e8)(uVar41,1000);
        plVar50 = *(long **)((long)plVar48 + *(long *)(*plVar48 + -0x18) + 0xf0);
        if (plVar50 != (long *)0x0) {
          if ((char)plVar50[7] == '\0') {
            (*(code *)PTR__M_widen_init_008cab08)(plVar50);
            cVar31 = (**(code **)(*plVar50 + 0x30))(plVar50,10);
          }
          else {
            cVar31 = *(char *)((long)plVar50 + 0x43);
          }
          uVar41 = (*(code *)PTR_put_008ca520)(plVar48,(int)cVar31);
          bVar17 = true;
          (*(code *)PTR_flush_008ca878)(uVar41);
          local_bd0 = &LAB_007b32bc_1;
          goto LAB_002ddf44;
        }
        goto LAB_002dfa95;
      }
      (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                (PTR_cerr_008caf98,&LAB_007b325d_1,0x1c);
      plVar48 = (long *)(*(code *)PTR__M_insert<unsigned_long>_008ca870)
                                  (PTR_cerr_008caf98,local_a98._0_8_);
      (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)(plVar48," command=",9);
      (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                (plVar48,&LAB_007b32bc_1,0x17);
      (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                (plVar48,&LAB_007b327a_1,0x1c);
      plVar50 = *(long **)((long)plVar48 + *(long *)(*plVar48 + -0x18) + 0xf0);
      if (plVar50 == (long *)0x0) goto LAB_002dfa95;
      if ((char)plVar50[7] != '\0') goto LAB_002ddf11;
      (*(code *)PTR__M_widen_init_008cab08)(plVar50);
      cVar31 = (**(code **)(*plVar50 + 0x30))(plVar50,10);
      goto LAB_002ddf2f;
    case 'E':
      if (local_ae2 == (_Optional_payload_base)0x0) {
        (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                  (PTR_cerr_008caf98,&LAB_007b325d_1,0x1c);
        plVar48 = (long *)(*(code *)PTR__M_insert<unsigned_long>_008ca870)
                                    (PTR_cerr_008caf98,local_a98._0_8_);
        (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)(plVar48," command=",9);
        (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                  (plVar48,&LAB_007b32d5,0x23);
        (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                  (plVar48,&LAB_007b32f8_1,0x19);
        plVar50 = *(long **)((long)plVar48 + *(long *)(*plVar48 + -0x18) + 0xf0);
        if (plVar50 != (long *)0x0) {
          if ((char)plVar50[7] != '\0') goto LAB_002ddf11;
          (*(code *)PTR__M_widen_init_008cab08)(plVar50);
          cVar31 = (**(code **)(*plVar50 + 0x30))(plVar50,10);
          goto LAB_002ddf2f;
        }
      }
      else {
        local_bb0 = local_b40 + 1000000000;
        (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                  (PTR_cerr_008caf98,&LAB_007b3311_2,0x26);
        uVar41 = (*(code *)PTR__M_insert<unsigned_long>_008ca870)(PTR_cerr_008caf98,local_a98._0_8_)
        ;
        (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)(uVar41," command=",9);
        (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                  (uVar41,&LAB_007b32d5,0x23);
        (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                  (uVar41,&LAB_007b30fa_4,0xd);
        plVar48 = (long *)(*(code *)PTR__M_insert<long>_008ca9e8)(uVar41,1000);
        plVar50 = *(long **)((long)plVar48 + *(long *)(*plVar48 + -0x18) + 0xf0);
        if (plVar50 != (long *)0x0) {
          if ((char)plVar50[7] == '\0') {
            (*(code *)PTR__M_widen_init_008cab08)(plVar50);
            cVar31 = (**(code **)(*plVar50 + 0x30))(plVar50,10);
          }
          else {
            cVar31 = *(char *)((long)plVar50 + 0x43);
          }
          uVar41 = (*(code *)PTR_put_008ca520)(plVar48,(int)cVar31);
          bVar16 = true;
          (*(code *)PTR_flush_008ca878)(uVar41);
          goto LAB_002ddf44;
        }
      }
      goto LAB_002dfa95;
    }
    if (local_a88 == '\x01') {
      cVar31 = crsf::CrsfTransmitEncoder::EncodeReceiverBindFrame
                         (*(CrsfTransmitEncoder **)(this + 0x58),(vector *)local_ab8);
      pcVar65 = "bind";
      goto joined_r0x002dcfe9;
    }
switchD_002dce92_caseD_41:
    (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
              (PTR_cerr_008caf98,&LAB_007b3338_2,0x1c);
    if (!bVar68) {
      (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                (PTR_cerr_008caf98," command=",9);
      if (pcVar65 == (char *)0x0) {
        (*(code *)PTR_clear_008cae58)
                  (PTR_cerr_008caf98 + *(long *)(*(long *)PTR_cerr_008caf98 + -0x18),
                   *(uint *)(PTR_cerr_008caf98 +
                            *(long *)(*(long *)PTR_cerr_008caf98 + -0x18) + 0x20) | 1);
      }
      else {
        uVar41 = (*(code *)PTR_strlen_008ca708)(pcVar65);
        (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                  (PTR_cerr_008caf98,pcVar65,uVar41);
      }
    }
                    /* try { // try from 002dde85 to 003ddf1f has its CatchHandler @ 002dabf0 */
    if (puStack_1d0 != (undefined1 *)0x0) {
      (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                (PTR_cerr_008caf98,&LAB_007b318f,5);
      (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                (PTR_cerr_008caf98,local_1d8,puStack_1d0);
    }
    (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
              (PTR_cerr_008caf98,&LAB_007b406c,5);
    plVar48 = (long *)(*(code *)PTR__M_insert<unsigned_long>_008ca870)
                                (PTR_cerr_008caf98,local_a98._0_8_);
    plVar50 = *(long **)((long)plVar48 + *(long *)(*plVar48 + -0x18) + 0xf0);
    if (plVar50 == (long *)0x0) {
LAB_002dfa95:
      if (*(long *)(in_FS_OFFSET + 0x28) != local_38) goto LAB_002e0448;
      (*(code *)PTR___throw_bad_cast_008cab80)();
LAB_002dfab2:
      if (*(long *)(in_FS_OFFSET + 0x28) != local_38) goto LAB_002e0448;
      (*(code *)PTR___throw_bad_cast_008cab80)();
LAB_002dfacf:
      if (*(long *)(in_FS_OFFSET + 0x28) != local_38) goto LAB_002e0448;
      (*(code *)PTR___throw_bad_cast_008cab80)();
LAB_002dfaec:
      local_bc0 = &LAB_007a9e33_3;
      puVar27 = local_a18[0];
LAB_002dfafb:
      local_a18[0] = puVar27;
      if (*(long *)(in_FS_OFFSET + 0x28) != local_38) goto LAB_002e0448;
      (*(code *)PTR___throw_length_error_008ca788)(local_bc0);
      goto LAB_002dfb20;
    }
    if ((char)plVar50[7] == '\0') {
                    /* try { // try from 002ddf20 to 003ddf2f has its CatchHandler @ 002dea9b */
      (*(code *)PTR__M_widen_init_008cab08)(plVar50);
      cVar31 = (**(code **)(*plVar50 + 0x30))(plVar50,10);
    }
    else {
LAB_002ddf11:
      cVar31 = *(char *)((long)plVar50 + 0x43);
    }
LAB_002ddf2f:
                    /* try { // try from 002ddf3a to 003ddf51 has its CatchHandler @ 002deab6 */
    uVar41 = (*(code *)PTR_put_008ca520)(plVar48,(int)cVar31);
    (*(code *)PTR_flush_008ca878)(uVar41);
LAB_002ddf44:
    if (local_1d8 != local_1c8) {
      (*(code *)puVar23)(local_1d8,local_1c8[0] + 1);
    }
    if (local_ab8._0_8_ != 0) {
      (*(code *)puVar23)(local_ab8._0_8_,local_aa8 - local_ab8._0_8_);
    }
  }
  if (!bVar17) {
    bVar17 = false;
LAB_002de02f:
    if (bVar16) {
LAB_002de03a:
      if ((local_ae2 != (_Optional_payload_base)0x1) || (bVar16 = true, local_bb0 <= local_b40)) {
        (*(code *)puVar43)(PTR_cerr_008caf98,"nimbus command aux5 pulse complete command=",0x2b);
        (*(code *)puVar43)(PTR_cerr_008caf98,&LAB_007b32d5,0x23);
        (*(code *)puVar43)(PTR_cerr_008caf98,&DAT_007b3446,8);
        pcVar65 = "vehicle-disarmed";
        if (local_ae2 != (_Optional_payload_base)0x0) {
          pcVar65 = "duration-complete";
        }
        (*(code *)puVar43)(PTR_cerr_008caf98,pcVar65,(byte)local_ae2 | 0x10);
        plVar50 = *(long **)(PTR_cerr_008caf98 +
                            *(long *)(*(long *)PTR_cerr_008caf98 + -0x18) + 0xf0);
        if (plVar50 == (long *)0x0) goto LAB_002dfb3d;
        if ((char)plVar50[7] == '\0') {
          (*(code *)PTR__M_widen_init_008cab08)(plVar50);
          cVar31 = (**(code **)(*plVar50 + 0x30))(plVar50,10);
        }
        else {
          cVar31 = *(char *)((long)plVar50 + 0x43);
        }
        uVar41 = (*(code *)PTR_put_008ca520)(PTR_cerr_008caf98,(int)cVar31);
        (*(code *)PTR_flush_008ca878)(uVar41);
        goto LAB_002de1ea;
      }
    }
    else {
LAB_002de1ea:
      bVar16 = false;
    }
    cVar67 = '\x04';
    cVar31 = '\x01';
    if (local_53c == 1) {
      cVar67 = '\x04';
      cVar31 = '\x01';
      runtime::(anonymous_namespace)::FormatFlightControllerUid_abi_cxx11_((array *)local_1b8);
      lVar49 = std::
               _Hashtable<std::__cxx11::string,std::pair<std::__cxx11::string_const,droneforge::core::runtime::VtxPowerConfigMessage>,std::allocator<std::pair<std::__cxx11::string_const,droneforge::core::runtime::VtxPowerConfigMessage>>,std::__detail::_Select1st,std::equal_to<std::__cxx11::string>,std::hash<std::__cxx11::string>,std::__detail::_Mod_range_hashing,std::__detail::_Default_ranged_hash,std::__detail::_Prime_rehash_policy,std::__detail::_Hashtable_traits<true,false,true>>
               ::find((_Hashtable<std::__cxx11::string,std::pair<std::__cxx11::string_const,droneforge::core::runtime::VtxPowerConfigMessage>,std::allocator<std::pair<std::__cxx11::string_const,droneforge::core::runtime::VtxPowerConfigMessage>>,std::__detail::_Select1st,std::equal_to<std::__cxx11::string>,std::hash<std::__cxx11::string>,std::__detail::_Mod_range_hashing,std::__detail::_Default_ranged_hash,std::__detail::_Prime_rehash_policy,std::__detail::_Hashtable_traits<true,false,true>>
                       *)&local_b20,(string *)local_1b8);
                    /* try { // try from 002de240 to 003de251 has its CatchHandler @ 002deb20 */
      if ((undefined1 *)local_1b8._0_8_ != local_1a8) {
        (*(code *)puVar23)(local_1b8._0_8_,_local_1a8 + 1);
      }
                    /* try { // try from 002de252 to 003de40b has its CatchHandler @ 002dabf0 */
      if (lVar49 != 0) {
        cVar31 = *(char *)(lVar49 + 0x58);
        cVar67 = *(char *)(lVar49 + 0x59);
      }
    }
    local_b41 = cVar31;
    if (local_ae2 != (_Optional_payload_base)0x0) {
      local_b41 = cVar67;
    }
    local_1b8._8_8_ = &local_aca;
    local_1b8._0_8_ = &local_ac9;
    stack0xfffffffffffffe60 = &local_548;
    _local_1a8 = (long)&local_ae1;
    ppuStack_190 = (undefined1 **)&local_b22;
    local_198 = (undefined1  [8])&local_a78;
    local_188._8_8_ = &local_b40;
    local_188._0_8_ = &local_b41;
    local_178 = &local_b30;
    local_170 = &local_ae0;
    local_168 = this;
    local_160 = &local_b24;
    local_158 = &local_b38;
    local_150 = &local_ae2;
    if (local_ae2 == (_Optional_payload_base)0x1) {
      Run(std::atomic<bool>&)::$_1::operator()((__1 *)local_1b8);
      bVar68 = (bool)((byte)local_ae2 & local_c85);
    }
    else {
      bVar68 = false;
    }
    local_a28 = (undefined1  [16])0x0;
    local_a18[0] = (undefined1 *)0x0;
    puVar42 = &local_ac8;
    if (bVar17) {
      puVar42 = &local_ad8;
    }
    uVar41 = *(undefined8 *)((long)puVar42 + 6);
    local_b50 = (undefined4)*puVar42;
    uStack_b4c = (ushort)((ulong)*puVar42 >> 0x20);
    uStack_b4a = (undefined2)uVar41;
    local_b48 = (ushort)((ulong)uVar41 >> 0x10);
    uStack_b46 = (undefined2)((ulong)uVar41 >> 0x20);
    local_b44 = (undefined2)((ulong)uVar41 >> 0x30);
    fVar69 = (float)core::control::CrsfMapper::CrsfToThrottle01(uStack_b4c);
    uVar62 = (*(code *)PTR_now_008cabf0)();
    iVar35 = OptrangeFailsafe::Update(local_3b8,bVar68,fVar69,uVar62,(optional *)&local_a58);
                    /* try { // try from 002de40c to 003de41d has its CatchHandler @ 002deab6 */
    if (iVar35 != 0) {
                    /* try { // try from 002de41e to 003de5ae has its CatchHandler @ 002dabf0 */
      (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                (PTR_cerr_008caf98,&DAT_007b3434,0x1a);
      pcVar65 = "missing-frames";
      if (iVar35 == 1) {
        pcVar65 = "payload-flatline";
      }
      (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                (PTR_cerr_008caf98,pcVar65,(iVar35 == 1) * '\x02' + '\x0e');
      (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                (PTR_cerr_008caf98," throttle=zero",0xe);
      plVar50 = *(long **)(PTR_cerr_008caf98 + *(long *)(*(long *)PTR_cerr_008caf98 + -0x18) + 0xf0)
      ;
      if (plVar50 == (long *)0x0) {
LAB_002dfb20:
        if (*(long *)(in_FS_OFFSET + 0x28) == local_38) {
          (*(code *)PTR___throw_bad_cast_008cab80)();
          goto LAB_002dfb3d;
        }
        goto LAB_002e0448;
      }
      if ((char)plVar50[7] == '\0') {
        (*(code *)PTR__M_widen_init_008cab08)(plVar50);
        cVar31 = (**(code **)(*plVar50 + 0x30))(plVar50,10);
      }
      else {
        cVar31 = *(char *)((long)plVar50 + 0x43);
      }
      uVar41 = (*(code *)PTR_put_008ca520)(PTR_cerr_008caf98,(int)cVar31);
      (*(code *)PTR_flush_008ca878)(uVar41);
    }
    pcVar59 = (code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00;
    if (local_3b4 != 0) {
      uStack_b4c = 0xac;
    }
    if ((local_ae2 != (_Optional_payload_base)0x1) ||
       ((local_b21 == '\x01' && (local_b22 != cVar67)))) {
      local_b48 = 0xac;
    }
    local_b44 = 0xac;
    if (bVar16) {
      local_b44 = 0x713;
    }
    cVar31 = crsf::CrsfTransmitEncoder::EncodeControlFrame
                       (*(CrsfTransmitEncoder **)(this + 0x58),(RcChannelsCommand *)&local_b50,
                        (vector *)local_a28);
    if (cVar31 == '\0') {
      bVar34 = 0;
    }
    else {
      bVar34 = io::SerialLinkWriter::Transmit
                         (*(undefined8 *)(this + 0x50),local_a28._0_8_,
                          local_a28._8_8_ - local_a28._0_8_);
    }
    local_ab8 = (undefined1  [16])0x0;
    local_aa8 = local_aa8 & 0xffffffffffff0000;
    bVar68 = bVar14;
    while( true ) {
      uVar28 = (uint)local_c38;
                    /* try { // try from 002de638 to 003de644 has its CatchHandler @ 002deaa1 */
      cVar31 = Topic<droneforge::core::runtime::VrxChannelRequestMessage,32ul>::Subscription::
               TryRead((Subscription *)&local_250,(VrxChannelRequestMessage *)local_ab8);
      if (cVar31 == '\0') break;
      (*pcVar59)(plVar64,"vrx connect request received bandCode=",0x26);
                    /* try { // try from 002de65c to 003de668 has its CatchHandler @ 002dea9d */
      uVar41 = (*(code *)PTR_operator<<_008cae78)(plVar64,local_aa8 & 0xff);
      (*pcVar59)(uVar41,&LAB_007aae40_4,9);
                    /* try { // try from 002de680 to 003de68c has its CatchHandler @ 002dea91 */
      (*(code *)PTR_operator<<_008cae78)(uVar41,local_aa8._1_1_);
      uVar62 = (ulong)local_aa8._1_1_;
                    /* try { // try from 002de6a4 to 003de6b0 has its CatchHandler @ 002dea8f */
      if (((byte)(local_aa8._1_1_ - 1) < 8 &&
           (byte)((char)local_aa8._0_1_ << 5 | (byte)local_aa8._0_1_ >> 3) < 6) &&
         ((byte)local_aa8._0_1_ < 0x30)) {
        bVar55 = (byte)local_aa8._0_1_ >> 3;
                    /* try { // try from 002de6c8 to 003de6d4 has its CatchHandler @ 002dea8d */
        sVar2 = *(short *)((ulong)bVar55 * 0x10 + 0x7f007a + uVar62 * 2);
        if (sVar2 != 0) {
                    /* try { // try from 002de6ec to 003de6f8 has its CatchHandler @ 002dea88 */
          cVar31 = "ABEFRL"[bVar55];
                    /* try { // try from 002de6f9 to 003de727 has its CatchHandler @ 002dabf0 */
          uVar41 = *(undefined8 *)(crsf::utils::kVideoReceiverBandNames + (ulong)bVar55 * 8);
          (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                    (plVar64,&LAB_007aae4c_2,5);
          local_1d8 = (undefined1 **)CONCAT71(local_1d8._1_7_,cVar31);
          if (*(long *)((long)plVar64 + *(long *)(*plVar64 + -0x18) + 0x10) == 0) {
                    /* try { // try from 002de73f to 003de76d has its CatchHandler @ 002dabf0 */
            (*(code *)PTR_put_008ca520)(plVar64,(int)cVar31);
            plVar50 = plVar64;
          }
          else {
                    /* try { // try from 002de728 to 003de73e has its CatchHandler @ 002dea3b */
            plVar50 = (long *)(*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                                        (plVar64,&local_1d8,1);
          }
          uVar45 = (*(code *)PTR_operator<<_008cae78)(plVar50,uVar62);
                    /* try { // try from 002de76e to 003de784 has its CatchHandler @ 002dea36 */
          (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                    (uVar45,&LAB_007aae53_1,6);
          uVar51 = (*(code *)PTR_strlen_008ca708)(uVar41);
          (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)(uVar45,uVar41,uVar51)
          ;
                    /* try { // try from 002de79c to 003de7a8 has its CatchHandler @ 002dea14 */
          (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                    (uVar45,&LAB_007aae5b,9);
          uVar41 = (*(code *)PTR__M_insert<unsigned_long>_008ca870)(uVar45,sVar2);
                    /* try { // try from 002de7c0 to 003de7cc has its CatchHandler @ 002dea0a */
          (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                    (uVar41,&LAB_007aae64_1,7);
          (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                    (uVar41,&LAB_007ab014_4,8);
        }
      }
                    /* try { // try from 002de7e4 to 003de7f0 has its CatchHandler @ 002dea2e */
      pcVar59 = (code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00;
      uVar36 = (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                         (plVar64,&LAB_007be511,1);
                    /* try { // try from 002de808 to 003de814 has its CatchHandler @ 002de9f4 */
      if (((bVar7) && (uVar36 = (uint)(byte)local_c30, local_c30 == local_aa8._0_1_)) &&
         (uVar36 = uVar28, (byte)local_c38 == local_aa8._1_1_)) {
LAB_002dead9:
                    /* catch() { ... } // from try @ 002daeef with catch @ 002deada */
        bVar7 = true;
                    /* catch() { ... } // from try @ 002ddd9f with catch @ 002deae2 */
                    /* catch() { ... } // from try @ 002de5cc with catch @ 002deae6 */
        (*pcVar59)(plVar64,&DAT_007b3485,0x36);
      }
      else {
        if ((bVar15) && (cStack_a60 != '\0')) {
                    /* try { // try from 002de850 to 003de85c has its CatchHandler @ 002de9ab */
          auVar71[0] = -(local_aa8._0_1_ == local_a68);
          cVar31 = -(local_aa8._7_1_ == cStack_a61);
          auVar71._8_8_ =
               (undefined8)
               (CONCAT72(CONCAT61(CONCAT51(CONCAT41(CONCAT31(CONCAT21(CONCAT11(cVar31,cVar31),
                                                                      -(local_aa8._6_1_ ==
                                                                       cStack_a62)),
                                                             -(local_aa8._6_1_ == cStack_a62)),
                                                    -(local_aa8._5_1_ == cStack_a63)),
                                           -(local_aa8._5_1_ == cStack_a63)),
                                  -(local_aa8._4_1_ == cStack_a64)),
                         CONCAT11(-(local_aa8._4_1_ == cStack_a64),cVar31)) >> 8);
          auVar71[7] = -(local_aa8._3_1_ == cStack_a65);
          auVar71[6] = -(local_aa8._3_1_ == cStack_a65);
          auVar71[5] = -(local_aa8._2_1_ == cStack_a66);
          auVar71[4] = -(local_aa8._2_1_ == cStack_a66);
          auVar71[3] = -(local_aa8._1_1_ == bStack_a67);
          auVar71[2] = -(local_aa8._1_1_ == bStack_a67);
          auVar71[1] = auVar71[0];
          auVar75 = pshuflw(auVar71,auVar71,0x50);
          auVar72._0_4_ = auVar75._0_4_;
          auVar72._4_4_ = auVar72._0_4_;
          auVar72._8_4_ = auVar75._4_4_;
          auVar72._12_4_ = auVar75._4_4_;
          iVar35 = movmskpd(uVar36,auVar72);
                    /* try { // try from 002de874 to 003de880 has its CatchHandler @ 002de9a1 */
          if (iVar35 == 3) {
            (*pcVar59)(plVar64,&LAB_007b34bc,0x37);
            while( true ) {
                    /* try { // try from 002de898 to 003de8a4 has its CatchHandler @ 002de992 */
              cVar31 = Topic<droneforge::core::runtime::VrxChannelRequestMessage,32ul>::Subscription
                       ::TryRead((Subscription *)&local_250,(VrxChannelRequestMessage *)local_ab8);
              if (cVar31 == '\0') {
                bVar15 = true;
                goto LAB_002deb07;
              }
                    /* try { // try from 002de8bc to 003de8c8 has its CatchHandler @ 002de98d */
              (*pcVar59)(plVar64,"vrx connect request received bandCode=",0x26);
              uVar41 = (*(code *)PTR_operator<<_008cae78)(plVar64,local_aa8 & 0xff);
                    /* try { // try from 002de8e0 to 003de8ec has its CatchHandler @ 002de979 */
              (*pcVar59)(uVar41,&LAB_007aae40_4,9);
                    /* try { // try from 002de8ed to 003de91b has its CatchHandler @ 002dabf0 */
              (*(code *)PTR_operator<<_008cae78)(uVar41,local_aa8._1_1_);
              uVar62 = (ulong)local_aa8._1_1_;
                    /* try { // try from 002de91c to 003de932 has its CatchHandler @ 002de96b */
              if (((byte)(local_aa8._1_1_ - 1) < 8 &&
                   (byte)((char)local_aa8._0_1_ << 5 | (byte)local_aa8._0_1_ >> 3) < 6) &&
                 ((byte)local_aa8._0_1_ < 0x30)) {
                bVar55 = (byte)local_aa8._0_1_ >> 3;
                sVar2 = *(short *)((ulong)bVar55 * 0x10 + 0x7f007a + uVar62 * 2);
                    /* try { // try from 002de94a to 003de956 has its CatchHandler @ 002de95c */
                if (sVar2 != 0) {
                  cVar31 = "ABEFRL"[bVar55];
                    /* try { // try from 002de957 to 003debd9 has its CatchHandler @ 002dabf0 */
                  uVar41 = *(undefined8 *)(crsf::utils::kVideoReceiverBandNames + (ulong)bVar55 * 8)
                  ;
                    /* catch() { ... } // from try @ 002db1ad with catch @ 002de963 */
                    /* catch() { ... } // from try @ 002de91c with catch @ 002de96b */
                    /* catch() { ... } // from try @ 002dd660 with catch @ 002de972 */
                  (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                            (plVar64,&LAB_007aae4c_2,5);
                    /* catch() { ... } // from try @ 002de8e0 with catch @ 002de979 */
                  local_1d8 = (undefined1 **)CONCAT71(local_1d8._1_7_,cVar31);
                  if (*(long *)((long)plVar64 + *(long *)(*plVar64 + -0x18) + 0x10) == 0) {
                    /* catch() { ... } // from try @ 002dc82e with catch @ 002de9a6 */
                    /* catch() { ... } // from try @ 002dbf43 with catch @ 002de9b0
                       catch() { ... } // from try @ 002de850 with catch @ 002de9ab */
                    (*(code *)PTR_put_008ca520)(plVar64,(int)cVar31);
                    plVar50 = plVar64;
                  }
                  else {
                    /* catch() { ... } // from try @ 002de8bc with catch @ 002de98d */
                    /* catch() { ... } // from try @ 002de898 with catch @ 002de992 */
                    /* catch() { ... } // from try @ 002dcd24 with catch @ 002de997 */
                    /* catch() { ... } // from try @ 002de874 with catch @ 002de9a1 */
                    plVar50 = (long *)(*(code *)
                                        PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                                                (plVar64,&local_1d8,1);
                  }
                    /* catch() { ... } // from try @ 002dd6af with catch @ 002de9b5 */
                  uVar45 = (*(code *)PTR_operator<<_008cae78)(plVar50,uVar62);
                  (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                            (uVar45,&LAB_007aae53_1,6);
                  uVar51 = (*(code *)PTR_strlen_008ca708)(uVar41);
                    /* catch() { ... } // from try @ 002dc1dc with catch @ 002de9e2 */
                    /* catch() { ... } // from try @ 002de82c with catch @ 002de9e7 */
                    /* catch() { ... } // from try @ 002dba12 with catch @ 002de9ec */
                  (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                            (uVar45,uVar41,uVar51);
                    /* catch() { ... } // from try @ 002de808 with catch @ 002de9f4 */
                    /* catch() { ... } // from try @ 002dd61f with catch @ 002de9fe */
                    /* catch() { ... } // from try @ 002dd5fc with catch @ 002dea00 */
                  (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                            (uVar45,&LAB_007aae5b,9);
                    /* catch() { ... } // from try @ 002de7c0 with catch @ 002dea0a */
                    /* catch() { ... } // from try @ 002dcb00 with catch @ 002dea0f */
                  uVar41 = (*(code *)PTR__M_insert<unsigned_long>_008ca870)(uVar45,sVar2);
                    /* catch() { ... } // from try @ 002de79c with catch @ 002dea14 */
                    /* catch() { ... } // from try @ 002ddf9e with catch @ 002dea19 */
                    /* catch() { ... } // from try @ 002dac9b with catch @ 002dea1e */
                  (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                            (uVar41,&LAB_007aae64_1,7);
                  (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                            (uVar41,&LAB_007ab014_4,8);
                }
              }
              pcVar59 = (code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00;
              uVar36 = (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                                 (plVar64,&LAB_007be511,1);
                    /* catch() { ... } // from try @ 002dd392 with catch @ 002dea7e */
              if (((bVar7) && (uVar36 = (uint)(byte)local_c30, local_c30 == local_aa8._0_1_)) &&
                 (uVar36 = uVar28, (byte)local_c38 == local_aa8._1_1_)) {
                    /* catch() { ... } // from try @ 002dc0e1 with catch @ 002dead2 */
                bVar15 = true;
                    /* catch() { ... } // from try @ 002dbe31 with catch @ 002dead8 */
                goto LAB_002dead9;
              }
                    /* catch() { ... } // from try @ 002de6ec with catch @ 002dea88 */
                    /* catch() { ... } // from try @ 002de6c8 with catch @ 002dea8d */
              if (cStack_a60 != '\x01') break;
              auVar73[0] = -(local_aa8._0_1_ == local_a68);
              cVar31 = -(local_aa8._7_1_ == cStack_a61);
              auVar73._8_8_ =
                   (undefined8)
                   (CONCAT72(CONCAT61(CONCAT51(CONCAT41(CONCAT31(CONCAT21(CONCAT11(cVar31,cVar31),
                                                                          -(local_aa8._6_1_ ==
                                                                           cStack_a62)),
                                                                 -(local_aa8._6_1_ == cStack_a62)),
                                                        -(local_aa8._5_1_ == cStack_a63)),
                                               -(local_aa8._5_1_ == cStack_a63)),
                                      -(local_aa8._4_1_ == cStack_a64)),
                             CONCAT11(-(local_aa8._4_1_ == cStack_a64),cVar31)) >> 8);
              auVar73[7] = -(local_aa8._3_1_ == cStack_a65);
              auVar73[6] = -(local_aa8._3_1_ == cStack_a65);
              auVar73[5] = -(local_aa8._2_1_ == cStack_a66);
              auVar73[4] = -(local_aa8._2_1_ == cStack_a66);
              auVar73[3] = -(local_aa8._1_1_ == bStack_a67);
              auVar73[2] = -(local_aa8._1_1_ == bStack_a67);
              auVar73[1] = auVar73[0];
              auVar75 = pshuflw(auVar73,auVar73,0x50);
              auVar74._0_4_ = auVar75._0_4_;
              auVar74._4_4_ = auVar74._0_4_;
              auVar74._8_4_ = auVar75._4_4_;
              auVar74._12_4_ = auVar75._4_4_;
              iVar35 = movmskpd(uVar36,auVar74);
              if (iVar35 != 3) break;
              (*pcVar59)(plVar64,&LAB_007b34bc,0x37);
            }
          }
        }
        local_c10 = local_b40;
                    /* try { // try from 002de5cc to 003de5d8 has its CatchHandler @ 002deae6 */
        local_ca8 = 8;
        if (local_c08 < local_b40) {
          local_ca8 = 1;
        }
        if (local_c08 == 0) {
          local_ca8 = 1;
        }
                    /* try { // try from 002de5f0 to 003de5fc has its CatchHandler @ 002dead0 */
        local_c38 = local_aa8 >> 8 & 0xff;
        bVar7 = true;
        local_c08 = 0;
                    /* try { // try from 002de614 to 003de620 has its CatchHandler @ 002deaa5 */
        bVar68 = false;
        bVar15 = false;
        local_ca4 = local_ca8;
        local_c30 = local_aa8._0_1_;
      }
    }
LAB_002deb07:
                    /* catch() { ... } // from try @ 002ddd4d with catch @ 002deb1b */
                    /* catch() { ... } // from try @ 002de240 with catch @ 002deb20 */
                    /* catch() { ... } // from try @ 002dad5a with catch @ 002deb27 */
                    /* catch() { ... } // from try @ 002de5af with catch @ 002deb39 */
    if (((local_ac9 == 1) && (local_aca != 0)) &&
       ((local_ae1 == 0 &&
        (((bVar7 && (0 < (int)local_ca4)) && (bVar7 = true, local_c10 <= local_b40)))))) {
      local_b68 = 0;
      lStack_b60 = 0;
      local_b58 = 0;
      cVar31 = crsf::CrsfTransmitEncoder::EncodeVideoReceiverConnectFrame
                         (*(CrsfTransmitEncoder **)(this + 0x58),(uchar)local_c30,(byte)local_c38,
                          (vector *)&local_b68);
      bVar7 = false;
      if (cVar31 == '\0') {
        bVar68 = false;
        local_cb4 = 0;
        local_ca4 = 0;
      }
      else {
        cVar31 = io::SerialLinkWriter::Transmit
                           (*(undefined8 *)(this + 0x50),local_b68,lStack_b60 - local_b68);
        iVar35 = (local_ca8 - local_ca4) + 1;
        if (cVar31 == '\0') {
          (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                    (plVar64,"vrx connect failed attempt=",0x1b);
          uVar41 = (*(code *)PTR_operator<<_008cae78)(plVar64,iVar35);
          (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                    (uVar41,&LAB_007b36c0_2,7);
                    /* try { // try from 002def5d to 003def6e has its CatchHandler @ 002df326 */
          io::SerialLinkWriter::LastError_abi_cxx11_();
          puVar43 = PTR___ostream_insert<char,std_char_traits<char>>_008cab00;
          uVar41 = (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                             (uVar41,local_1d8,puStack_1d0);
                    /* try { // try from 002def8f to 003defaf has its CatchHandler @ 002df32b */
          (*(code *)puVar43)(uVar41,&LAB_007be511,1);
          if (local_1d8 != local_1c8) {
            (*(code *)puVar23)(local_1d8,local_1c8[0] + 1);
          }
        }
        else {
          (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                    (plVar64,&DAT_007b3510,0x21);
          uVar41 = (*(code *)PTR_operator<<_008cae78)(plVar64,local_c30);
          (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                    (uVar41,&LAB_007aae40_4,9);
          (*(code *)PTR_operator<<_008cae78)(uVar41,(byte)local_c38);
          if (1 < local_ca8) {
            (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                      (plVar64," attempt=",9);
            uVar41 = (*(code *)PTR_operator<<_008cae78)(plVar64,iVar35);
            (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                      (uVar41,&DAT_007bffd3,1);
            (*(code *)PTR_operator<<_008cae78)(uVar41,local_ca8);
          }
          puVar43 = PTR___ostream_insert<char,std_char_traits<char>>_008cab00;
          if ((((byte)((char)local_c30 << 5 | (byte)local_c30 >> 3) < 6) &&
              ((byte)((byte)local_c38 - 1) < 8)) && ((byte)local_c30 < 0x30)) {
            bVar55 = (byte)local_c30 >> 3;
            sVar2 = *(short *)((ulong)bVar55 * 0x10 + 0x7f007a + local_c38 * 2);
            if (sVar2 != 0) {
              cVar31 = "ABEFRL"[bVar55];
              uVar41 = *(undefined8 *)(crsf::utils::kVideoReceiverBandNames + (ulong)bVar55 * 8);
              (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                        (plVar64,&LAB_007aae4c_2,5);
              local_1d8 = (undefined1 **)CONCAT71(local_1d8._1_7_,cVar31);
              if (*(long *)((long)plVar64 + *(long *)(*plVar64 + -0x18) + 0x10) == 0) {
                (*(code *)PTR_put_008ca520)(plVar64,(int)cVar31);
                plVar50 = plVar64;
              }
              else {
                plVar50 = (long *)(*(code *)puVar43)(plVar64,&local_1d8,1);
              }
              uVar45 = (*(code *)PTR_operator<<_008cae78)(plVar50,(byte)local_c38);
              (*(code *)puVar43)(uVar45,&LAB_007aae53_1,6);
              uVar51 = (*(code *)PTR_strlen_008ca708)(uVar41);
              (*(code *)puVar43)(uVar45,uVar41,uVar51);
              (*(code *)puVar43)(uVar45,&LAB_007aae5b,9);
              uVar41 = (*(code *)PTR__M_insert<unsigned_long>_008ca870)(uVar45,sVar2);
              (*(code *)puVar43)(uVar41,&LAB_007aae64_1,7);
              (*(code *)puVar43)(uVar41,&LAB_007ab014_4,8);
            }
          }
          bVar68 = true;
          (*(code *)puVar43)(plVar64,&LAB_007be511,1);
        }
        pcVar59 = (code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00;
        local_c10 = local_b40 + 100000000;
        bVar7 = true;
        local_ca4 = local_ca4 - 1;
        local_cb4 = local_ca8;
        if (local_ca4 == 0) {
          if (1 < local_ca8) {
            (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
                      (plVar64,&LAB_007b3530_2,0x2a);
            pcVar65 = "false";
            if (bVar68) {
              pcVar65 = "true";
            }
            (*pcVar59)(plVar64,pcVar65,bVar68 ^ 5);
            (*pcVar59)(plVar64,&LAB_007be511,1);
          }
          if (bVar68 == false) {
            local_c80 = local_b40 + 1500000000;
          }
          bVar7 = false;
          bVar15 = bVar68 != false;
          bVar68 = false;
          local_ca4 = 0;
          local_cb4 = 0;
        }
      }
      if (local_b68 != 0) {
        (*(code *)puVar23)(local_b68,local_b58 - local_b68);
      }
    }
    else {
      local_cb4 = local_ca8;
    }
    if (((bVar34 & ((byte)local_ae2 ^ 1)) == 1) && (local_b48 < 0x1f5)) {
      Run(std::atomic<bool>&)::$_1::operator()((__1 *)local_1b8);
    }
    bVar34 = local_aca;
    bVar55 = local_ae1;
    bVar57 = local_ac9;
    if ((((local_ac9 == 1) && (local_aca != 0)) && (local_ae1 == 0)) &&
       ((local_53c != 0 && (local_b23 != '\0')))) {
                    /* catch() { ... } // from try @ 002df326 with catch @ 002dedf0 */
      bVar34 = 1;
      bVar55 = 0;
      if (local_b40 < local_b38) {
        bVar57 = 1;
      }
      else {
        bVar57 = 1;
        if (local_ae0 <= local_b40) {
          local_b68 = 0;
          lStack_b60 = 0;
          local_b58 = 0;
          cVar31 = crsf::CrsfTransmitEncoder::EncodeMspVtxConfigRequestFrame
                             (*(CrsfTransmitEncoder **)(this + 0x58),(vector *)&local_b68);
          if (cVar31 != '\0') {
            cVar31 = io::SerialLinkWriter::Transmit
                               (*(undefined8 *)(this + 0x50),local_b68,lStack_b60 - local_b68);
            if (cVar31 == '\0') {
              (*pcVar59)(plVar64,&LAB_007b3595_1,0x21);
              io::SerialLinkWriter::LastError_abi_cxx11_();
              uVar41 = (*pcVar59)(plVar64,local_1d8,puStack_1d0);
              (*pcVar59)(uVar41,&LAB_007be511,1);
              if (local_1d8 != local_1c8) {
                (*(code *)puVar23)(local_1d8,local_1c8[0] + 1);
              }
              plVar50 = &local_b38;
            }
            else {
              (*pcVar59)(plVar64,&LAB_007b355a_3,0x38);
              uVar41 = (*(code *)PTR_operator<<_008cae78)(plVar64,local_b24);
              (*pcVar59)(uVar41,&LAB_007b3615_5,5);
              uVar45 = (*(code *)PTR_now_008cabf0)();
              uVar41 = (*(code *)PTR__M_insert<unsigned_long>_008ca870)(uVar41,uVar45);
              (*pcVar59)(uVar41,&LAB_007be511,1);
              local_b23 = '\0';
              plVar50 = &local_ae0;
            }
            *plVar50 = local_b40 + 1000000000;
          }
          bVar34 = local_aca;
          bVar55 = local_ae1;
          bVar57 = local_ac9;
          if (local_b68 != 0) {
            (*(code *)puVar23)(local_b68,local_b58 - local_b68);
            bVar34 = local_aca;
            bVar55 = local_ae1;
            bVar57 = local_ac9;
          }
        }
      }
    }
    if (((~(bVar57 & bVar34) | bVar55) & 1) == 0) {
      if (((local_53c != 1) || (bVar18)) || ((local_b40 < local_c50 || (local_b40 < local_ae0)))) {
        bVar34 = 1;
        bVar55 = 0;
      }
      else {
                    /* try { // try from 002df0f8 to 003df0fd has its CatchHandler @ 002df339 */
        local_b68 = 0;
        lStack_b60 = 0;
                    /* try { // try from 002df0fe to 003df1dd has its CatchHandler @ 002dedf0 */
        local_b58 = 0;
        cVar31 = crsf::CrsfTransmitEncoder::EncodeMspBoardInfoRequestFrame
                           (*(CrsfTransmitEncoder **)(this + 0x58),(vector *)&local_b68);
        if (cVar31 != '\0') {
          cVar31 = io::SerialLinkWriter::Transmit
                             (*(undefined8 *)(this + 0x50),local_b68,lStack_b60 - local_b68);
          if (cVar31 == '\0') {
            (*pcVar59)(plVar64,&LAB_007b35de_2,0x1b);
            io::SerialLinkWriter::LastError_abi_cxx11_();
            uVar41 = (*pcVar59)(plVar64,local_1d8,puStack_1d0);
            (*pcVar59)(uVar41,&LAB_007be511,1);
            if (local_1d8 != local_1c8) {
              (*(code *)puVar23)(local_1d8,local_1c8[0] + 1);
            }
          }
          else {
            (*pcVar59)(plVar64,&LAB_007b35b1_7,0x27);
            uVar41 = (*(code *)PTR_operator<<_008cae78)(plVar64,iVar61 + 1);
            (*pcVar59)(uVar41,&LAB_007b3615_5,5);
            uVar45 = (*(code *)PTR_now_008cabf0)();
            uVar41 = (*(code *)PTR__M_insert<unsigned_long>_008ca870)(uVar41,uVar45);
            (*pcVar59)(uVar41,&LAB_007be511,1);
            local_ae0 = local_b40 + 2500000000;
            lVar49 = local_ae0;
            if (local_ae0 < local_c80) {
              lVar49 = local_c80;
            }
            if (!bVar19) {
              local_c80 = lVar49;
            }
                    /* try { // try from 002df1de to 003df1e3 has its CatchHandler @ 002df339 */
            bVar19 = true;
                    /* try { // try from 002df1e4 to 003df2f9 has its CatchHandler @ 002dedf0 */
          }
        }
        local_c50 = 5000000000;
        if (bVar19) {
          local_c50 = 2500000000;
        }
        local_c50 = local_c50 + local_b40;
        if (local_b68 != 0) {
          (*(code *)puVar23)(local_b68,local_b58 - local_b68);
        }
        iVar61 = iVar61 + 1;
        bVar34 = local_aca;
        bVar55 = local_ae1;
        if (local_ac9 == 0) goto LAB_002df4b5;
      }
LAB_002df2f0:
                    /* try { // try from 002df2fa to 003df313 has its CatchHandler @ 002df33b */
                    /* try { // try from 002df316 to 003df325 has its CatchHandler @ 002df32b */
                    /* try { // try from 002df326 to 003df389 has its CatchHandler @ 002dedf0 */
                    /* catch() { ... } // from try @ 002df316 with catch @ 002df32b */
                    /* catch() { ... } // from try @ 002df1de with catch @ 002df339 */
                    /* catch() { ... } // from try @ 002df2fa with catch @ 002df33b */
      if (((((bVar34 != 0) && (bVar55 == 0)) && (local_53c == 1)) && ((bVar19 && (!bVar15)))) &&
         ((!bVar7 && ((local_c80 <= local_b40 && (local_ae0 <= local_b40)))))) {
        local_b68 = 0;
        lStack_b60 = 0;
        local_b58 = 0;
        cVar31 = crsf::CrsfTransmitEncoder::EncodeMspVtxConfigRequestFrame
                           (*(CrsfTransmitEncoder **)(this + 0x58),(vector *)&local_b68);
        puVar43 = PTR___ostream_insert<char,std_char_traits<char>>_008cab00;
        if (cVar31 != '\0') {
          cVar31 = io::SerialLinkWriter::Transmit
                             (*(undefined8 *)(this + 0x50),local_b68,lStack_b60 - local_b68);
          if (cVar31 == '\0') {
            (*(code *)puVar43)(plVar64,&LAB_007b361f_1,0x1b);
            io::SerialLinkWriter::LastError_abi_cxx11_();
            uVar41 = (*(code *)puVar43)(plVar64,local_1d8,puStack_1d0);
            (*(code *)puVar43)(uVar41,&LAB_007be511,1);
            if (local_1d8 != local_1c8) {
              (*(code *)puVar23)(local_1d8,local_1c8[0] + 1);
            }
          }
          else {
            (*(code *)puVar43)(plVar64,&LAB_007b35f5_7,0x23);
            uVar41 = (*(code *)PTR_now_008cabf0)();
            uVar41 = (*(code *)PTR__M_insert<unsigned_long>_008ca870)(plVar64,uVar41);
            (*(code *)puVar43)(uVar41,&LAB_007be511,1);
            local_ae0 = local_b40 + 1000000000;
          }
        }
        local_c80 = local_b40 + 1500000000;
        if (local_b68 != 0) {
          (*(code *)puVar23)(local_b68,local_b58 - local_b68);
        }
      }
    }
    else if (bVar57 != 0) goto LAB_002df2f0;
LAB_002df4b5:
    lVar49 = local_b40;
    uVar41 = *(undefined8 *)(this + 0x50);
    if ((bVar20) && (local_be8 <= local_b40)) {
      local_1d8 = (undefined1 **)0x0;
      puStack_1d0 = (undefined1 *)0x0;
      local_1c8[0] = (undefined1 *)0x0;
      cVar31 = crsf::CrsfTransmitEncoder::EncodeDevicePingFrame
                         (*(CrsfTransmitEncoder **)(this + 0x58),0xee,&local_1d8,0xea);
      if (cVar31 != '\0') {
        io::SerialLinkWriter::Transmit(uVar41,local_1d8,(long)puStack_1d0 - (long)local_1d8);
        local_be8 = lVar49 + 250000000;
      }
      if (local_1d8 != (undefined1 **)0x0) {
        (*(code *)puVar23)(local_1d8,(long)local_1c8[0] - (long)local_1d8);
      }
      uVar41 = *(undefined8 *)(this + 0x50);
    }
    lVar49 = local_b40;
    if ((lVar60 <= local_b40 & bVar54) == 1) {
      local_1d8 = (undefined1 **)0x0;
      puStack_1d0 = (undefined1 *)0x0;
      local_1c8[0] = (undefined1 *)0x0;
      cVar31 = crsf::CrsfTransmitEncoder::EncodeDevicePingFrame
                         (*(CrsfTransmitEncoder **)(this + 0x58),0xec,&local_1d8,0xea);
      if (cVar31 != '\0') {
        io::SerialLinkWriter::Transmit(uVar41,local_1d8,(long)puStack_1d0 - (long)local_1d8);
        lVar60 = lVar49 + 250000000;
      }
      if (local_1d8 != (undefined1 **)0x0) {
        (*(code *)puVar23)(local_1d8,(long)local_1c8[0] - (long)local_1d8);
      }
      uVar41 = *(undefined8 *)(this + 0x50);
    }
    lVar49 = local_b40;
    local_c00 = lVar63;
    if ((lVar63 <= local_b40 & bVar32) == 1) {
      local_1d8 = (undefined1 **)0x0;
      puStack_1d0 = (undefined1 *)0x0;
      local_1c8[0] = (undefined1 *)0x0;
      cVar31 = crsf::CrsfTransmitEncoder::EncodeDevicePingFrame
                         (*(CrsfTransmitEncoder **)(this + 0x58),200,&local_1d8,0xea);
      if (cVar31 != '\0') {
        io::SerialLinkWriter::Transmit(uVar41,local_1d8,(long)puStack_1d0 - (long)local_1d8);
        lVar63 = lVar49 + 250000000;
      }
      local_c00 = lVar63;
      if (local_1d8 != (undefined1 **)0x0) {
        (*(code *)puVar23)(local_1d8,(long)local_1c8[0] - (long)local_1d8);
      }
    }
    pcVar59 = (code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00;
    lVar63 = (*(code *)PTR_now_008cabf0)();
    if (lVar63 - local_b40 < 10000000) {
      uVar62 = 10000000 - (lVar63 - local_b40);
      local_1d8 = (undefined1 **)(uVar62 / 1000000000);
      puStack_1d0 = (undefined1 *)(uVar62 % 1000000000);
      do {
        iVar35 = (*(code *)PTR_nanosleep_008ca630)(&local_1d8,&local_1d8);
        if (iVar35 != -1) break;
        piVar52 = (int *)(*(code *)PTR___errno_location_008ca530)();
      } while (*piVar52 == 4);
    }
    if (local_a28._0_8_ != 0) {
      (*(code *)puVar23)(local_a28._0_8_,(long)local_a18[0] - local_a28._0_8_);
    }
    if (local_9f8 != &local_9e8) {
      (*(code *)puVar23)(local_9f8,CONCAT71(uStack_9e7,local_9e8) + 1);
    }
    cVar31 = local_870;
    local_870 = '\0';
    if ((cVar31 == '\x01') && (local_8a8 != local_898)) {
      (*(code *)puVar23)(local_8a8,local_898[0] + 1);
    }
    cVar31 = local_8f8;
    local_8f8 = '\0';
    if ((cVar31 == '\x01') && (local_920 != local_910)) {
      (*(code *)puVar23)(local_920,local_910[0] + 1);
    }
    DeviceInfoMessage::~DeviceInfoMessage(local_728);
    if (local_570 != &local_560) {
      (*(code *)puVar23)(local_570,CONCAT71(uStack_55f,local_560) + 1);
    }
    if (local_590 != &local_580) {
      (*(code *)puVar23)(local_590,CONCAT71(uStack_57f,local_580) + 1);
    }
    local_c40 = lVar60;
    bVar34 = bVar54;
    bVar55 = bVar32;
    if (*param_1 != (atomic)0x0) goto LAB_002daf32;
    goto LAB_002db4b8;
  }
  bVar17 = true;
  if (local_b40 < local_bc8) goto LAB_002de02f;
  (*(code *)PTR___ostream_insert<char,std_char_traits<char>>_008cab00)
            (PTR_cerr_008caf98,"nimbus command override complete command=",0x29);
  if (local_bd0 == (undefined1 *)0x0) {
    (*(code *)PTR_clear_008cae58)
              (PTR_cerr_008caf98 + *(long *)(*(long *)PTR_cerr_008caf98 + -0x18),
               *(uint *)(PTR_cerr_008caf98 + *(long *)(*(long *)PTR_cerr_008caf98 + -0x18) + 0x20) |
               1);
  }
  else {
    uVar41 = (*(code *)PTR_strlen_008ca708)(local_bd0);
    (*(code *)puVar43)(PTR_cerr_008caf98,local_bd0,uVar41);
  }
  plVar50 = *(long **)(PTR_cerr_008caf98 + *(long *)(*(long *)PTR_cerr_008caf98 + -0x18) + 0xf0);
  if (plVar50 != (long *)0x0) {
    if ((char)plVar50[7] == '\0') {
      (*(code *)PTR__M_widen_init_008cab08)(plVar50);
      cVar31 = (**(code **)(*plVar50 + 0x30))(plVar50,10);
    }
    else {
      cVar31 = *(char *)((long)plVar50 + 0x43);
    }
    uVar41 = (*(code *)PTR_put_008ca520)(PTR_cerr_008caf98,(int)cVar31);
    (*(code *)PTR_flush_008ca878)(uVar41);
    local_bd0 = (undefined1 *)0x0;
    bVar17 = false;
    if (bVar16) goto LAB_002de03a;
    goto LAB_002de1ea;
  }
LAB_002dfb3d:
  if (*(long *)(in_FS_OFFSET + 0x28) != local_38) goto LAB_002e0448;
  uVar53 = (*(code *)PTR___throw_bad_cast_008cab80)();
  cVar31 = local_198[0];
  auVar13[0xf] = 0;
  auVar13._0_15_ = stack0xfffffffffffffe69;
  _local_198 = auVar13 << 8;
  if ((cVar31 == '\x01') && ((undefined1 *)local_1b8._0_8_ != local_1a8)) {
    (*(code *)PTR_operator_delete_008caa50)(local_1b8._0_8_,_local_1a8 + 1);
  }
  if (local_9f8 != &local_9e8) {
    (*(code *)PTR_operator_delete_008caa50)(local_9f8,CONCAT71(uStack_9e7,local_9e8) + 1);
  }
  cVar31 = local_870;
  local_870 = '\0';
  if ((cVar31 == '\x01') && (local_8a8 != local_898)) {
    (*(code *)PTR_operator_delete_008caa50)(local_8a8,local_898[0] + 1);
  }
  cVar31 = local_8f8;
  local_8f8 = '\0';
  if ((cVar31 == '\x01') && (local_920 != local_910)) {
    (*(code *)PTR_operator_delete_008caa50)(local_920,local_910[0] + 1);
  }
  DeviceInfoMessage::~DeviceInfoMessage(local_728);
  if (local_570 == &local_560) {
    if (local_590 != &local_580) {
LAB_002e00b4:
      (*(code *)PTR_operator_delete_008caa50)(local_590,CONCAT71(uStack_57f,local_580) + 1);
      puVar42 = (undefined8 *)local_b10._0_8_;
joined_r0x002e0086:
      while (puVar42 != (undefined8 *)0x0) {
        puVar3 = (undefined8 *)*puVar42;
        if ((long *)puVar42[7] != puVar42 + 9) {
          (*(code *)puVar23)((long *)puVar42[7],puVar42[9] + 1);
        }
        if ((long *)puVar42[1] != puVar42 + 3) {
          (*(code *)puVar23)((long *)puVar42[1],puVar42[3] + 1);
        }
        (*(code *)puVar23)(puVar42,0x68);
        puVar42 = puVar3;
      }
      (*(code *)PTR_memset_008ca790)(local_b20,0,local_b18 << 3);
      local_b10 = (undefined1  [16])0x0;
      if (local_b20 != local_af8 + 8) {
        (*(code *)PTR_operator_delete_008caa50)(local_b20,local_b18 << 3);
      }
      DeviceInfoMessage::~DeviceInfoMessage(local_538);
      if (local_368 != 0) {
        (*(code *)PTR_zmq_close_008cacf8)();
        local_368 = 0;
      }
      if (local_360 != local_350) {
        (*(code *)PTR_operator_delete_008caa50)(local_360,local_350[0] + 1);
      }
      if (local_340 != 0) {
        (*(code *)PTR_zmq_close_008cacf8)();
        local_340 = 0;
      }
      if (local_338 != local_328) {
        (*(code *)PTR_operator_delete_008caa50)(local_338,local_328[0] + 1);
      }
      if (local_318 != 0) {
        (*(code *)PTR_zmq_close_008cacf8)();
        local_318 = 0;
      }
      if (local_310 != local_300) {
        (*(code *)PTR_operator_delete_008caa50)(local_310,local_300[0] + 1);
      }
      if (local_2f0 != 0) {
        (*(code *)PTR_zmq_close_008cacf8)();
        local_2f0 = 0;
      }
      if (local_2e8 != local_2d8) {
        (*(code *)PTR_operator_delete_008caa50)(local_2e8,local_2d8[0] + 1);
      }
      if (local_2c8 != 0) {
        (*(code *)PTR_zmq_close_008cacf8)();
        local_2c8 = 0;
      }
      if (local_2c0 != local_2b0) {
        (*(code *)PTR_operator_delete_008caa50)(local_2c0,local_2b0[0] + 1);
      }
      if (local_2a0 != 0) {
        (*(code *)PTR_zmq_close_008cacf8)();
        local_2a0 = 0;
      }
      if (local_298 != local_288) {
        (*(code *)PTR_operator_delete_008caa50)(local_298,local_288[0] + 1);
      }
      if (local_278 != 0) {
        (*(code *)PTR_zmq_close_008cacf8)();
        local_278 = 0;
      }
      if (local_270 != local_260) {
        (*(code *)PTR_operator_delete_008caa50)(local_270,local_260[0] + 1);
      }
      if (local_250 != 0) {
        (*(code *)PTR_zmq_close_008cacf8)();
        local_250 = 0;
      }
      if (local_248 != local_238) {
        (*(code *)PTR_operator_delete_008caa50)(local_248,local_238[0] + 1);
      }
      if (local_228 != 0) {
        (*(code *)PTR_zmq_close_008cacf8)();
        local_228 = 0;
      }
      if (local_220 != local_210) {
        (*(code *)PTR_operator_delete_008caa50)(local_220,local_210[0] + 1);
      }
      if (local_200 != 0) {
        (*(code *)PTR_zmq_close_008cacf8)();
        local_200 = 0;
      }
      if (local_1f8 != local_1e8) {
        (*(code *)PTR_operator_delete_008caa50)(local_1f8,local_1e8[0] + 1);
      }
      if (*(long *)(in_FS_OFFSET + 0x28) == local_38) {
                    /* WARNING: Subroutine does not return */
        _Unwind_Resume(uVar53);
      }
      goto LAB_002e0448;
    }
  }
  else {
    (*(code *)PTR_operator_delete_008caa50)(local_570,CONCAT71(uStack_55f,local_560) + 1);
    if (local_590 != &local_580) goto LAB_002e00b4;
  }
  puVar42 = (undefined8 *)local_b10._0_8_;
  goto joined_r0x002e0086;
}


