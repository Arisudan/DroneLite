"""Persistent flight settings (JSON), validated. The values that must come from MEASUREMENTS on the real drone live here:
hover throttle (from throttle_ramp_tool.py) and the hover height. Used by HoverAutonomy; edited in the GCS Hover panel or applied by the ramp tool."""
from __future__ import annotations

import json
import os
from dataclasses import InitVar, asdict, dataclass, fields
from typing import Optional

PATH = os.environ.get("DRONEFORGE_SETTINGS", os.path.expanduser("~/Music/DroneForge/config/flight_settings.json"))

LIMITS = {"hover_height": (0.20, 2.50), "ceiling_m": (0.3, 3.0), "thr_hover0": (0.15, 0.88), "thr_max": (0.25, 1.00), "batt_ref_v": (12.0, 17.0), "creep_per_s": (0.005, 0.05), "battery_scale": (0.5, 2.0)}

# Flight profile for THIS drone (4S, 3", 382 g): found by simulation against the measured plant and sensor behaviour (docs/status_logs/flight-profile_test-history-and-findings.md).
PROFILE = dict(kp_z=0.9923, kv_z=0.0538, ki_z=0.01, i_max=0.078, sensor_delay_s=0.1118, bias_ff=0.6135, vz_lim=0.4581, takeoff_rate=0.3646, takeoff_ramp_rate=0.03,
               takeoff_ramp_slow=0.0074, takeoff_slow_frac=0.953, takeoff_lift_margin=0.008, thrust_exp=2.0, range_untrusted=(0.07, 0.47), range_untrusted_r_scale=966.6,
               lift_blend_s=2.27, terrain_gate=True)
SENSOR_GROUND_M = 0.07                         # what the range sensor reads with the drone sitting on the floor (real flight log: 0.07-0.08 m)
SENSOR_LOW_BIAS_M = 0.09                       # the MTF-02P reads ~9 cm too HIGH between about 20 and 35 cm (measured); accurate from 50 cm: hold at >= 0.5 m


@dataclass
class FlightSettings:
    hover_height: float = 0.5        # m (first tethered flight: 0.3)
    thr_hover0: float = 0.42         # stick 0..1 at full battery: UNMEASURED default until the ramp tool has run
    thr_max: float = 0.70            # hard cap on the throttle the hover controller may command
    measured: bool = False           # True once thr_hover0 came from a real ramp
    batt_ref_v: float = 15.2         # pack voltage at which thr_hover0 was measured (the controller scales the throttle with the voltage relative to this)
    creep_per_s: float = 0.0074      # throttle per second while the drone is creeping up to lift-off (stick fraction/s); lift-off takes (lift - 0.95*hover)/creep seconds
    xy_source: str = "fc"            # horizontal estimate: "fc" = the FC EKF when it agrees with the flow (else the PC flow filter), "pc" = always the PC flow filter
    flight_controller: str = "pc"    # "pc" = the PC does take-off + hold (default); "fc" = EXPERIMENTAL: the FC does take-off + hold (firmware candidate_fc_flight)
    battery_scale: float = 1.0       # display-only correction: shown pack voltage = FC reading x this (the controllers keep the raw reading)
    ceiling_m: float = 3.0           # tether length / hard height limit: the safety layer lands above it and no height above it can be set
    fc_hold: InitVar[Optional[bool]] = None   # LEGACY keyword only (old JSON / old callers): True -> flight_controller "fc". Not stored; read flight_controller.

    def __post_init__(self, fc_hold=None) -> None:
        if fc_hold is not None and self.flight_controller == "pc" and fc_hold:
            self.flight_controller = "fc"

    def validate(self) -> list[str]:
        bad = [f"{k}={getattr(self, k)} outside {lo}..{hi}" for k, (lo, hi) in LIMITS.items() if not lo <= getattr(self, k) <= hi]
        if self.xy_source not in ("fc", "pc"):
            bad.append(f"xy_source {self.xy_source!r} must be 'fc' or 'pc'")
        if self.flight_controller not in ("pc", "fc"):
            bad.append(f"flight_controller {self.flight_controller!r} must be 'pc' or 'fc'")
        if self.hover_height > self.ceiling_m:
            bad.append(f"hover_height {self.hover_height} m is above the ceiling {self.ceiling_m} m")
        if self.thr_max < self.thr_hover0 * 1.15:
            bad.append(f"thr_max {self.thr_max} must be at least 1.15 x thr_hover0 ({self.thr_hover0 * 1.15:.2f}) or the controller cannot climb")
        return bad


def load(path: str = PATH) -> FlightSettings:
    try:
        d = json.load(open(path))
        kw = {k: d[k] for k in asdict(FlightSettings()) if k in d}
        if "flight_controller" not in d and "fc_hold" in d:      # migrate the old boolean
            kw["flight_controller"] = "fc" if d["fc_hold"] else "pc"
        s = FlightSettings(**kw)
        return s if not s.validate() else FlightSettings()
    except (OSError, ValueError, TypeError):
        return FlightSettings()


def save(s: FlightSettings, path: str = PATH) -> None:
    bad = s.validate()
    if bad:
        raise ValueError("; ".join(bad))
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    json.dump(asdict(s), open(tmp, "w"), indent=1)
    os.replace(tmp, path)


def apply_to_config(s: FlightSettings, cfg) -> None:
    cfg.hover_height, cfg.thr_hover0, cfg.thr_max, cfg.batt_v0 = s.hover_height, s.thr_hover0, s.thr_max, s.batt_ref_v
    for k, v in PROFILE.items():
        setattr(cfg, k, v)
    cfg.takeoff_ramp_slow = s.creep_per_s
    cfg.xy_source = s.xy_source
    cfg.sign_height = min(s.hover_height, 0.5)              # sign check at the hold height: the range sensor is accurate there, and not in the 20-35 cm zone
    cfg.ceiling = max(cfg.ceiling, s.hover_height + 0.3)


def plant_params(s: FlightSettings):
    """Simulator plant that matches this drone's measured numbers (hover throttle, quadratic thrust, pack voltage, sensor over-read)."""
    from nimbus_pc.hover.sim import SimParams
    return SimParams(hover_thr=s.thr_hover0, thrust_exp=2.0, batt_v0=s.batt_ref_v, batt_sag_per_s=0.005, range_low_bias_m=SENSOR_LOW_BIAS_M, ground_range_m=SENSOR_GROUND_M)


# Field dict keys: key, label, unit, kind ('number'|'choice'), min, max, step, choices [(value, text)], tooltip, experimental (whole field),
# experimental_values (choice values to label EXPERIMENTAL), readonly (+ value). Number fields: min/max/step; choice fields: choices.
# --- declarative schema: the GUI builds its settings forms from this (no widget knowledge here) ---------------------------------
def _num(key, label, unit, lo, hi, step, tip, **kw):
    return dict(key=key, label=label, unit=unit, kind="number", min=lo, max=hi, step=step, choices=None, tooltip=tip, experimental=False, experimental_values=[], readonly=False, **kw)


def _choice(key, label, choices, tip, experimental_values=()):
    """choices: list of (value, text); a choice whose value is in `experimental_values` is shown with an 'experimental' label."""
    return dict(key=key, label=label, unit="", kind="choice", min=None, max=None, step=None, choices=choices, tooltip=tip, experimental=False, experimental_values=list(experimental_values), readonly=False)


def _ro(key, label, unit, value, tip):
    return dict(key=key, label=label, unit=unit, kind="number", min=value, max=value, step=None, choices=None, tooltip=tip, experimental=False, experimental_values=[], readonly=True, value=value)


SCHEMA = [
    {"group": "Flight", "fields": [
        _num("hover_height", "Hover height", "m", *LIMITS["hover_height"], 0.05, "Height held after take-off (range-sensor height). Must not exceed the ceiling."),
        _choice("flight_controller", "Take-off and hold by", [("pc", "PC (default)"), ("fc", "Flight controller (experimental)")],
                "PC: the PC does the take-off and the height hold. FC: the flight controller does both (EXPERIMENTAL, needs the candidate_fc_flight firmware).", experimental_values=("fc",)),
    ]},
    {"group": "Safety", "fields": [
        _num("ceiling_m", "Ceiling (tether length)", "m", *LIMITS["ceiling_m"], 0.1, "Hard height limit: the drone lands above it and no higher hover height can be set. Set it to the tether length."),
        _ro("tilt_sustained_deg", "Disarm tilt (sustained)", "deg", 45.0, "Fixed by the safety layer: disarm if tilted this far for 0.5 s."),
        _ro("tilt_extreme_deg", "Disarm tilt (instant)", "deg", 70.0, "Fixed by the safety layer: instant disarm."),
    ]},
    {"group": "Controller", "fields": [
        _num("thr_hover0", "Hover throttle", "", *LIMITS["thr_hover0"], 0.005, "Stick fraction (0..1) that hovers at the reference voltage. Measured by the throttle ramp."),
        _choice("measured", "Hover throttle status", [(False, "Not measured (take-off is refused)"), (True, "Measured (take-off allowed)")],
                "Take-off on the real drone is refused until this says Measured. Set it only after the hover throttle and the reference voltage came from a real lift-off (a ramp or a log): hover throttle and reference voltage are the values at which the drone lifted off."),
        _num("thr_max", "Throttle cap", "", *LIMITS["thr_max"], 0.01, "Hard cap on the throttle the controller may command (at least 1.15 x hover throttle)."),
        _num("creep_per_s", "Take-off creep", "/s", *LIMITS["creep_per_s"], 0.001, "Throttle added per second while creeping up to lift-off. Smaller = gentler but slower: the PC take-off stops after 16 s without lift-off, so values below 0.005 are not allowed."),
    ]},
    {"group": "Battery", "fields": [
        _num("batt_ref_v", "Reference voltage", "V", *LIMITS["batt_ref_v"], 0.1, "Pack voltage at which the hover throttle was measured; the controller scales the throttle with voltage relative to this (hover scaling)."),
        _num("battery_scale", "Voltage correction factor", "x", *LIMITS["battery_scale"], 0.01, "Multiplies the FC's pack-voltage reading for DISPLAY only (voltage and percentage); the flight controllers keep the raw reading. Use the Calibrate button below with a fully charged pack."),
    ]},
    {"group": "Estimation", "fields": [
        _choice("xy_source", "Horizontal position source", [("fc", "Flight controller EKF"), ("pc", "PC flow filter")],
                "FC: the FC EKF when it agrees with the optical flow (else the PC filter). PC: always the PC flow filter."),
    ]},
]
FIELD_KEYS = [f["key"] for g in SCHEMA for f in g["fields"] if not f["readonly"]]
