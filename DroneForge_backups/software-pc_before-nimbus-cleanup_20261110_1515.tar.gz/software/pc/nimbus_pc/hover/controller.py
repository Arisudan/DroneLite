"""Hover hold controller: altitude from the range sensor, horizontal position from optical-flow velocity, on top of Betaflight ANGLE mode.

Designed for the data we measured on the real link: range/flow ~10 Hz, attitude ~3.6 Hz, 80-150 ms old, with gaps. So every
measurement goes through a Kalman filter that predicts between samples from the commands we sent, and the control gains are low.
Body-rate damping (Nimbus has it) needs high-rate gyro data, which the 7 Hz link does not give: it is NOT faked here, the velocity damping (kv_xy) stays the only damping term.
Vertical references (take-off climb, height changes, landing descent) come from the jerk-limited S-curve generator in trajectory.py.
All numbers are first guesses to be tuned in the simulator and then on a tethered flight (UNVERIFIED on the real drone).
Output is a nimbus_pc Controls (roll/pitch -1..1 stick, throttle 0..1, arm), always clamped by the safety envelope below.
"""
from __future__ import annotations

import math
from collections import deque
from dataclasses import dataclass
from enum import Enum
from typing import Optional

from nimbus_pc.sender import Controls
from .trajectory import JerkLimited1D

G = 9.81


class HoverState(Enum):
    IDLE = "idle"
    TAKEOFF = "takeoff"
    SIGN_CHECK = "sign_check"
    HOVER = "hover"
    LAND = "land"
    SENSOR_LOSS = "sensor_loss"
    DONE = "done"


@dataclass
class HoverConfig:
    hover_height: float = 0.5
    takeoff_rate: float = 0.15
    land_rate: float = 0.10
    land_cut_height: float = 0.03
    land_slow_below: float = 0.15       # (unused since the Nimbus-style landing: constant land_rate down to land_ramp_height)
    land_min_rate: float = 0.05
    land_ramp_height: float = 0.10      # landing: below this height above the floor reading the throttle ramps to idle
    land_ramp_s: float = 1.0            # ... linearly over this long, then DONE (the caller disarms)
    land_contact_height: float = 0.02   # below this for land_contact_s while landing = on the floor: finish at once
    land_contact_s: float = 0.2
    land_sink_guard: float = 0.15       # during the ramp, if sinking faster than this (m/s) the altitude loop throttle is kept as a lower bound (soft touchdown)
    ref_v_max: float = 0.25             # jerk-limited vertical reference (Nimbus: 0.25 m/s, 0.35 m/s^2, 0.8 m/s^3)
    ref_a_max: float = 0.35
    ref_j_max: float = 0.8
    lift_grace_s: float = 1.5           # after lift-off the overshoot damper's height margin is widened by lift_grace_m for this long
    lift_grace_m: float = 0.15
    hover_learn_min_s: float = 3.0      # settled hover seconds before the measured hover throttle replaces the lift-off reference
    hover_learn_report_s: float = 5.0   # settled hover seconds before hover_learned() reports it
    ceiling: float = 1.2
    # throttle model (stick 0..1). thr_hover0 is the full-battery hover throttle: UNKNOWN on the real drone, calibrate first
    thr_hover0: float = 0.42
    thrust_exp: float = 1.0              # thrust ~ (throttle above idle)^exp. Real props/motors: about 2 (set from the flight settings); 1 = old linear model
    thr_idle: float = 0.05
    thr_min_air: float = 0.15
    thr_max: float = 0.70
    overshoot_m: float = 0.12            # above the height target by this much (or climbing faster than overshoot_vz) -> pull throttle below hover at once
    overshoot_vz: float = 0.45
    overshoot_cut: float = 0.08          # how far below the hover throttle the overshoot damper goes
    batt_v0: float = 16.2
    # altitude loop
    kp_z: float = 1.0
    kv_z: float = 0.10
    ki_z: float = 0.03
    bias_ff: float = 1.0                 # fraction of the learned acceleration bias fed back as throttle (a disturbance observer)
    min_rate_hz: float = 6.5             # preflight: range/flow samples per second needed to fly at all
    max_gap_s: float = 0.4               # preflight: longest allowed gap between range samples
    min_rate_inflight_hz: float = 5.0    # in flight: below this for 2 s -> land
    i_max: float = 0.10
    vz_lim: float = 0.35
    # horizontal loop (flow velocity)
    kp_pos: float = 0.50
    kv_xy: float = 1.5
    ki_xy: float = 0.15                  # position integral (m/s^2 per m*s), conditional anti-windup; contribution limited to xy_i_max_deg of tilt
    xy_i_max_deg: float = 3.0
    xy_i_range_m: float = 0.5            # integrate only while the position error is below this
    v_lim: float = 0.5
    tilt_max_deg: float = 8.0
    angle_limit_deg: float = 60.0        # Betaflight angle_limit: stick 1.0 = this many degrees (verify on the bench)
    pitch_sign: float = 1.0              # +1: positive pitch stick = accelerate forward. VERIFY with a bench tilt test before flying
    roll_sign: float = 1.0
    # plant model used for prediction
    tau_motor: float = 0.06
    tau_att: float = 0.08
    drag: float = 0.3
    sensor_delay_s: float = 0.12
    # safety envelope
    stale_s: float = 0.5
    sensor_loss_open_loop_s: float = 1.0
    sensor_loss_timeout_s: float = 3.5   # blind descent ends on this timer (the estimate cannot be trusted without sensors)
    sign_check: bool = True
    sign_height: float = 0.25            # the sign check runs this low, with horizontal control off, before climbing to hover_height
    sign_pulse_deg: float = 2.0
    sign_min_response_mps: float = 0.08
    sensor_loss_thr_drop: float = 0.02   # throttle below hover during open-loop descent
    tilt_abort_deg: float = 35.0
    runaway_m: float = 0.6
    runaway_speed: float = 0.7
    runaway_hold_s: float = 0.8          # beyond runaway_m / runaway_speed for this long (a single gust is fine)
    batt_autoland: bool = False          # False (default): a low battery only WARNS; True: the controller lands by itself below batt_land_v
    batt_land_v: float = 13.2
    batt_warn_v: float = 14.0
    flow_min_quality: int = 60
    xy_source: str = "fc"                # horizontal speed/position from: "fc" = the FC EKF (fused range+flow+gyro-aware attitude) when it agrees with the flow, else the PC flow filter; "pc" = always the PC flow filter
    fc_xy_max_age_s: float = 0.6         # FC estimate older than this is not used (the PC flow filter takes over)
    fc_xy_min_energy: float = 0.02       # flow energy (m/s)^2 needed before the FC/flow agreement is judged
    fc_xy_agree_ratio: float = 0.6       # the best frame candidate must have this fraction of the other's error (or less), and error below the flow energy
    range_untrusted: tuple = (0.0, 0.0)  # (low, high) metres: readings in between are down-weighted in the height estimate (0,0 = trust everything)
    range_untrusted_r_scale: float = 40.0   # measurement variance multiplier there (x40 = sigma 6x larger)
    climb_min_jerk: bool = True          # takeoff climb follows a minimum-jerk height trajectory with a velocity feed-forward (Nimbus plans smooth trajectories too)
    ground_max_m: float = 0.20           # preflight: the range sensor must read less than this on the ground (the real drone reads 0.04-0.08)
    takeoff_timeout_s: float = 16.0      # no real lift-off this long after the takeoff started -> stop (disarm). The real drone must not sit on the ground at high throttle
    lift_hover_tol: float = 0.12         # a lift-off throttle more than this fraction away from the expected hover throttle is not believed (false lift detection)
    soft_start_per_s: float = 0.6        # throttle may rise from zero at most this fast at the start of the takeoff (no step)
    terrain_gate: bool = False           # Nimbus-style: gate every range reading against the physics prediction; absorb sustained jumps into a terrain state
    terrain_q: float = 0.0004            # terrain random-walk variance (m^2/s)
    gate_sigma: float = 3.0
    gate_floor_m: float = 0.06           # innovation always allowed below this (sensor noise + model error)
    terrain_max_m: float = 0.40          # the terrain offset may never exceed this (a bigger 'floor change' is a sensor fault, not terrain)
    absorb_min_gap_s: float = 3.0        # at most one absorption per this many seconds
    gate_max_m: float = 0.12             # the gate never widens beyond this, however uncertain the (IMU-less) prediction becomes
    absorb_n: int = 3                    # this many consecutive rejected readings that agree with each other = the floor really changed
    absorb_spread_m: float = 0.06
    use_imu: bool = False                # use the FC's window-mean vertical acceleration instead of the throttle model for the height prediction
    imu_stale_s: float = 0.35
    range_cal: tuple = ()                # ((reading_m, true_m), ...) sorted by reading: corrects the range sensor (reads too high at 20-35 cm); empty = trust the reading
    takeoff_ramp_rate: float = 0.05     # throttle added per second on the ground until the drone lifts (learns the real hover throttle)
    takeoff_lift_margin: float = 0.030   # subtract from the ground-ramp throttle at lift-off (the estimator notices the lift ~0.3 s late)
    lift_blend_s: float = 0.0            # seconds to hand the throttle over from the creep value to the hover reference after lift-off (0 = step)
    use_lift_ref: bool = True            # hover throttle reference = what physically lifted the drone this flight (not the configured number)
    takeoff_slow_frac: float = 0.96     # from this fraction of the hover throttle the ground ramp creeps (the drone should leave the ground gently, the lift-off is noticed ~0.4 s late)
    climb_peak_frac: float = 0.45         # height change UP in flight: peak speed as a fraction of vz_lim
    descent_peak_frac: float = 0.45       # height change DOWN in flight: peak speed as a fraction of vz_lim (climbs use 0.8)
    takeoff_ramp_slow: float = 0.012    # throttle per second in the creep zone
    takeoff_start_frac: float = 0.85    # ground ramp starts at this fraction of the estimated hover throttle


class _KF2:
    """[position, velocity] filter with an acceleration input; measures either position or velocity."""

    def __init__(self, q_acc: float, r: float, p0: float = 1.0):
        self.x = [0.0, 0.0]
        self.P = [[p0, 0.0], [0.0, p0]]
        self.q, self.r = q_acc, r

    def predict(self, dt: float, a: float) -> None:
        x, v = self.x
        self.x = [x + v * dt + 0.5 * a * dt * dt, v + a * dt]
        P = self.P
        p00 = P[0][0] + dt * (P[1][0] + P[0][1]) + dt * dt * P[1][1]
        p01 = P[0][1] + dt * P[1][1]
        p10 = P[1][0] + dt * P[1][1]
        p11 = P[1][1]
        q = self.q
        self.P = [[p00 + q * dt ** 4 / 4, p01 + q * dt ** 3 / 2], [p10 + q * dt ** 3 / 2, p11 + q * dt * dt]]

    def update(self, meas: float, which: int) -> None:
        P = self.P
        s = P[which][which] + self.r
        k0, k1 = P[0][which] / s, P[1][which] / s
        y = meas - self.x[which]
        self.x = [self.x[0] + k0 * y, self.x[1] + k1 * y]
        p = [[P[0][0] - k0 * P[which][0], P[0][1] - k0 * P[which][1]], [P[1][0] - k1 * P[which][0], P[1][1] - k1 * P[which][1]]]
        self.P = [[p[0][0], p[0][1]], [p[1][0], p[1][1]]]


class _KF3:
    """Vertical filter [z, vz, b]: b is an acceleration bias (model error: weight, battery, thrust curve) learned from the range sensor."""

    def __init__(self, q_acc: float = 1.0, q_bias: float = 0.6, r: float = 0.02 ** 2):
        self.x = [0.0, 0.0, 0.0]
        self.P = [[1.0, 0, 0], [0, 1.0, 0], [0, 0, 1.0]]
        self.qa, self.qb, self.r = q_acc, q_bias, r

    def predict(self, dt: float, a_model: float) -> None:
        z, v, b = self.x
        a = a_model + b
        self.x = [z + v * dt + 0.5 * a * dt * dt, v + a * dt, b]
        F = [[1, dt, 0.5 * dt * dt], [0, 1, dt], [0, 0, 1]]
        P = self.P
        FP = [[sum(F[i][k] * P[k][j] for k in range(3)) for j in range(3)] for i in range(3)]
        Pn = [[sum(FP[i][k] * F[j][k] for k in range(3)) for j in range(3)] for i in range(3)]
        g = [0.5 * dt * dt, dt, 0.0]
        for i in range(3):
            for j in range(3):
                Pn[i][j] += self.qa * g[i] * g[j]
        Pn[2][2] += self.qb * dt
        self.P = Pn

    def update(self, z_meas: float, r_scale: float = 1.0) -> None:
        P = self.P
        s = P[0][0] + self.r * r_scale
        K = [P[i][0] / s for i in range(3)]
        y = z_meas - self.x[0]
        self.x = [self.x[i] + K[i] * y for i in range(3)]
        self.P = [[P[i][j] - K[i] * P[0][j] for j in range(3)] for i in range(3)]


class _KF4(_KF3):
    """Vertical filter [z, vz, b, t] (Nimbus keeps a TERRAIN state too): z = height above the take-off floor (global), t = how much the floor under the drone is above that
    floor, b = acceleration bias. The range sensor measures z - t. With t frozen (P_tt = 0) this is exactly _KF3."""

    def __init__(self, q_acc: float = 1.0, q_bias: float = 0.6, r: float = 0.02 ** 2, q_terrain: float = 0.0):
        self.x = [0.0, 0.0, 0.0, 0.0]
        self.P = [[1.0, 0, 0, 0], [0, 1.0, 0, 0], [0, 0, 1.0, 0], [0, 0, 0, 0.0]]
        self.qa, self.qb, self.r, self.qt = q_acc, q_bias, r, q_terrain

    def predict(self, dt: float, a_model: float) -> None:
        z, v, b, t = self.x
        a = a_model + b
        self.x = [z + v * dt + 0.5 * a * dt * dt, v + a * dt, b, t]
        F = [[1, dt, 0.5 * dt * dt, 0], [0, 1, dt, 0], [0, 0, 1, 0], [0, 0, 0, 1]]
        P = self.P
        FP = [[sum(F[i][k] * P[k][j] for k in range(4)) for j in range(4)] for i in range(4)]
        Pn = [[sum(FP[i][k] * F[j][k] for k in range(4)) for j in range(4)] for i in range(4)]
        g = [0.5 * dt * dt, dt, 0.0, 0.0]
        for i in range(4):
            for j in range(4):
                Pn[i][j] += self.qa * g[i] * g[j]
        Pn[2][2] += self.qb * dt
        Pn[3][3] += self.qt * dt
        self.P = Pn

    H = (1.0, 0.0, 0.0, -1.0)

    def innovation(self, meas: float, r_scale: float = 1.0) -> tuple[float, float]:
        """(y, S): measurement minus predicted range, and its variance."""
        P, H = self.P, self.H
        S = sum(H[i] * P[i][j] * H[j] for i in range(4) for j in range(4)) + self.r * r_scale
        return meas - (self.x[0] - self.x[3]), S

    def update(self, z_meas: float, r_scale: float = 1.0) -> None:
        P, H = self.P, self.H
        y, S = self.innovation(z_meas, r_scale)
        PH = [sum(P[i][j] * H[j] for j in range(4)) for i in range(4)]
        K = [PH[i] / S for i in range(4)]
        self.x = [self.x[i] + K[i] * y for i in range(4)]
        self.P = [[P[i][j] - K[i] * PH[j] for j in range(4)] for i in range(4)]

    def absorb_terrain(self, delta: float, var: float = 0.01) -> None:
        """The floor moved by delta under us (range jumped, physics says we did not): move the terrain state, not the height."""
        self.x[3] -= delta
        self.P[3][3] = max(self.P[3][3], var)
        for k in range(4):
            if k != 3:
                self.P[3][k] = self.P[k][3] = 0.0


class HoverController:
    def __init__(self, cfg: Optional[HoverConfig] = None):
        self.cfg = cfg or HoverConfig()
        c = self.cfg
        self.state = HoverState.IDLE
        self.kz = _KF4()
        self.kx = _KF2(q_acc=1.0, r=0.06 ** 2)
        self.ky = _KF2(q_acc=1.0, r=0.06 ** 2)
        self.z_ref = 0.0
        self.x_ref = self.y_ref = 0.0
        self.integ = 0.0
        self.thr_eff_est = 0.0
        self.tilt_x_est = self.tilt_y_est = 0.0     # estimated tilt (rad) from our own commands through the attitude lag
        self.batt_v = c.batt_v0
        self._batt_seen = False
        self.v_start = None                          # pack reading at the start of this flight: the throttle scales with the voltage RELATIVE to it (a constant scale error of the reading cancels)
        self.pitch_deg = self.roll_deg = 0.0
        self.last_optrange = -1e9
        self.t_state = 0.0
        self.t_last = None
        self.xy_disabled = False                    # set after a position runaway: stay level and land vertically
        self._init_fc_xy()
        self.lifted, self.ground_thr = False, None
        self.lift_thr = None
        self.imu_az = 0.0; self.t_imu = -1e9
        self.terrain_events = 0
        self._t_absorb = -1e9
        self._sus = []
        self.ground = 0.0                            # what the range sensor reads on the floor (measured before takeoff)
        self._raw_hist: deque = deque(maxlen=64)     # (time, raw range) while idle: the ground reference comes from here
        self._lift_cnt = 0
        self.t_lift = None; self.thr_at_lift = 0.0
        self._climb = None
        self._traj = None; self._traj_tag = None      # jerk-limited vertical reference (JerkLimited1D) and what it is for: ("up", cap) | ("hold", h) | ("land",)
        self._land_bias = None
        self._ramp = None                             # landing: (t0, throttle at t0) of the throttle ramp to idle
        self._contact_s = 0.0
        self._dt = 0.01
        self._learn: deque = deque(maxlen=3000); self._learn_dt = 0.01; self._learn_adopted = None
        self.ix = [0.0, 0.0]                          # XY position integrals (m*s)
        self.vz_ff = 0.0
        self.hover_ref = None                        # (throttle, pack V) that physically held the drone at lift-off: replaces the configured hover throttle for this flight
        self._flags: set = set()
        self.thr_learned = None                    # smoothed throttle that actually holds the drone in hover (used for the blind descent)
        self.runaway_since = None
        self._now = 0.0
        self.opt_times: deque = deque(maxlen=128)
        self.refused: list = []
        self.sign_done = False
        self.sign_base = [0.0, 0.0]
        self.sign_peak = [0.0, 0.0]
        self.flow_raw = [(0.0, 0.0), (0.0, 0.0)]        # last two raw flow readings (vx, vy), straight from the sensor
        self._base_samples = [[], []]
        self.cmd = Controls()
        self.reason = ""
        self.events: list = []

    # --- public ----------------------------------------------------------------------------
    @property
    def z(self) -> float: return self.kz.x[0]

    def _set_state(self, now: float, st: HoverState, why: str = "") -> None:
        if st != self.state:
            self.events.append((now, f"{self.state.value} -> {st.value}" + (f" ({why})" if why else "")))
            self.state, self.t_state, self.reason = st, now, why
            if st == HoverState.LAND:
                self._ramp, self._contact_s, self._traj, self._traj_tag, self._land_bias = None, 0.0, None, None, None
                self.ix = [0.0, 0.0]

    def observe(self, now: float, samples) -> None:
        """Feed telemetry while idle (so preflight can judge the data rate) without producing any control output."""
        for smp in samples:
            self._ingest(now, smp)

    def telemetry_health(self, now: float, window: float = 2.0) -> tuple[float, float]:
        """(range samples per second, longest gap in seconds) over the last `window` seconds."""
        t = [x for x in self.opt_times if now - x <= window]
        if not t:
            return 0.0, window
        pts = [now - window] + t + [now]
        return len(t) / window, max(b - a for a, b in zip(pts, pts[1:]))

    def preflight(self, now: float) -> tuple[bool, list]:
        c = self.cfg
        rate, gap = self.telemetry_health(now)
        why = []
        if rate < c.min_rate_hz:
            why.append(f"range data too slow: {rate:.1f} Hz (need {c.min_rate_hz:.0f}); raise the ELRS telemetry ratio")
        if gap > c.max_gap_s:
            why.append(f"range data has a {gap:.2f} s gap (limit {c.max_gap_s} s)")
        return (not why), why                     # the battery never blocks a takeoff: it only warns (see battery_warning())

    def battery_warning(self) -> str:
        """Text of the battery warning, or '' (warning only: the pilot decides)."""
        c = self.cfg
        if self.batt_v < c.batt_warn_v:
            return f"WARNING battery {self.batt_v:.1f} V is below {c.batt_warn_v:.1f} V (warning only: nothing is blocked, you decide)"
        return ""

    def start(self, now: float, force: bool = False) -> bool:
        c = self.cfg
        w = self.battery_warning()
        if w:
            self.events.append((now, w))
        ok, why = self.preflight(now)
        if not ok and not force:
            self.refused = why
            self.events.append((now, "takeoff refused: " + "; ".join(why)))
            return False
        self.refused = []
        recent = sorted(r for t, r in self._raw_hist if now - t <= 1.5)
        if len(recent) >= 5:
            self.ground = recent[len(recent) // 2]                        # median of the last 1.5 s: the sensor's reading on the floor
        elif not force:
            self.refused = ["no recent range readings to measure the ground reference"]
            self.events.append((now, "takeoff refused: " + self.refused[0])); return False
        else:
            self.ground = 0.0
        if self.ground > c.ground_max_m and not force:
            self.refused = [f"range sensor reads {self.ground:.2f} m on the ground (limit {c.ground_max_m:.2f}): something under the drone or the sensor is blocked"]
            self.events.append((now, "takeoff refused: " + self.refused[0])); return False
        self.events.append((now, f"ground reference {self.ground:.3f} m (heights are relative to it)"))
        self._lift_cnt = 0
        self.kz = _KF4(q_terrain=c.terrain_q if c.terrain_gate else 0.0); self.kx = _KF2(1.0, 0.06 ** 2); self.ky = _KF2(1.0, 0.06 ** 2)
        self._sus = []                               # consecutive range readings the physics model rejected (signed innovations)
        self.lifted, self.ground_thr = False, None
        self.lift_thr = None; self.hover_ref = None; self._flags = set(); self._climb = None; self.vz_ff = 0.0; self.t_lift = None
        self._traj = self._traj_tag = self._ramp = None; self._contact_s = 0.0; self.ix = [0.0, 0.0]
        self._learn.clear(); self._learn_adopted = None
        self.v_start = self.batt_v
        self.z_ref, self.integ, self.t_last = 0.0, 0.0, now
        self.xy_disabled = False
        self.thr_learned, self.runaway_since = None, None
        self.sign_peak, self.sign_base, self._base_samples = [0.0, 0.0], [0.0, 0.0], [[], []]
        self.sign_done = False
        self.last_optrange = now
        self._set_state(now, HoverState.TAKEOFF)
        return True

    def land(self, now: float, why: str = "operator") -> None:
        if self.state in (HoverState.TAKEOFF, HoverState.SIGN_CHECK, HoverState.HOVER):
            if abs(self.kz.x[3]) > 1e-6:                                # land onto whatever is under us now: height above THAT surface, terrain back to zero
                self.kz.x[0] -= self.kz.x[3]; self.kz.x[3] = 0.0; self.z_ref = min(self.z_ref, self.kz.x[0] + 0.05)
            self._set_state(now, HoverState.LAND, why)

    def update(self, now: float, samples, dt: float) -> Controls:
        c = self.cfg
        self._now = now
        self._dt = dt
        if self.state in (HoverState.IDLE, HoverState.DONE):
            self.cmd = Controls(arm=False)
            return self.cmd
        self._predict(dt)
        for s in samples:
            self._ingest(now, s)
        self._supervise(now)
        if self.state == HoverState.DONE:
            self.cmd = Controls(arm=False)
            return self.cmd
        thr = self._altitude(now, dt)
        pitch, roll = self._horizontal(dt)
        ramping = self.state == HoverState.LAND and self._ramp is not None
        thr = min(max(thr, 0.0 if ramping else (c.thr_min_air if self.z > 0.03 else 0.0)), c.thr_max)
        self.thr_eff_est += (thr - self.thr_eff_est) * dt / c.tau_motor
        lim = math.radians(c.angle_limit_deg)
        self.tilt_x_est += (pitch * lim - self.tilt_x_est) * dt / c.tau_att          # physical tilt we asked for
        self.tilt_y_est += (roll * lim - self.tilt_y_est) * dt / c.tau_att
        self.cmd = Controls(roll=roll * c.roll_sign, pitch=pitch * c.pitch_sign, yaw=0.0, throttle=thr, arm=True)   # hardware signs applied once, here
        return self.cmd

    # --- estimation ------------------------------------------------------------------------
    def _cal_range(self, z: float) -> float:
        pts = self.cfg.range_cal
        if not pts or z <= pts[0][0]:
            return z
        for (r0, t0), (r1, t1) in zip(pts, pts[1:]):
            if z <= r1:
                return t0 + (t1 - t0) * (z - r0) / (r1 - r0)
        return pts[-1][1] + (z - pts[-1][0])

    def _hover0(self) -> tuple[float, float]:
        """(hover throttle, pack voltage it applies at): from the flight when known (lift-off, later the settled-hover median), else the configured hover throttle taken at the pack reading at the start of the flight (only RELATIVE voltage changes matter)."""
        c = self.cfg
        return self.hover_ref if self.hover_ref is not None else (c.thr_hover0, self.v_start if self.v_start is not None else self.batt_v)

    def _thrust_ratio(self) -> float:
        c = self.cfg
        h0, v0 = self._hover0()
        u = max(self.thr_eff_est - c.thr_idle, 0.0) / max(h0 - c.thr_idle, 1e-6)
        return (u ** c.thrust_exp) * (self.batt_v / v0) ** 2

    def _predict(self, dt: float) -> None:
        c = self.cfg
        az = G * (self._thrust_ratio() * math.cos(self.tilt_x_est) * math.cos(self.tilt_y_est) - 1.0) - 0.15 * self.kz.x[1]
        if c.use_imu and self._now - self.t_imu < c.imu_stale_s and self.lifted:
            az = self.imu_az                         # measured acceleration (already includes drag and the real thrust); the bias state absorbs its constant error
        if self.kz.x[0] <= 0.0 and az < 0:
            az = 0.0
            self.kz.x[1] = max(self.kz.x[1], 0.0)
        self.kz.predict(dt, az)
        if self.kz.x[0] < 0.0:
            self.kz.x[0] = 0.0
            self.kz.x[1] = max(self.kz.x[1], 0.0)
        ax = G * math.tan(self.tilt_x_est) - c.drag * self.kx.x[1]
        ay = G * math.tan(self.tilt_y_est) - c.drag * self.ky.x[1]
        if self.kz.x[0] < 0.03:                       # on the ground: no horizontal motion
            ax = ay = 0.0
            self.kx.x[1] *= 0.5; self.ky.x[1] *= 0.5
        self.kx.predict(dt, ax)
        self.ky.predict(dt, ay)

    def _ingest(self, now: float, s) -> None:
        c = self.cfg
        d = s.data
        if s.kind == "optrange":
            self.last_optrange = now
            if d["distance_m"] <= 0.005 and self.ground > 0.02:    # the decoder reports 0.0 for an invalid/out-of-range reading (seen when the drone tilts): not a measurement
                return
            self.opt_times.append(now)
            tilt_cos = max(math.cos(math.radians(self.pitch_deg)) * math.cos(math.radians(self.roll_deg)), 0.5)
            if self.state in (HoverState.IDLE, HoverState.DONE):
                self._raw_hist.append((now, d["distance_m"]))
            z_meas = max(self._cal_range(d["distance_m"] * tilt_cos) - self.ground, 0.0)     # height above the floor reading measured before takeoff
            dly = c.sensor_delay_s
            vz = self.kz.x[1]
            if z_meas < 0.04 and not self.lifted:                # sitting on the ground: believe the range sensor, no predicted climb
                self.kz.x[0], self.kz.x[1], self.kz.x[2] = z_meas, min(vz, 0.0), self.kz.x[2]
            else:
                lo, hi = c.range_untrusted
                untrusted = lo < d["distance_m"] < hi and self.lifted      # the sensor over-reads here (measured +9 cm at 20-30 cm): ride on the physics model, not on these readings
                rs = c.range_untrusted_r_scale if untrusted else 1.0
                meas = z_meas + vz * dly                               # bring the old reading forward to now
                gate_on = (c.terrain_gate and self.lifted and self.state in (HoverState.SIGN_CHECK, HoverState.HOVER) and self.kz.x[0] >= c.range_untrusted[1])
                if gate_on:
                    y, S = self.kz.innovation(meas, rs)
                    allowed = min(max(c.gate_sigma * math.sqrt(max(S, 1e-9)), c.gate_floor_m), c.gate_max_m)
                    if abs(y) <= allowed:
                        self._sus.clear(); self.kz.update(meas, rs)       # physically plausible: a normal update
                    else:                                              # the physics model cannot explain this reading
                        self._sus.append(y)
                        if len(self._sus) >= c.absorb_n:
                            mean = sum(self._sus) / len(self._sus)
                            if max(self._sus) - min(self._sus) <= c.absorb_spread_m and abs(self.kz.x[3] - mean) <= c.terrain_max_m and now - self._t_absorb >= c.absorb_min_gap_s:       # consistent: the FLOOR changed (box, rug, step), not us
                                self.kz.absorb_terrain(mean); self._t_absorb = now
                                self.terrain_events += 1
                                self.events.append((now, f"floor changed by {-mean * 100:+.0f} cm under the drone: absorbed into the terrain state (height unchanged)"))
                                self._sus.clear()
                            else:
                                del self._sus[0]                       # erratic, not a clean step: keep ignoring it
                else:
                    self.kz.update(meas, rs)
            flow_ok = d.get("quality", 255) >= c.flow_min_quality and self.kz.x[0] > 0.05
            self._flow_b = (now, d["flow_vx"], d["flow_vy"], flow_ok)
            if flow_ok:
                self.flow_raw = [self.flow_raw[1], (d["flow_vx"], d["flow_vy"])]
                if not self.fc_xy_in_use(now):                       # the FC estimate drives XY when it is trusted and fresh; the PC flow filter is the fallback
                    self.kx.update(d["flow_vx"] + 0.0, 1)
                    self.ky.update(d["flow_vy"] + 0.0, 1)
                self.xy_active = "fc" if self.fc_xy_in_use(now) else "pc"
        elif s.kind == "fcxy":
            self._ingest_fcxy(now, d)
        elif s.kind == "imu":
            self.imu_az, self.t_imu = d["az_mean"], now
        elif s.kind == "attitude":
            self.pitch_deg, self.roll_deg = d["pitch_deg"], d["roll_deg"]
        elif s.kind == "battery":
            if not self._batt_seen:
                self.batt_v, self._batt_seen = d["voltage_v"], True
            else:
                self.batt_v += 0.3 * (d["voltage_v"] - self.batt_v)

    # --- FC horizontal estimate -------------------------------------------------------------------
    def _init_fc_xy(self) -> None:
        self.fc_xy_t = -1e9                       # time of the last valid FC velocity
        self.fc_xy_sign = 0                       # +1 / -1 = yaw convention that agrees with the flow, 0 = not yet known
        self._fcxy_err = {1: 0.0, -1: 0.0}; self._fcxy_energy = 0.0
        self._flow_b = None                       # (time, forward, right, quality-ok) of the latest PC flow
        self.xy_active = "pc"

    def fc_xy_in_use(self, now: float) -> bool:
        return self.cfg.xy_source == "fc" and self.fc_xy_sign != 0 and now - self.fc_xy_t <= self.cfg.fc_xy_max_age_s

    @staticmethod
    def _to_body(vx: float, vy: float, yaw_deg: float, sign: int) -> tuple:
        a = math.radians(yaw_deg) * sign
        return math.cos(a) * vx + math.sin(a) * vy, -math.sin(a) * vx + math.cos(a) * vy

    def _ingest_fcxy(self, now: float, d: dict) -> None:
        """FC EKF velocity (world frame of the FC's attitude quaternion) -> body forward/right. The yaw sign convention is not assumed: both candidates are scored
        against the PC's own flow (forward/right) while the drone moves, and the better one is used only when it clearly agrees; until then the PC flow filter runs."""
        c = self.cfg
        if c.xy_source != "fc":
            return
        vx, vy, yaw = d["vx_mps"], d["vy_mps"], d["yaw_deg"]
        fb = self._flow_b
        if fb is not None and now - fb[0] < 0.25 and fb[3]:
            for sgn in (1, -1):
                bx, by = self._to_body(vx, vy, yaw, sgn)
                self._fcxy_err[sgn] = 0.98 * self._fcxy_err[sgn] + (bx - fb[1]) ** 2 + (by - fb[2]) ** 2
            self._fcxy_energy = 0.98 * self._fcxy_energy + fb[1] ** 2 + fb[2] ** 2
            n = 50.0                                                  # effective window ~50 samples
            if self._fcxy_energy / n >= c.fc_xy_min_energy:
                best = 1 if self._fcxy_err[1] <= self._fcxy_err[-1] else -1
                e_b, e_o = self._fcxy_err[best], self._fcxy_err[-best]
                agree = e_b <= c.fc_xy_agree_ratio * e_o and e_b <= 0.5 * self._fcxy_energy
                if agree and best != self.fc_xy_sign:
                    self.fc_xy_sign = best
                    self.events.append((now, f"FC horizontal estimate agrees with the flow (yaw convention {'+' if best > 0 else '-'}): XY now from the FC EKF"))
                elif not agree and self.fc_xy_sign != 0 and e_b > 0.9 * self._fcxy_energy:
                    self.fc_xy_sign = 0
                    self.events.append((now, "FC horizontal estimate no longer agrees with the flow: XY back on the PC flow filter"))
        if self.fc_xy_sign == 0 or not d.get("valid", True):
            return
        bx, by = self._to_body(vx, vy, yaw, self.fc_xy_sign)
        self.fc_xy_t = now
        self.kx.update(bx, 1)
        self.ky.update(by, 1)

    # --- supervision (safety envelope) ---------------------------------------------------------
    def _supervise(self, now: float) -> None:
        c, st = self.cfg, self.state
        airborne = self.z > 0.10
        if max(abs(self.pitch_deg), abs(self.roll_deg)) > c.tilt_abort_deg:
            self._set_state(now, HoverState.DONE, "tilt exceeded"); return
        stale = now - self.last_optrange
        if st in (HoverState.TAKEOFF, HoverState.SIGN_CHECK, HoverState.HOVER, HoverState.LAND) and stale > c.stale_s and airborne:
            self._set_state(now, HoverState.SENSOR_LOSS, f"no range data for {stale:.1f}s"); return
        if st in (HoverState.SIGN_CHECK, HoverState.HOVER) and now - self.t_state > 2.0 and airborne:
            rate, _ = self.telemetry_health(now)
            if rate < c.min_rate_inflight_hz:
                self.land(now, f"range data too slow in flight: {rate:.1f} Hz")
        if st == HoverState.SENSOR_LOSS:
            if now - self.t_state > c.sensor_loss_timeout_s:
                self._set_state(now, HoverState.DONE, "sensor loss descent finished"); return
            if now - self.t_state > c.sensor_loss_open_loop_s and stale < c.stale_s:
                self._set_state(now, HoverState.LAND, "sensors back, landing under control")
            return
        if st == HoverState.TAKEOFF and not self.lifted and now - self.t_state > c.takeoff_timeout_s:
            self._set_state(now, HoverState.DONE, f"no lift-off within {c.takeoff_timeout_s:.0f} s: stopped (check props, battery, tether, ground)"); return
        if st in (HoverState.TAKEOFF, HoverState.SIGN_CHECK, HoverState.HOVER):
            if self.z > c.ceiling:
                self.land(now, "ceiling")
            elif c.batt_autoland and self.batt_v < c.batt_land_v:
                self.land(now, f"battery {self.batt_v:.1f} V")
            elif self.batt_v < c.batt_land_v and "batt_low" not in self._flags:
                self._flags.add("batt_low"); self.events.append((now, f"WARNING battery {self.batt_v:.1f} V is below {c.batt_land_v:.1f} V: no automatic landing (you decide)"))
            elif st == HoverState.HOVER:
                dist = math.hypot(self.kx.x[0] - self.x_ref, self.ky.x[0] - self.y_ref)
                speed = math.hypot(self.kx.x[1], self.ky.x[1])
                if dist > c.runaway_m or speed > c.runaway_speed:
                    self.runaway_since = self.runaway_since if self.runaway_since is not None else now
                    if now - self.runaway_since > c.runaway_hold_s:
                        self.xy_disabled = True                   # stop steering: a wrong sign would keep pushing us away
                        self.land(now, "position runaway")
                else:
                    self.runaway_since = None
        if st == HoverState.TAKEOFF and c.sign_check and not self.sign_done and self.z >= c.sign_height - 0.03 and abs(self.kz.x[1]) < 0.2:
            self.x_ref, self.y_ref = self.kx.x[0], self.ky.x[0]
            self._base_samples = [[], []]
            self._set_state(now, HoverState.SIGN_CHECK)
        elif st == HoverState.TAKEOFF and (self.sign_done or not c.sign_check) and self.z >= c.hover_height - 0.05 and abs(self.kz.x[1]) < 0.2:
            if not c.sign_check:
                self.x_ref, self.y_ref = self.kx.x[0], self.ky.x[0]  # no test pulses: hold where we are; otherwise keep the take-off point
            self._set_state(now, HoverState.HOVER)
        if st == HoverState.SIGN_CHECK:
            e = now - self.t_state
            mean2 = [(self.flow_raw[0][a] + self.flow_raw[1][a]) / 2.0 for a in (0, 1)]    # raw sensor, not the filter (it predicts the pulse works)
            if 0.4 <= e < 1.0:
                for a in (0, 1):
                    self._base_samples[a].append(mean2[a])
            elif e >= 1.0 and self._base_samples[0] and self.sign_base == [0.0, 0.0]:
                self.sign_base = [sum(b) / len(b) for b in self._base_samples]
            for axis, (t0, t1) in enumerate(((1.0, 2.1), (2.7, 3.8))):
                if t0 <= e <= t1:                                   # best response (positive velocity change) in this axis' window
                    self.sign_peak[axis] = max(self.sign_peak[axis], mean2[axis] - self.sign_base[axis])
                if e > t1 and axis == 0 and self.sign_peak[0] < c.sign_min_response_mps:
                    self.xy_disabled = True; self.land(now, "pitch sign check failed: no forward response (wrong sign or flow sensor?)")
                if e > t1 and axis == 1 and self.sign_peak[1] < c.sign_min_response_mps:
                    self.xy_disabled = True; self.land(now, "roll sign check failed: no rightward response (wrong sign or flow sensor?)")
            if self.state == HoverState.SIGN_CHECK and e > 3.8 + 1.0:
                self.sign_done = True                                # the hold point stays where the drone TOOK OFF: it returns there after the test pulses
                self._set_state(now, HoverState.TAKEOFF, "sign check passed, climbing to hover height")
        if st == HoverState.LAND:
            self._contact_s = self._contact_s + self._dt if self.z < c.land_contact_height else 0.0
            if self._ramp is not None and now - self._ramp[0] >= c.land_ramp_s:
                self._set_state(now, HoverState.DONE, "landed")
            elif self._contact_s >= c.land_contact_s:
                self._set_state(now, HoverState.DONE, "landed (floor contact)")

    # --- control laws ----------------------------------------------------------------------
    def fc_target_height(self):
        """Height (m) the FC-side hold should be asked for in the current phase, or None (the PC keeps the throttle): from lift-off on, the sign-check height until the
        sign check has passed, then the hover height. Not while landing."""
        c = self.cfg
        if self.state == HoverState.SIGN_CHECK:
            return c.sign_height
        if self.state == HoverState.TAKEOFF and self.lifted:
            return c.hover_height if (self.sign_done or not c.sign_check) else c.sign_height
        if self.state == HoverState.HOVER:
            return c.hover_height
        return None

    def command_height(self, now: float, h: float) -> bool:
        """Change the hold height while flying. In HOVER the height reference glides there on a jerk-limited S-curve (speed limit min(ref_v_max, peak fraction x vz_lim)) with a velocity feed-forward: no step in the reference. During the takeoff it just changes the climb target. Refused while landing."""
        c = self.cfg
        if self.state in (HoverState.LAND, HoverState.DONE, HoverState.SENSOR_LOSS):
            return False
        c.hover_height = h
        c.ceiling = max(c.ceiling, h + 0.3)                  # raised only: lowering it under a drone that is still above would trigger a ceiling landing
        if self.state == HoverState.HOVER:
            peak = (c.climb_peak_frac if h > self.z_ref else c.descent_peak_frac) * c.vz_lim      # descending is gentler: the drone speeds up under gravity and brakes late
            self._plan(self.z_ref, self.vz_ff, h, min(peak, c.ref_v_max), ("hold", h))
        self.events.append((now, f"hold height -> {h:.2f} m"))
        return True

    def _thr_hover_now(self) -> float:
        c = self.cfg
        h0, v0 = self._hover0()
        scale = (v0 / max(self.batt_v, 1.0)) ** (2.0 / c.thrust_exp)                # thrust ~ V^2 * u^exp  =>  the throttle that still balances weight scales with V^(-2/exp); v0 is a reading of the same sensor, so a scale error cancels
        return c.thr_idle + (h0 - c.thr_idle) * min(scale, 1.6)

    def _plan(self, z0: float, v0: float, z1: float, v_max: float, tag: tuple) -> None:
        self._traj = JerkLimited1D(max(v_max, 0.02), self.cfg.ref_a_max, self.cfg.ref_j_max)
        self._traj.plan(z0, v0, z1)
        self._traj_tag = tag

    def _learn_hover(self, thr: float, dt: float) -> None:
        """Settled hover (|vz| < 0.15 m/s, within 5 cm of the reference): remember the throttle that really holds the drone; after hover_learn_min_s of it, it becomes
        the hover reference (the base throttle) instead of the lift-off value."""
        c = self.cfg
        self._learn.append((thr, self.batt_v)); self._learn_dt = dt
        if len(self._learn) * dt < c.hover_learn_min_s or len(self._learn) % 100 != 0:
            return
        h, b = self.hover_learned_raw()
        cur = self._hover0()[0]
        if self._learn_adopted is None or abs(h - self._learn_adopted) > 0.01:
            a_old = G * (self._thrust_ratio() - 1.0)
            self.hover_ref = (h, b)
            self._learn_adopted = h
            a_new = G * (self._thrust_ratio() - 1.0)
            self.kz.x[2] += a_old - a_new                      # the model changed: keep the predicted acceleration (bias state absorbs the difference)
            self.integ = 0.0
            self.events.append((self._now, f"hover throttle from flight data: {h:.3f} at {b:.2f} V (was {cur:.3f})"))

    def hover_learned_raw(self) -> tuple[float, float]:
        xs = sorted(t for t, _ in self._learn); bs = sorted(v for _, v in self._learn)
        return xs[len(xs) // 2], bs[len(bs) // 2]

    def hover_learned(self) -> Optional[tuple[float, float, float]]:
        """(median hover throttle, median pack reading, seconds of settled hover behind it), or None until 5 s of settled hover. For the caller to persist: the
        throttle belongs to THAT pack reading (the reading's own scale), see _thr_hover_now for how it is used."""
        n = len(self._learn) * self._learn_dt
        if n < self.cfg.hover_learn_report_s:
            return None
        h, b = self.hover_learned_raw()
        return h, b, n

    def _altitude(self, now: float, dt: float) -> float:
        c, st = self.cfg, self.state
        if st == HoverState.SENSOR_LOSS:
            base = self.thr_learned if self.thr_learned is not None else self._thr_hover_now() + self.integ
            return base - c.sensor_loss_thr_drop
        z, vz, bias = self.kz.x[:3]
        if st == HoverState.TAKEOFF:
            if self.lifted and z < 0.02 and vz < 0.05:
                self.lifted = False                              # sank back to the ground: keep raising the throttle from where we were
                self._traj = self._traj_tag = None
                self.integ = 0.0
            if not self.lifted:
                if self.ground_thr is None:
                    self.ground_thr = c.takeoff_start_frac * self._thr_hover_now()
                slow = self.ground_thr >= c.takeoff_slow_frac * self._thr_hover_now()
                self.ground_thr += (c.takeoff_ramp_slow if slow else c.takeoff_ramp_rate) * dt      # raise throttle slowly until we leave the ground
                if (z > 0.05 and vz > 0.02) or (vz > 0.10 and z > 0.02):
                    self._lift_cnt += 1
                else:
                    self._lift_cnt = 0
                if self._lift_cnt >= 3:                                         # 3 consecutive confirmations (~0.1 s): a single noisy reading is not a lift-off
                    self.lifted = True
                    self.t_lift = now; self.thr_at_lift = self.ground_thr
                    self.lift_thr = max(self.ground_thr - c.takeoff_lift_margin, c.thr_idle)         # the throttle that physically lifted us
                    exp_h = self._hover0()[0]
                    if c.use_lift_ref and abs(self.lift_thr - self._thr_hover_now()) <= c.lift_hover_tol * max(exp_h, 0.1):
                        self.hover_ref = (self.lift_thr, self.batt_v)                                # the hover reference for the rest of this flight (at this pack voltage)
                    else:
                        self.events.append((now, f"lift-off throttle {self.lift_thr:.3f} is not plausible (expected about {self._thr_hover_now():.3f}): using the configured hover throttle"))
                    a_model = G * (self._thrust_ratio() * math.cos(self.tilt_x_est) * math.cos(self.tilt_y_est) - 1.0)
                    self.integ = 0.0
                    self.kz.x[2] = -a_model + 0.3                # at lift-off the real acceleration is ~0: whatever the model predicts is its error
                    self.z_ref = max(z, 0.0)                    # the height target starts from where we really are
                    self._traj = self._traj_tag = None; self.vz_ff = min(max(vz, 0.0), c.ref_v_max)       # the reference continues the climb the drone is already in
                else:
                    self.z_ref = 0.0
                    return min(self.ground_thr, c.thr_max, c.soft_start_per_s * max(now - self.t_state, 0.0))
            cap = c.hover_height if (self.sign_done or not c.sign_check) else c.sign_height
            if c.climb_min_jerk:
                if self._traj_tag != ("up", cap):                                          # (re)start the S-curve from where the reference is now
                    self._plan(max(self.z_ref, 0.0), self.vz_ff, cap, c.ref_v_max, ("up", cap))
                self.z_ref, self.vz_ff, _ = self._traj.step(dt)
            else:
                self.z_ref = min(self.z_ref + c.takeoff_rate * dt, cap)
        elif st == HoverState.HOVER:
            if self._traj is not None and self._traj_tag[0] == "hold" and not self._traj.done:
                self.z_ref, self.vz_ff, _ = self._traj.step(dt)
            else:
                self._traj = self._traj_tag = None
                self.z_ref = c.hover_height; self.vz_ff = 0.0
        elif st == HoverState.SIGN_CHECK:
            self.z_ref = c.sign_height; self.vz_ff = 0.0; self._traj = self._traj_tag = None
        elif st == HoverState.LAND:
            if self._traj_tag != ("land",):                    # constant land_rate descent (S-curve start), XY held; the throttle ramp takes over near the floor
                z0 = self.z if self.z_ref > self.z + 0.2 else self.z_ref      # entered LAND from above the reference: start from where we are
                self._plan(z0, self.vz_ff, z0 - 5.0, c.land_rate, ("land",))
            self.z_ref, self.vz_ff, _ = self._traj.step(dt)
            self.z_ref = max(self.z_ref, -0.1)
        e = self.z_ref - z
        vz_ref = min(max(c.kp_z * e + self.vz_ff, -c.vz_lim), c.vz_lim)
        if z > 0.05 and st != HoverState.TAKEOFF or (st == HoverState.TAKEOFF and self.lifted and z > 0.05):
            self.integ = min(max(self.integ + c.ki_z * e * dt, -c.i_max), c.i_max)
        gain = G * c.thrust_exp / max(self._hover0()[0] - c.thr_idle, 1e-6)          # m/s^2 of vertical acceleration per unit of throttle, at hover
        if st == HoverState.LAND:
            if self._land_bias is None:
                self._land_bias = bias                           # the descent is slow and the bias observer only adds a wobble to it: keep the value it had when landing began
            bias = self._land_bias
        ff = -c.bias_ff * min(max(bias, -3.0), 3.0) / gain if z > 0.05 else 0.0
        base = self._thr_hover_now()
        if st == HoverState.TAKEOFF and self.t_lift is not None and c.lift_blend_s > 0:
            w = min(max((now - self.t_lift) / c.lift_blend_s, 0.0), 1.0)                     # hand over from the creep throttle to the hover reference smoothly (no step)
            base = (1.0 - w) * self.thr_at_lift + w * base
        thr = base + c.kv_z * (vz_ref - vz) + self.integ + ff
        grace = c.lift_grace_m if (self.t_lift is not None and now - self.t_lift < c.lift_grace_s) else 0.0      # the lift-off is noticed late: the drone is ahead of a slow reference for a moment, do not slam the throttle for that
        if st in (HoverState.TAKEOFF, HoverState.SIGN_CHECK, HoverState.HOVER) and z > 0.05 and (z > self.z_ref + c.overshoot_m + grace or vz > c.overshoot_vz):
            thr = min(thr, self._thr_hover_now() - c.overshoot_cut)          # overshoot damper: climbing too high/fast -> throttle below hover immediately
            self.integ = min(self.integ, 0.0)
            if "overshoot" not in self._flags:
                self._flags.add("overshoot"); self.events.append((self._now, f"overshoot damper (z {z:.2f}, vz {vz:+.2f})"))
        elif z < self.z_ref + c.overshoot_m * 0.5 and vz < c.overshoot_vz * 0.5:
            self._flags.discard("overshoot")
        if st in (HoverState.HOVER, HoverState.SIGN_CHECK) and abs(vz) < 0.15:       # remember the throttle that really holds us up
            self.thr_learned = thr if self.thr_learned is None else self.thr_learned + 0.02 * (thr - self.thr_learned)
        if st == HoverState.HOVER and self.lifted and abs(vz) < 0.15 and abs(z - self.z_ref) < 0.05:
            self._learn_hover(thr, dt)
        if st == HoverState.LAND:
            if self._ramp is None and z <= c.land_ramp_height:
                self._ramp = (now, thr)                                   # from the current throttle ...
            if self._ramp is not None:
                t0, thr0 = self._ramp                                     # ... linearly to idle
                ramp = thr0 + (c.thr_idle - thr0) * min(max((now - t0) / c.land_ramp_s, 0.0), 1.0)
                thr = ramp if vz > -c.land_sink_guard else max(ramp, thr)  # soft touchdown: sinking too fast keeps the altitude loop as a floor
        return thr

    def _horizontal(self, dt: float) -> tuple[float, float]:
        c = self.cfg
        if self.xy_disabled or self.z < 0.15 or self.state in (HoverState.SENSOR_LOSS, HoverState.DONE) \
                or (self.state == HoverState.TAKEOFF and c.sign_check and not self.sign_done):
            self.ix = [0.0, 0.0]
            return 0.0, 0.0
        if self.state == HoverState.SIGN_CHECK:                      # small test pulses: forward, then right; the supervisor checks the response
            e = self._now - self.t_state
            lim = c.sign_pulse_deg / c.angle_limit_deg
            if 1.0 <= e < 1.5:                                    # open loop on purpose: feedback would hide a wrong sign
                return lim, 0.0
            if 1.5 <= e < 2.1 or 3.2 <= e < 3.8:
                return 0.0, 0.0                                   # coast and measure
            if 2.7 <= e < 3.2:
                return 0.0, lim
            # outside the measuring windows: normal position hold, so the drone brakes and returns to where it was
        out = []
        a_lim = G * math.tan(math.radians(c.xy_i_max_deg))             # the integral may contribute at most xy_i_max_deg of tilt
        landing = self.state == HoverState.LAND
        if landing:
            self.ix = [0.0, 0.0]                                       # reset once landing starts, no integration
        tmax = math.radians(c.tilt_max_deg)
        for i, (kf, ref) in enumerate(((self.kx, self.x_ref), (self.ky, self.y_ref))):
            x, v = kf.x
            e = ref - x
            v_ref = min(max(c.kp_pos * e, -c.v_lim), c.v_lim)
            a = c.kv_xy * (v_ref - v)
            a_i = min(max(c.ki_xy * self.ix[i], -a_lim), a_lim)
            tilt_raw = math.atan2(a + a_i, G)
            tilt = min(max(tilt_raw, -tmax), tmax)
            if not landing and c.ki_xy > 0.0 and abs(tilt_raw) < tmax and abs(e) < c.xy_i_range_m:    # conditional anti-windup: only while the command is not saturated and the error is small
                self.ix[i] = min(max(self.ix[i] + e * dt, -a_lim / c.ki_xy), a_lim / c.ki_xy)
            out.append(tilt / math.radians(c.angle_limit_deg))
        px, ry = out
        return px, ry                                    # physical sticks; hardware signs are applied in update()
