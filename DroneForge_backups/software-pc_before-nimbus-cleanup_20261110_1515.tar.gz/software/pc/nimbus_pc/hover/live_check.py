"""Hover controller on the LIVE link, observe-only (nothing is armed, no control output is ever produced).

Real telemetry (0xD3 range+flow, attitude, battery) goes into the same HoverController the simulator and the HIL run use.
Prints what it would believe (altitude estimate, flow velocity, tilt, battery) and whether its preflight would allow a takeoff.
The sender stays at idle: sticks centred, throttle minimum, arm LOW. The controller's start()/update() are never called.

    python3 -m nimbus_pc.hover.live_check --adapter <CP2102> --duration 60
Use it for the bench checks: range vs a ruler, flow sign when you slide the drone (hand-held, props off), telemetry rate.
"""
from __future__ import annotations

import argparse
import math
import statistics
import sys
import threading
import time

from nimbus_pc.sender import Controls
from nimbus_pc.session import Session

from .controller import HoverConfig, HoverController
from .sim import Sample


def to_sample(name: str, d: dict, now: float):
    if name == "optrange":
        return Sample(now, "optrange", {"distance_m": d["distance_m"], "flow_vx": d["velocity_forward"], "flow_vy": d["velocity_right"],
                                        "quality": d["flow_quality"]})
    if name == "attitude":
        return Sample(now, "attitude", {"pitch_deg": math.degrees(d["pitch_rad"]), "roll_deg": math.degrees(d["roll_rad"]), "yaw_deg": math.degrees(d["yaw_rad"])})
    if name == "battery":
        return Sample(now, "battery", {"voltage_v": d["voltage_v"]})
    return None


def run(adapter: str, duration: float, hz: float = 2.0, log=print) -> dict:
    ctl = HoverController(HoverConfig())
    box: list = []
    lock = threading.Lock()
    raw = {"dist": [], "vx": [], "vy": [], "q": []}
    t0 = time.monotonic()

    def on_tel(name: str, d: dict) -> None:
        now = time.monotonic() - t0
        s = to_sample(name, d, now)
        if s is None:
            return
        with lock:
            box.append(s)
            if name == "optrange":
                raw["dist"].append(d["distance_m"]); raw["vx"].append(d["velocity_forward"]); raw["vy"].append(d["velocity_right"]); raw["q"].append(d["flow_quality"])

    s = Session(adapter, hz=100.0, allow_arm=False, ping=True, on_telemetry=on_tel)
    ok_n = n = 0
    last_print = 0.0
    why_last: list = []
    try:
        s.start()
        while True:
            now = time.monotonic() - t0
            if now >= duration:
                break
            s.set_controls(Controls())                        # idle, disarmed
            with lock:
                got, box[:] = list(box), []
            ctl.observe(now, got)
            if now - last_print >= 1.0 / hz:
                last_print = now
                ok, why = ctl.preflight(now)
                why_last = why
                if now > 6.0:
                    n += 1; ok_n += bool(ok)
                rate, gap = ctl.telemetry_health(now)
                with lock:
                    d = raw["dist"][-1] if raw["dist"] else float("nan")
                    vx = raw["vx"][-1] if raw["vx"] else float("nan"); vy = raw["vy"][-1] if raw["vy"] else float("nan"); q = raw["q"][-1] if raw["q"] else -1
                log(f"t={now:5.1f}s range={d:5.2f} m z_est={ctl.z:5.3f} m flow=({vx:+.2f},{vy:+.2f}) m/s q={q:3d} "
                    f"tilt=({ctl.pitch_deg:+.1f},{ctl.roll_deg:+.1f})deg batt={ctl.batt_v:4.1f}V rate={rate:4.1f}Hz gap={gap:.2f}s "
                    f"preflight={'OK' if ok else 'NO: ' + '; '.join(why)}")
            time.sleep(0.01)
    finally:
        s.set_controls(Controls()); time.sleep(0.1); s.stop()
    out = {"seconds": duration, "preflight_ok_pct": round(100.0 * ok_n / max(n, 1), 1), "last_preflight_reasons": why_last}
    with lock:
        if len(raw["dist"]) > 5:
            out["range_samples"] = len(raw["dist"]); out["range_rate_hz"] = round(len(raw["dist"]) / duration, 1)
            out["range_mean_m"] = round(statistics.mean(raw["dist"]), 3); out["range_sd_m"] = round(statistics.pstdev(raw["dist"]), 4)
            out["flow_vx_mean"] = round(statistics.mean(raw["vx"]), 3); out["flow_vy_mean"] = round(statistics.mean(raw["vy"]), 3)
            out["flow_vx_sd"] = round(statistics.pstdev(raw["vx"]), 3); out["flow_vy_sd"] = round(statistics.pstdev(raw["vy"]), 3)
            out["flow_quality_mean"] = round(statistics.mean(raw["q"]), 1)
    return out


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--adapter", required=True, help="CP2102 port to the TX (CRSF)")
    ap.add_argument("--duration", type=float, default=60.0)
    ap.add_argument("--hz", type=float, default=2.0, help="print rate")
    a = ap.parse_args(argv)
    for k, v in run(a.adapter, a.duration, a.hz).items():
        print(f"{k}: {v}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
