"""Fly page ('Mission control' look): SceneView with the flight-view PiP, mission timeline above the height plot on one time axis, and a 376 px right column
(hold-to-ARM then TAKE OFF, DISARM / LAND with disabled reasons, target height, pre-flight list), bottom strip of readouts.
The page flies ONLY through win.model.core.director; no dialogs: results go to the inline status line and to toasts (DISARM / LAND carry an Undo)."""
from __future__ import annotations

import math
import time

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QHBoxLayout, QLabel, QVBoxLayout, QWidget

from . import theme as T
from .components import ActionButton, Card, HoldButton, StepField
from .components.hold_button import default_hold_ms
from .viz.bottom_strip import BottomStrip
from .viz.flight_view_mini import FlightViewMini
from .viz.height_plot import HeightPlot
from .viz.mission_timeline import MissionTimeline
from .viz.preflight_list import PreflightList
from .viz.scene_view import SceneView

ARM_PHASES = ("ready", "landed")
TAKEOFF_PHASES = ("ready", "landed", "armed")
LAND_PHASES = ("arming", "armed", "takeoff", "climbing", "holding")
FLYING_PHASES = ("takeoff", "climbing", "holding", "landing")


def check_mark(ok: bool, blocking: bool) -> tuple[str, str]:
    """(glyph, level) of a pre-flight row; the glyph differs per state so it reads without colour."""
    if ok:
        return "✔", "ok"
    return ("✖", "blocking") if blocking else ("⚠", "caution")


def first_blocker(checks) -> str:
    for c in checks:
        if not c.ok and c.blocking:
            return f"{c.label}: {c.detail}" if c.detail else c.label
    return ""


def disabled_reason(phase: str, checks) -> str:
    """Why ARM / TAKE OFF cannot be used (or will be refused) right now; '' when nothing stops them."""
    if phase == "disconnected":
        return "Not connected: connect the radio (or Sim) first."
    if phase == "fault":
        return "Safety fault latched: press SAFE, then reconnect."
    if phase not in TAKEOFF_PHASES:
        return {"arming": "Arming: gyro calibration, keep the drone still.", "landing": "Landing in progress."}.get(phase, f"Flying ({phase}): LAND or SAFE to end the flight.")
    b = first_blocker(checks)
    return f"ARM / TAKE OFF will be refused: {b}" if b else ""


# fallback when a check carries no goto: check id -> (workspace, sub-tab)
FIX_TARGETS = {"rest_tilt": ("SETUP", "Calibration"), "range": ("SETUP", "Sensors"), "link": ("SETUP", "Radio"), "telemetry": ("SETUP", "Radio"),
               "battery": ("SETTINGS", "Settings"), "ceiling": ("SETTINGS", "Settings")}


def mmss(sec: float) -> str:
    sec = max(0, int(sec)); return f"{sec // 60}:{sec % 60:02d}"


class FlyPage(QWidget):
    def __init__(self, win) -> None:
        super().__init__()
        self.win = win
        self._sig = None; self._checks: list = []
        self._t0 = time.monotonic(); self._armed_t = None
        self._last_phase = None
        self.setMinimumWidth(1000)
        # --- left: scene (+ PiP), timeline, plot
        self.scene = SceneView(); self.mini = FlightViewMini(); self.scene.set_pip_widget(self.mini)
        self.scene.pip_clicked.connect(lambda: self.win.goto("VIDEO"))
        self.timeline = MissionTimeline(); self.plot = HeightPlot()
        self.timeline.set_margins(*self.plot.plot_margins())
        left = QVBoxLayout(); left.setSpacing(16); left.setContentsMargins(0, 0, 0, 0)
        left.addWidget(self.scene, 5)
        tl = QVBoxLayout(); tl.setSpacing(0); tl.setContentsMargins(24, 0, 24, 0)
        tl.addWidget(self.timeline); tl.addWidget(self.plot, 1)
        left.addLayout(tl, 4)
        # --- right column
        self.btn_main = HoldButton("ARM", "", "drone"); self.btn_main.setFixedHeight(96)
        self.btn_disarm = ActionButton("DISARM", "unlock", "Available once armed")
        self.btn_land = ActionButton("LAND", "download", "Available in flight")
        row = QHBoxLayout(); row.setSpacing(8); row.setContentsMargins(0, 0, 0, 0); row.addWidget(self.btn_disarm); row.addWidget(self.btn_land)
        st0 = win.model.core.autonomy.settings
        self.height_field = StepField(min(st0.hover_height, st0.ceiling_m), 0.05, 0.25, max(0.25, st0.ceiling_m))
        self.height_card = Card("Target height"); self.height_card.body.addWidget(self.height_field)
        self.why = QLabel(""); self.why.setWordWrap(True); self.why.setStyleSheet(f"color:{T.DIM}"); self.why.setFont(T.f_body(12))
        self.status = QLabel("Ready.", self); self.status.setVisible(False); self.status.setWordWrap(True); self.status.setFont(T.f_body(12)); self.status.setStyleSheet(f"color:{T.TXT}")
        self.preflight = PreflightList()
        side = QWidget(); side.setFixedWidth(T.RIGHT_COL_W)
        sl = QVBoxLayout(side); sl.setContentsMargins(0, 0, 0, 0); sl.setSpacing(12)
        sl.addWidget(self.btn_main); sl.addLayout(row); sl.addWidget(self.why); sl.addWidget(self.height_card); sl.addWidget(self.preflight); sl.addStretch(1)
        self.strip = BottomStrip()
        body = QHBoxLayout(); body.setContentsMargins(24, 16, 24, 16); body.setSpacing(24); body.addLayout(left, 1); body.addWidget(side, 0, Qt.AlignmentFlag.AlignTop)
        root = QVBoxLayout(self); root.setContentsMargins(0, 0, 0, 0); root.setSpacing(0); root.addLayout(body, 1); root.addWidget(self.strip)
        # --- wiring
        self.btn_main.activated.connect(self.on_main)
        self.btn_disarm.clicked.connect(self.do_disarm)
        self.btn_land.clicked.connect(self.do_land)
        self.height_field.valueChanged.connect(self.on_height)
        self.preflight.row_clicked.connect(self._row_clicked)

    @property
    def director(self):
        return self.win.model.core.director

    @property
    def sp_height(self):                        # old name of the target-height field
        return self.height_field

    # --- inline status + toasts ----------------------------------------------------------------
    def say(self, res, warn: bool = False, undo=None) -> None:
        self.status.setText(res.message)
        if hasattr(self.win, "say"):
            self.win.say(res.message, "ok" if res.ok and not warn else "warn" if res.ok else "err")
        toasts = getattr(self.win, "toasts", None)
        if toasts is not None and (undo is not None or not res.ok):
            toasts.show_toast(res.message, undo if res.ok else None)

    # --- commands -----------------------------------------------------------------------------
    def on_main(self) -> None:
        ph = self.director.state().phase
        if ph == "armed":
            self.say(self.director.takeoff(self.height_field.value()))
        elif ph in ARM_PHASES:
            self.say(self.director.arm())
        else:
            self.say(self.director.arm())                       # refused by the director with its own message

    def do_disarm(self) -> None:
        res = self.director.disarm()
        self.say(res, undo=None)

    def do_land(self) -> None:
        res = self.director.land()
        self.say(res, undo=None)

    def on_height(self, v: float) -> None:
        """In flight: hold the new height now. On the ground: only the take-off height (not saved)."""
        if self.director.state().phase in ("takeoff", "climbing", "holding"):
            res = self.director.set_height(v)
            self.say(res)
            if not res.ok:
                self.height_field.set_value(self.director.state().target_m)

    def _row_clicked(self, rid: str) -> None:
        c = next((c for c in self._checks if c.id == rid), None)
        if c is None or c.ok:
            return
        tgt = c.goto or FIX_TARGETS.get(rid)
        if tgt:
            self.win.goto(*tgt)
        elif c.fix_hint:
            self.win.say(c.fix_hint, "warn")

    # --- refresh (10 Hz, called by the window) ------------------------------------------------
    def refresh(self, s: dict) -> None:
        m, d = self.win.model, self.director
        st = d.state(); checks = d.preflight(); self._checks = list(checks)
        ph = st.phase; live = s["connected"]
        ceiling = m.core.autonomy.settings.ceiling_m
        if abs(self.height_field._max - max(0.25, ceiling)) > 1e-9:
            self.height_field.set_range(0.25, max(0.25, ceiling))
        # controls: ARM (hold) then TAKE OFF; DISARM / LAND with reasons
        why = disabled_reason(ph, checks)
        self.btn_main.set_label("TAKE OFF" if ph == "armed" else "ARM")
        if ph == "armed":
            self.btn_main.set_enabled_with_reason(True); self.btn_main.set_hint(f"PRESS AND HOLD {default_hold_ms() / 1000:.1f} s"); why = ""
        elif ph in ARM_PHASES and not why:
            self.btn_main.set_enabled_with_reason(True); self.btn_main.set_hint(f"PRESS AND HOLD {default_hold_ms() / 1000:.1f} s")
        else:
            self.btn_main.set_enabled_with_reason(False, why or "Not available")
        self.why.setText(why); self.why.setVisible(bool(why))
        self.btn_disarm.set_enabled_with_reason(ph == "armed", "" if ph == "armed" else "Not connected" if ph == "disconnected" else "Available once armed")
        self.btn_land.set_enabled_with_reason(ph in LAND_PHASES, "" if ph in LAND_PHASES else "Not connected" if ph == "disconnected" else "Available in flight")
        self.height_field.set_enabled_state(ph != "disconnected" and ph != "fault")
        # pre-flight
        sig = tuple((c.id, c.ok, c.blocking, c.detail) for c in checks)
        if sig != self._sig:
            self._sig = sig
            rows = []
            for c in checks:
                _g, level = check_mark(c.ok, c.blocking)
                state = "ready" if c.ok else (c.detail or "check")
                rows.append((c.id, c.label, state, level))
            self.preflight.set_checks(rows)
        # readouts
        dec = m.state.decoded
        o, k, a = dec.get("optrange"), dec.get("kinematic"), dec.get("attitude")
        z = st.height_m if st.height_m is not None else (k["z_m"] if (k and k.get("valid")) else None)
        z = z if (live and z is not None) else None
        vz = k["vz_mps"] if (k and k.get("valid") and live) else 0.0
        spd = math.hypot(k["vx_mps"], k["vy_mps"]) if (k and k.get("valid") and live) else None
        rng = o["distance_m"] if (o and live) else None
        hdg = math.degrees(a["yaw_rad"]) if (a and live) else 0.0
        self.scene.set_values(z or 0.0, hdg, vz)
        flying = ph in FLYING_PHASES
        self.mini.set_height(z or 0.0); self.mini.set_target(st.target_m if flying else None); self.mini.set_range(max(0.75, ceiling))
        mp = st.mission_phase
        self.timeline.set_phase(mp); self.timeline.set_phase_elapsed(st.phase_elapsed_s)
        if live:
            self.plot.push(time.monotonic() - self._t0, st.target_m if flying else 0.0, z, rng)
        if ph == "armed" or flying:
            self._armed_t = self._armed_t or time.monotonic()
        elif ph in ("ready", "landed", "disconnected"):
            self._armed_t = None
        pct, v = s["battery_pct"], s["battery_v"]
        batt_caution = any(c.id == "battery" and not c.ok for c in checks) or (pct is not None and pct < 30)
        f = lambda x, spec: "—" if x is None else format(x, spec)
        self.strip.set_values({"HEIGHT": f(z, ".2f"), "SPEED": f(spd, ".2f"), "RANGE": f(rng, ".2f"), "FLOW Q": f(o["flow_quality"] if (o and live) else None, "d"),
                               "LQ": f(s["lq"], ".0f"), "RSSI": f(s["rssi"], ".0f"), "BATT": f(v, ".1f"),
                               "ARMED TIME": mmss(time.monotonic() - self._armed_t) if self._armed_t else "0:00"})
        self.strip.set_caution("BATT", bool(batt_caution))
