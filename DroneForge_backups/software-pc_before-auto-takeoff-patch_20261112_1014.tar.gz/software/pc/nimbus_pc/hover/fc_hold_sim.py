"""Host-side stand-in for the FC height hold: the REAL C control law (firmware/fc_matek_h743/source_snapshots/2026-11-09_estimator-gates_v4/height_hold_core.c, compiled with gcc and called through ctypes)
fed by an emulation of the FC's estimator (IMU-aided height filter + 50 Hz range updates). Used by tests and by the sim checks of the FC hold."""
from __future__ import annotations

import ctypes
import os
import random
import subprocess
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
CORE_DIR = os.path.normpath(os.path.join(HERE, "..", "..", "..", "..", "firmware", "fc_matek_h743", "source_snapshots", "2026-11-09_estimator-gates_v4"))


class HhParams(ctypes.Structure):
    _fields_ = [(n, ctypes.c_float) for n in ("kp_z", "kv_z", "ki_z", "i_max", "vz_lim", "climb_peak_frac", "descent_peak_frac", "thr_idle", "thr_max", "drop_max",
                                              "overshoot_m", "overshoot_vz", "overshoot_cut", "height_min", "height_max",
                                              "base_tau", "base_follow_max", "lift_vz", "lift_m", "takeoff_start_frac", "takeoff_creep_per_s", "takeoff_cap_frac", "takeoff_fail_s",
                                              "land_rate", "land_slow_rate", "land_slow_below", "touch_m", "touch_s", "idle_ramp_per_s", "takeoff_ramp_per_s")]


class HhState(ctypes.Structure):
    _fields_ = [("active", ctypes.c_bool), ("z_ref", ctypes.c_float), ("vz_ff", ctypes.c_float), ("integ", ctypes.c_float), ("f_base", ctypes.c_float), ("v0", ctypes.c_float),
                ("target", ctypes.c_float), ("trans", ctypes.c_bool), ("t_start", ctypes.c_float), ("t_dur", ctypes.c_float), ("z_from", ctypes.c_float), ("z_to", ctypes.c_float),
                ("t", ctypes.c_float), ("f_out", ctypes.c_float), ("overshoot", ctypes.c_bool),
                ("mode", ctypes.c_int), ("f_cur", ctypes.c_float), ("t_mode", ctypes.c_float), ("t_cap", ctypes.c_float), ("target_pending", ctypes.c_float),
                ("t_touch", ctypes.c_float), ("fail", ctypes.c_bool), ("landed", ctypes.c_bool),
                ("f_lift", ctypes.c_float), ("lifted", ctypes.c_bool), ("base_learned", ctypes.c_bool), ("f_start", ctypes.c_float)]


def load_core():
    out = os.path.join(tempfile.gettempdir(), "libheighthold_test.so")
    src = os.path.join(CORE_DIR, "height_hold_core.c")
    subprocess.check_call(["gcc", "-O2", "-shared", "-fPIC", "-o", out, src])
    lib = ctypes.CDLL(out)
    lib.hhDefaults.argtypes = [ctypes.POINTER(HhParams)]
    lib.hhEngage.argtypes = [ctypes.POINTER(HhState), ctypes.POINTER(HhParams), ctypes.c_float, ctypes.c_float, ctypes.c_float]
    lib.hhDisengage.argtypes = [ctypes.POINTER(HhState)]
    lib.hhSetTarget.argtypes = [ctypes.POINTER(HhState), ctypes.POINTER(HhParams), ctypes.c_float]
    lib.hhUpdate.argtypes = [ctypes.POINTER(HhState), ctypes.POINTER(HhParams), ctypes.c_float, ctypes.c_float, ctypes.c_float, ctypes.c_float]
    lib.hhUpdate.restype = ctypes.c_float
    lib.hhTakeoffBegin.argtypes = [ctypes.POINTER(HhState), ctypes.POINTER(HhParams), ctypes.c_float, ctypes.c_float, ctypes.c_float]
    lib.hhLand.argtypes = [ctypes.POINTER(HhState), ctypes.POINTER(HhParams)]
    lib.hhFollowBase.argtypes = [ctypes.POINTER(HhState), ctypes.POINTER(HhParams), ctypes.c_float, ctypes.c_float, ctypes.c_float]
    return lib


class FcHoldSim:
    """Emulates: FC estimator (z, vz at the IMU rate, corrected by each range sample) + the 50 Hz hold task + the RC-channel encoding of the target height."""

    def __init__(self, seed: int = 1, rate_hz: float = 50.0, imu_sigma: float = 0.25, imu_bias: float = 0.15, target_us: bool = True) -> None:
        self.lib = load_core()
        self.p = HhParams(); self.lib.hhDefaults(ctypes.byref(self.p))
        self.s = HhState()
        self.rng = random.Random(seed)
        self.period = 1.0 / rate_hz
        self.imu_sigma, self.imu_bias, self.target_us = imu_sigma, imu_bias, target_us
        self.z = 0.0; self.vz = 0.0; self._P = [[0.01, 0.0], [0.0, 0.1]]
        self._last_vz = 0.0; self._next = 0.0
        self.engaged_at = None; self.fault = None
        self.last_height_cmd = None
        self.ground = None                        # range-sensor reading with the drone on the floor (the EKF height includes it)
        self._gnd_n = 0

    # simple 2-state Kalman filter: IMU acceleration predicts, range corrects (the FC EKF does the same with more states)
    def _predict(self, dt: float, a: float) -> None:
        self.z += self.vz * dt + 0.5 * a * dt * dt; self.vz += a * dt
        P = self._P
        P[0][0] += dt * (2 * P[0][1] + dt * P[1][1]) + 1e-6; P[0][1] += dt * P[1][1]; P[1][0] = P[0][1]; P[1][1] += 0.02 * dt

    def _update(self, zm: float, r: float = 0.012 ** 2) -> None:
        P = self._P; S = P[0][0] + r; k0, k1 = P[0][0] / S, P[0][1] / S
        y = zm - self.z; self.z += k0 * y; self.vz += k1 * y
        P00, P01 = P[0][0], P[0][1]
        P[0][0] = (1 - k0) * P00; P[0][1] = (1 - k0) * P01; P[1][0] = P[0][1]; P[1][1] -= k1 * P01

    @staticmethod
    def height_to_us(h: float) -> int:
        """PC side: target height -> RC channel microseconds (the FC decodes it the same way)."""
        return int(round(1150 + h * 320))

    @staticmethod
    def us_to_height(us: int) -> float:
        return (us - 1150) * 2.5 / 800.0

    def step(self, t, dt, sim, samples, ctl, cmd):
        a_true = (sim.vz - self._last_vz) / dt if dt > 0 else 0.0
        self._last_vz = sim.vz
        self._predict(dt, a_true + self.imu_bias + self.rng.gauss(0.0, self.imu_sigma))
        for smp in samples:
            if smp.kind == "optrange":
                self._update(smp.data["distance_m"])
        tgt = ctl.fc_target_height()                                       # what the PC asks for on CH9 in this phase (None = switch off)
        if self.engaged_at is None and self.z < 0.12 and abs(self.vz) < 0.1:      # on the ground: learn the sensor's ground offset (running mean)
            self._gnd_n = min(self._gnd_n + 1, 200); w = 1.0 / self._gnd_n
            self.ground = self.z if self.ground is None else self.ground + w * (self.z - self.ground)
        zr = self.z - (self.ground or 0.0)
        if self.engaged_at is None or not self.s.active:
            if self.engaged_at is not None and tgt is None:
                return None                                                 # PC landing / fallback: the PC throttle takes over
            if tgt is not None and self.engaged_at is None and zr > 0.15 and abs(self.vz) < 0.5 and self.ground is not None:
                self.lib.hhEngage(ctypes.byref(self.s), ctypes.byref(self.p), zr, ctl._thr_hover_now(), sim.batt_v)        # base = the PC hover reference (CH10)
                self.engaged_at = t; self._next = t
                self.last_height_cmd = None
            else:
                return None
        if tgt is None:
            self.lib.hhDisengage(ctypes.byref(self.s)); return None
        if tgt != self.last_height_cmd:
            hh = self.us_to_height(self.height_to_us(tgt)) if self.target_us else tgt
            self.lib.hhSetTarget(ctypes.byref(self.s), ctypes.byref(self.p), hh); self.last_height_cmd = tgt
        if t >= self._next:
            self._next += self.period
            self._thr = self.lib.hhUpdate(ctypes.byref(self.s), ctypes.byref(self.p), self.period, zr, self.vz, sim.batt_v)
        return getattr(self, "_thr", None)
