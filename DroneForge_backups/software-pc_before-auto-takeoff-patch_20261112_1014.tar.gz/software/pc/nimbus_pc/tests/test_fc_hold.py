"""FC-side height hold: the REAL C control law (compiled with gcc) against the flight simulator, plus the RC-channel encoding shared with the firmware."""
import math
import unittest

from nimbus_core import settings as S
from nimbus_pc.hover import runner
from nimbus_pc.hover.controller import HoverConfig
from nimbus_pc.hover.fc_hold_sim import FcHoldSim
from nimbus_pc.mapper import aux5_to_height, height_to_aux5
from nimbus_pc.sender import CRSF_MIN, Controls


def run_case(seed=1, steps=None, land=140, dur=150):
    st = S.load(); st.hover_height = 0.5; st.creep_per_s = 0.012; st.ceiling_m = max(st.ceiling_m, 3.0)      # pinned: the live settings file may hold a slow real-flight creep rate that cannot lift within the sim timeout
    cfg = HoverConfig(); S.apply_to_config(st, cfg)
    p = S.plant_params(st)
    sim = {k: getattr(p, k) for k in ("hover_thr", "thrust_exp", "batt_v0", "batt_sag_per_s", "range_low_bias_m", "ground_range_m")}
    sim.update(optrange_hz=50.0, sensor_delay=(0.01, 0.03))                 # the FC sees the range sensor at 50 Hz with almost no delay
    cfgd = {k: getattr(cfg, k) for k in cfg.__dataclass_fields__}; cfgd.update(sensor_delay_s=0.02, min_rate_hz=4.0)
    runner.SCENARIOS["fch_test"] = ("fch_test", sim, cfgd)
    fh = FcHoldSim(seed=seed)
    r = runner.run("fch_test", duration=dur, land_at=land, seed=seed, height_steps=[list(s) for s in (steps or [])], fc_hold=fh)
    return r, fh


class TestEncoding(unittest.TestCase):
    def test_height_channel_roundtrip_is_within_one_tick(self):
        for h in (0.2, 0.5, 1.0, 1.5, 2.0, 2.5):
            t = height_to_aux5(h)
            self.assertTrue(172 <= t <= 1811)                              # a legal CRSF value
            self.assertAlmostEqual(aux5_to_height(t), h, delta=0.003)
        us = 5 * height_to_aux5(0.5) / 8 + 880
        self.assertGreaterEqual(us, 1150)                                    # always above the FC's "hold at the current height" band
        self.assertEqual(Controls().to_channels(True)[8], CRSF_MIN)           # off by default
        self.assertEqual(Controls(aux5=height_to_aux5(1.0)).to_channels(True)[8], height_to_aux5(1.0))


class TestFcHoldAgainstSimulator(unittest.TestCase):
    def test_fc_takes_over_at_lift_off_and_holds_the_height(self):
        for seed in (1, 2, 3):
            r, fh = run_case(seed=seed, steps=[])
            self.assertIsNotNone(fh.engaged_at)
            th = r.metrics["t_hover_s"]
            self.assertIsNotNone(th); self.assertLess(fh.engaged_at, th - 3.0)               # engaged during the climb, long before the PC reaches HOVER
            rows = [x for x in r.rows if fh.engaged_at - 0.5 <= x["t"] <= fh.engaged_at + 0.5]
            steps = [abs(b["thr"] - a["thr"]) for a, b in zip(rows, rows[1:])]
            self.assertLess(max(steps), 0.12, (seed, "throttle step at the take-over"))   # the PC creeps PAST the hover throttle until it confirms lift-off; the FC starts from the hover reference (same drop the PC makes itself at lift-off)
            hold = [x for x in r.rows if th + 3 <= x["t"] <= 135]
            self.assertLess(max(abs(x["z"] - 0.5) for x in hold), 0.05, seed)
            self.assertFalse(r.metrics["crashed"])

    def test_height_steps_up_to_2_5_m_and_back_are_smooth_and_accurate(self):
        steps = [[24, 1.0], [44, 1.5], [64, 2.0], [84, 2.5], [106, 1.0], [126, 0.5]]
        for seed in (1, 2):
            r, fh = run_case(seed=seed, steps=steps)
            self.assertFalse(r.metrics["crashed"])
            a = 0.5
            for i, (t0, b) in enumerate(steps):
                nxt = steps[i + 1][0] if i + 1 < len(steps) else 140
                seg = [x for x in r.rows if t0 <= x["t"] < nxt]
                over = (max(x["z"] for x in seg) - b) if b > a else (b - min(x["z"] for x in seg))
                tail = max(abs(x["z"] - b) for x in seg if x["t"] > nxt - 5)
                self.assertLess(over, 0.16, (seed, a, b)); self.assertLess(tail, 0.05, (seed, a, b))
                self.assertLess(max(x["tilt_deg"] for x in seg), 3.0)
                a = b


if __name__ == "__main__":
    unittest.main()


class TestFcTakeoffAndLanding(unittest.TestCase):
    """The REAL C core flying the simulator alone: creep take-off -> hold -> land -> touchdown, with no PC controller involved."""

    def fly(self, hover_thr=0.62, ref_err=0.0, target=0.6, seed=1, t_land=80.0, dur=110.0):
        import ctypes, random
        from nimbus_pc.hover.fc_hold_sim import HhParams, HhState, load_core
        from nimbus_pc.hover.sim import DroneSim, SimParams
        lib = load_core(); p = HhParams(); lib.hhDefaults(ctypes.byref(p)); s = HhState()
        sim = DroneSim(SimParams(hover_thr=hover_thr), seed=seed); rng = random.Random(seed)
        dt = 0.02; t = 0.0; thr = 0.0; log = []
        lib.hhTakeoffBegin(ctypes.byref(s), ctypes.byref(p), hover_thr + ref_err, target, sim.batt_v)
        landing = False
        while t < dur:
            if t >= t_land and not landing:
                lib.hhLand(ctypes.byref(s), ctypes.byref(p)); landing = True
            z = max(sim.z, 0.0) + rng.gauss(0, 0.004); vz = sim.vz + rng.gauss(0, 0.03)
            if s.active:
                lib.hhFollowBase(ctypes.byref(s), ctypes.byref(p), dt, hover_thr + ref_err, sim.batt_v)   # the PC keeps sending its (possibly wrong) estimate
                thr = lib.hhUpdate(ctypes.byref(s), ctypes.byref(p), dt, z, vz, sim.batt_v)
                if s.fail or (s.landed and thr <= p.thr_idle + 1e-3):
                    s.active = False; thr = 0.0
            else:
                thr = 0.0
            sim.step(dt, 0.0, 0.0, thr, True); sim.poll(); t += dt
            log.append((t, sim.z, sim.vz, thr, s.mode, bool(s.fail), bool(s.landed)))
        return log, s

    def test_takeoff_holds_target_then_lands_softly(self):
        for ref_err in (0.0, -0.06, 0.06, 0.12):                                         # +0.12 = the 2026-11-06 incident: reference 17 % too high
            log, s = self.fly(ref_err=ref_err)
            lift = next((r[0] for r in log if r[1] > 0.15), None)
            self.assertIsNotNone(lift, f"never lifted (ref_err {ref_err})")
            self.assertLess(lift, 45.0)
            hold = [r[1] for r in log if lift + 14.0 < r[0] < 79.0]
            self.assertAlmostEqual(sum(hold) / len(hold), 0.6, delta=0.06)
            self.assertLess(max(r[1] for r in log), 0.85)                                   # no overshoot
            self.assertLess(max(r[2] for r in log), 0.60, f'climbed too fast (ref_err {ref_err})')   # never the violent climb of the first flight
            self.assertFalse(any(r[5] for r in log))
            thr = [r[3] for r in log if r[0] < lift]                                          # before lift-off the throttle never steps: slew <= 0.4 per second (a step is turned into a full-throttle burst by Betaflight's throttle boost)
            self.assertLess(max(abs(b - a) for a, b in zip(thr, thr[1:])) / 0.02, 0.4, 'throttle stepped')
            self.assertLess(thr[0], 0.10)                                                     # starts at idle
            self.assertLess(abs(log[-1][1]), 0.05)                                          # on the floor at the end
            self.assertTrue(any(r[6] for r in log))                                         # touchdown detected
            self.assertLess(sim_impact(log), 0.55)                                          # touchdown speed (m/s)

    def test_takeoff_that_cannot_lift_ends_in_a_fault_at_the_cap(self):
        log, s = self.fly(hover_thr=0.62, ref_err=-0.20, target=0.6, dur=40.0)               # reference far too low
        # with a true hover of 0.62 and a reference of 0.42 the cap is 0.47: it must not lift, and must report the fault, not creep on
        self.assertTrue(s.fail or any(r[5] for r in log))
        self.assertLess(max(r[3] for r in log), 0.52)


def sim_impact(log):
    """Largest downward speed in the last 0.2 m of the landing (after the land command at t = 80 s)."""
    return max((-r[2] for r in log if r[0] > 80.0 and r[2] < 0 and r[1] < 0.2), default=0.0)
