"""Drone3DView: a quad-X drone drawn with a plain QPainter perspective projection (no extra dependency).

World axes (metres): x right, y forward, z up. The user orbits with the left mouse button (drag), double-click or the right-click action resets the view.
Rotors turn at a rate proportional to the live output, are grey when idle/stale, blue when running; red outline + cross only for a motor the pilot marked NOT turning.
State reads without colour: stale -> the words NO DATA, running -> the output in us, selected -> thick ring plus a bracket mark.
"""
from __future__ import annotations

import math
import time
from typing import List, Optional, Sequence

from PyQt6.QtCore import QPointF, QRectF, Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QAction, QColor, QFont, QPainter, QPen, QPolygonF
from PyQt6.QtWidgets import QSizePolicy, QWidget

from .. import theme

# Betaflight quad-X: motor number -> (right, forward) in units of the arm offset, spin sense (+1 = clockwise seen from above)
MOTOR_POS = {1: (+1.0, -1.0, -1), 2: (+1.0, +1.0, +1), 3: (-1.0, -1.0, +1), 4: (-1.0, +1.0, -1)}
ARM = 0.065            # m, motor offset along x and y
PROP_R = 0.038         # m, 3" prop
MOTOR_Z = 0.012
DEF_YAW, DEF_PITCH, DEF_DIST = math.radians(35.0), math.radians(28.0), 0.50
IDLE_US = 1030


def _rgb(c: str, a: int = 255) -> QColor:
    q = QColor(c); q.setAlpha(a); return q




class Drone3DView(QWidget):
    motor_clicked = pyqtSignal(int)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setMinimumSize(360, 300); self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setMouseTracking(False); self.setCursor(Qt.CursorShape.OpenHandCursor)
        self.outputs: List[int] = [1000] * 4
        self.stale = True
        self.selected = 0
        self.seen: List[Optional[bool]] = [None] * 4
        self.yaw, self.pitch, self.dist = DEF_YAW, DEF_PITCH, DEF_DIST
        self._ang = [0.0] * 4
        self._t = time.monotonic()
        self._press: Optional[QPointF] = None; self._last: Optional[QPointF] = None; self._moved = 0.0
        self._hit: dict = {}
        act = QAction("Reset view", self); act.triggered.connect(self.reset_view)
        self.addAction(act); self.setContextMenuPolicy(Qt.ContextMenuPolicy.ActionsContextMenu)
        self._timer = QTimer(self); self._timer.setInterval(33); self._timer.timeout.connect(self._tick); self._timer.start()

    # ---- API -----------------------------------------------------------------------------
    def set_outputs(self, outputs: Optional[Sequence[int]], stale: bool = False) -> None:
        if outputs is None:
            self.stale = True
        else:
            self.outputs = [int(o) for o in outputs]; self.stale = bool(stale)
        self.update()

    def set_selected(self, n: int) -> None:
        self.selected = int(n); self.update()

    def set_seen(self, seen: Sequence[Optional[bool]]) -> None:
        self.seen = list(seen); self.update()

    def reset_view(self) -> None:
        self.yaw, self.pitch, self.dist = DEF_YAW, DEF_PITCH, DEF_DIST; self.update()

    def running(self) -> bool:
        return (not self.stale) and max(self.outputs) > IDLE_US

    # ---- animation ----------------------------------------------------------------------
    def _tick(self) -> None:
        now = time.monotonic(); dt = min(0.2, now - self._t); self._t = now
        if self.isVisible():
            for i, o in enumerate(self.outputs):
                if not self.stale and o > IDLE_US:
                    self._ang[i] = (self._ang[i] + (o - 1000) * 1.5 * dt) % 360.0          # visual only: faster = higher output
            self.update()

    # ---- projection ---------------------------------------------------------------------
    def _cam(self, p):
        x, y, z = p
        cy, sy = math.cos(self.yaw), math.sin(self.yaw)
        x, y = x * cy - y * sy, x * sy + y * cy                                           # yaw about z
        cp, sp = math.cos(self.pitch), math.sin(self.pitch)
        y, z = y * cp - z * sp, y * sp + z * cp                                           # pitch about x: y becomes depth (away from viewer)
        return x, y, z

    def _proj(self, p):
        x, d, z = self._cam(p)
        depth = self.dist + d
        f = min(self.width(), self.height() * 1.25) * 1.5
        k = f / max(0.05, depth)
        return QPointF(self.width() / 2 + x * k, self.height() * 0.56 - z * k), depth

    def _poly(self, pts):
        return QPolygonF([self._proj(p)[0] for p in pts])

    def _colour(self, i: int) -> QColor:
        o = self.outputs[i]
        if self.seen[i] is False:
            return _rgb(theme.RED)
        if self.stale or o <= IDLE_US:
            return _rgb(theme.DIM)
        return _rgb(theme.ACC)

    # ---- painting -----------------------------------------------------------------------
    def _box(self, p: QPainter, c, s, fill: str, edge: str) -> float:
        cx, cy, cz = c; sx, sy, sz = s[0] / 2, s[1] / 2, s[2] / 2
        v = [(cx + a * sx, cy + b * sy, cz + d * sz) for a in (-1, 1) for b in (-1, 1) for d in (-1, 1)]
        faces = [(0, 1, 3, 2), (4, 5, 7, 6), (0, 1, 5, 4), (2, 3, 7, 6), (0, 2, 6, 4), (1, 3, 7, 5)]
        order = sorted(faces, key=lambda f: -sum(self._proj(v[i])[1] for i in f))
        for n, f in enumerate(order):
            shade = 100 + 8 * n
            p.setBrush(_rgb(fill).lighter(shade)); p.setPen(QPen(_rgb(edge), 1))
            p.drawPolygon(self._poly([v[i] for i in f]))
        return self._proj(c)[1]

    def paintEvent(self, _ev) -> None:
        p = QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing); p.setRenderHint(QPainter.RenderHint.TextAntialiasing)
        w, h = self.width(), self.height()
        p.fillRect(0, 0, w, h, _rgb(theme.PANEL))
        # ground grid (0.05 m squares) and the shadow
        p.setPen(QPen(_rgb(theme.HAIR2), 1)); half = 0.25
        for k in range(-5, 6):
            g = k * 0.05
            p.drawLine(self._proj((g, -half, 0))[0], self._proj((g, half, 0))[0]); p.drawLine(self._proj((-half, g, 0))[0], self._proj((half, g, 0))[0])
        p.setPen(Qt.PenStyle.NoPen); p.setBrush(_rgb("#000000", 110))
        p.drawPolygon(QPolygonF([self._proj((ARM * 1.7 * math.cos(a) * 1.0, ARM * 1.7 * math.sin(a), 0))[0] for a in [i * math.pi / 12 for i in range(24)]]))
        items = []                                                                        # (depth, draw function) painter's algorithm
        # arms
        for n, (mx, my, _s) in MOTOR_POS.items():
            a, b = (0, 0, MOTOR_Z - 0.004), (mx * ARM, my * ARM, MOTOR_Z - 0.004)
            items.append((self._proj(((a[0] + b[0]) / 2, (a[1] + b[1]) / 2, a[2]))[1] + 0.001, lambda a=a, b=b: (p.setPen(QPen(_rgb("#4a515b"), 5, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap)), p.drawLine(self._proj(a)[0], self._proj(b)[0]))))
        items.append((self._proj((0, 0, 0.014))[1], lambda: self._box(p, (0, 0, 0.014), (0.05, 0.085, 0.018), "#2d3138", "#555c67")))                 # body
        items.append((self._proj((0, -0.005, 0.0))[1] + 0.012, lambda: self._box(p, (0, -0.005, 0.0), (0.034, 0.06, 0.016), "#3a3f47", "#6b727d")))      # battery below
        items.append((self._proj((0, 0.05, 0.016))[1] - 0.02, lambda: self._box(p, (0, 0.05, 0.016), (0.026, 0.018, 0.02), "#1b1e23", theme.ACC)))      # camera at the front
        for i, n in enumerate(MOTOR_POS):
            items.append((self._proj((MOTOR_POS[n][0] * ARM, MOTOR_POS[n][1] * ARM, MOTOR_Z))[1] - 0.03, lambda i=i, n=n: self._rotor(p, i, n)))
        for _d, fn in sorted(items, key=lambda t: -t[0]):
            fn()
        # captions
        p.setPen(_rgb(theme.DIM)); p.setFont(QFont("Lato", 9))
        fp = self._proj((0, 0.115, 0.0))[0]; p.drawText(QRectF(fp.x() - 40, fp.y() - 8, 80, 16), Qt.AlignmentFlag.AlignCenter, "FRONT")
        p.drawText(QRectF(12, h - 24, w - 24, 16), Qt.AlignmentFlag.AlignLeft, "Drag to orbit, double-click to reset view")
        if self.stale:
            p.setPen(_rgb(theme.TXT)); p.setFont(QFont("Lato", 11, QFont.Weight.DemiBold))
            p.drawText(QRectF(0, 10, w, 22), Qt.AlignmentFlag.AlignCenter, "NO DATA  (motor outputs not received)")
        p.end()

    def _rotor(self, p: QPainter, i: int, n: int) -> None:
        mx, my, sense = MOTOR_POS[n]
        c = (mx * ARM, my * ARM, MOTOR_Z); col = self._colour(i); sel = (n == self.selected)
        ctr, _d = self._proj(c)
        circ = lambda r, a0=0.0, z=0.0: [(c[0] + r * math.cos(a0 + t * math.pi / 14), c[1] + r * math.sin(a0 + t * math.pi / 14), c[2] + z) for t in range(28)]
        p.setBrush(_rgb("#2d3138")); p.setPen(Qt.PenStyle.NoPen); p.drawPolygon(self._poly(circ(0.008, 0, -0.004)))                                   # motor bell
        fill = QColor(col); fill.setAlpha(60 if (self.running() and self.outputs[i] > IDLE_US) else 30)
        p.setBrush(fill); p.setPen(QPen(col, 3 if sel else 1.5)); p.drawPolygon(self._poly(circ(PROP_R)))
        p.setPen(QPen(col, 2.2))
        for k in (0, 90):
            a = math.radians(self._ang[i] * -sense + k)
            p.drawLine(self._proj((c[0] - PROP_R * math.cos(a), c[1] - PROP_R * math.sin(a), c[2]))[0], self._proj((c[0] + PROP_R * math.cos(a), c[1] + PROP_R * math.sin(a), c[2]))[0])
        if sel:                                                                           # selected without colour: a second outer dashed ring
            pen = QPen(_rgb(theme.TXT), 1.5); pen.setStyle(Qt.PenStyle.DashLine); p.setPen(pen); p.setBrush(Qt.BrushStyle.NoBrush); p.drawPolygon(self._poly(circ(PROP_R + 0.008)))
        # spin arrow: an arc just outside the prop with a head (clockwise = sense +1, seen from above)
        arc = [self._proj((c[0] + (PROP_R + 0.004) * math.cos(a), c[1] + (PROP_R + 0.004) * math.sin(a), c[2]))[0] for a in
               [math.radians(200 + sense * -1 * t * 8) for t in range(0, 9)]]
        p.setPen(QPen(_rgb(theme.DIM), 1.5)); p.setBrush(Qt.BrushStyle.NoBrush)
        for a0, a1 in zip(arc, arc[1:]):
            p.drawLine(a0, a1)
        tip, prev = arc[-1], arc[-2]; ang = math.atan2(tip.y() - prev.y(), tip.x() - prev.x())
        p.setBrush(_rgb(theme.DIM)); p.drawPolygon(QPolygonF([tip, QPointF(tip.x() - 7 * math.cos(ang - 0.5), tip.y() - 7 * math.sin(ang - 0.5)), QPointF(tip.x() - 7 * math.cos(ang + 0.5), tip.y() - 7 * math.sin(ang + 0.5))]))
        if self.seen[i] is False:
            p.setPen(QPen(_rgb(theme.RED), 3)); p.drawLine(QPointF(ctr.x() - 12, ctr.y() - 12), QPointF(ctr.x() + 12, ctr.y() + 12)); p.drawLine(QPointF(ctr.x() - 12, ctr.y() + 12), QPointF(ctr.x() + 12, ctr.y() - 12))
        # label above the rotor
        body = self._proj((0, 0, 0.0))[0]; rr = abs(self._proj((c[0] + PROP_R, c[1], c[2]))[0].x() - ctr.x())
        vx, vy = ctr.x() - body.x(), ctr.y() - body.y(); vn = max(1.0, math.hypot(vx, vy))
        lp = QPointF(ctr.x() + vx / vn * (rr + 52), ctr.y() + vy / vn * (rr * 0.55 + 34) + 14)      # outside the prop, away from the body, never over it
        p.setPen(_rgb(theme.ACC if sel else theme.TXT)); p.setFont(QFont("Lato", 11, QFont.Weight.Bold))
        p.drawText(QRectF(lp.x() - 40, lp.y() - 18, 80, 16), Qt.AlignmentFlag.AlignCenter, f"M{n}" + (" ◄" if sel else ""))
        p.setPen(_rgb(theme.DIM)); p.setFont(QFont("Noto Sans Mono", 8))
        p.drawText(QRectF(lp.x() - 50, lp.y() - 3, 100, 14), Qt.AlignmentFlag.AlignCenter, ("--" if self.stale else f"{self.outputs[i]} us") + ("  CW" if sense > 0 else "  CCW"))
        r = abs(self._proj((c[0] + PROP_R, c[1], c[2]))[0].x() - ctr.x()) * 1.2 + 6
        self._hit[n] = (ctr, r)

    # ---- mouse --------------------------------------------------------------------------
    def mousePressEvent(self, e) -> None:
        if e.button() == Qt.MouseButton.LeftButton:
            self._press = self._last = e.position(); self._moved = 0.0; self.setCursor(Qt.CursorShape.ClosedHandCursor)

    def mouseMoveEvent(self, e) -> None:
        if self._last is not None:
            d = e.position() - self._last; self._last = e.position(); self._moved += abs(d.x()) + abs(d.y())
            self.yaw -= d.x() * 0.01; self.pitch = min(1.45, max(0.08, self.pitch + d.y() * 0.01)); self.update()

    def mouseReleaseEvent(self, e) -> None:
        if e.button() == Qt.MouseButton.LeftButton and self._press is not None:
            if self._moved < 4.0:
                self.click_at(e.position())
            self._press = self._last = None; self.setCursor(Qt.CursorShape.OpenHandCursor)

    def mouseDoubleClickEvent(self, e) -> None:
        self.reset_view()

    def wheelEvent(self, e) -> None:
        self.dist = min(1.4, max(0.3, self.dist * (0.9 if e.angleDelta().y() > 0 else 1.1))); self.update()

    def click_at(self, pos: QPointF) -> None:
        best, bd = 0, 1e9
        for n, (c, r) in self._hit.items():
            d = math.hypot(pos.x() - c.x(), pos.y() - c.y())
            if d <= r and d < bd:
                best, bd = n, d
        if best:
            self.motor_clicked.emit(best)
