"""BottomStrip: eight tabular readouts separated by hairlines."""
from __future__ import annotations

from PyQt6.QtCore import QRectF, QSize
from PyQt6.QtWidgets import QWidget

from .. import theme as T
from . import col, draw_text, hline, icon_tri, new_painter, text_w, vline

CELLS = [("HEIGHT", "m"), ("SPEED", "m/s"), ("RANGE", "m"), ("FLOW Q", "/255"), ("LQ", "%"), ("RSSI", "dBm"), ("BATT", "V"), ("MODE", ""), ("ARMED TIME", "")]


class BottomStrip(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        T.load_fonts()
        self._v = {n: "—" for n, _ in CELLS}; self._caution: set[str] = set()
        self.setMinimumHeight(T.BOTTOM_STRIP_H)

    def set_values(self, d: dict) -> None:
        for k, v in d.items():
            k = str(k).upper()
            if k in self._v:
                self._v[k] = str(v)
        self.update()

    def set_caution(self, name: str, on: bool = True) -> None:
        (self._caution.add if on else self._caution.discard)(name.upper()); self.update()

    def sizeHint(self) -> QSize:
        return QSize(1920, T.BOTTOM_STRIP_H)

    def paintEvent(self, _):
        p = new_painter(self); W, H = self.width(), self.height()
        p.fillRect(QRectF(0, 0, W, H), col("#0B0C0F")); hline(p, 0, W, 0, T.HAIR)
        cw = (W - 48) / len(CELLS); base = (H - 80) / 2 if H > 80 else 0
        uf = T.f_body(11)
        for i, (name, unit) in enumerate(CELLS):
            x = 24 + i * cw; v = self._v[name]; caut = name in self._caution
            if i:
                vline(p, x - 16, base + 20, H - 20 - base, T.HAIR)
            draw_text(p, x, base + 32, name, T.f_label(10), T.DIM if caut else T.FAINT)
            dim = v in ("0:00", "—")
            vc = T.AMB if caut else (T.DIM if dim else T.TXT)
            wv = draw_text(p, x, base + 60, v, T.f_mono(18), vc)
            xe = x + wv
            if unit and v != "—":
                xe += 6; xe += draw_text(p, xe, base + 60, unit, uf, T.FAINT)
            if caut:
                icon_tri(p, xe + 14, base + 54, T.AMB)
        p.end()
