"""FlightViewMini: side view of the drone on a height scale."""
from __future__ import annotations

from PyQt6.QtCore import QPointF, QRectF, QSize, Qt
from PyQt6.QtGui import QLinearGradient, QPainterPath, QPen
from PyQt6.QtWidgets import QWidget

from .. import theme as T
from . import col, draw_text, hline, _pen, new_painter
from .height_plot import nice_ticks


def draw_drone_side(p, cx: float, cy: float, k: float = 1.0) -> None:
    """Drone silhouette (cy = body centre), scale k. Built from QPainterPath."""
    p.save(); p.translate(cx, cy); p.scale(k, k)
    body = QPainterPath(); body.addRoundedRect(QRectF(-20, -5, 40, 10), 4, 4)
    g = QLinearGradient(0, -5, 0, 5); g.setColorAt(0, col("#E6EAEE")); g.setColorAt(1, col("#9AA2AD")); p.fillPath(body, g)
    can = QPainterPath(); can.moveTo(-9, -5); can.cubicTo(-6, -12, 6, -12, 9, -5); can.closeSubpath(); p.fillPath(can, col("#C3CAD3"))
    p.setBrush(Qt.BrushStyle.NoBrush)
    p.setPen(_pen("#AEB6C1", 1.5))
    for s in (-1, 1):
        p.drawLine(QPointF(20 * s, -3), QPointF(34 * s, -8))
        p.drawLine(QPointF(12 * s, 5), QPointF(16 * s, 14)); p.drawLine(QPointF(12 * s, 14), QPointF(20 * s, 14))
    p.setPen(_pen("#7D8591", 1.5))
    p.drawLine(QPointF(-46, -9), QPointF(-22, -9)); p.drawLine(QPointF(22, -9), QPointF(46, -9))
    p.restore()


class FlightViewMini(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        T.load_fonts()
        self._h = 0.0; self._t = None; self._max = 0.75
        self.setMinimumSize(200, 140)

    def set_height(self, h: float) -> None:
        self._h = max(0.0, float(h)); self.update()

    def set_target(self, t) -> None:
        self._t = None if t is None else float(t); self.update()

    def set_range(self, max_m: float) -> None:
        self._max = max(0.1, float(max_m)); self.update()

    def sizeHint(self) -> QSize:
        return QSize(310, 207)

    def paintEvent(self, _):
        p = new_painter(self); W, H = self.width(), self.height()
        r = QRectF(0, 0, W, H); path = QPainterPath(); path.addRoundedRect(r.adjusted(.5, .5, -.5, -.5), 8, 8)
        p.fillPath(path, col(T.BG, 230)); p.setClipPath(path)
        draw_text(p, 16, 24, "FLIGHT VIEW", T.f_label(10), T.DIM)
        draw_text(p, W - 16, 24, "SIDE", T.f_label(10), T.FAINT, "r")
        gy = H - 32.0; top = 44.0; vmax = max(self._max, self._h, self._t or 0)
        ticks, _ = nice_ticks(vmax, 3); vmax = ticks[-1]
        sc = (gy - top) / vmax; sx = W - 56.0
        p.fillRect(QRectF(round(sx), top, 1, gy - top), col(T.HAIR2))
        for v in ticks:
            yy = round(gy - v * sc)
            p.fillRect(QRectF(sx - 5, yy, 5, 1), col(T.DIM if v else T.HAIR2))
            draw_text(p, sx + 10, yy + 4, f"{v:.2f}", T.f_mono(10), T.FAINT)
        hline(p, 16, sx, round(gy), T.HAIR2)
        gg = QLinearGradient(0, gy, 0, H); gg.setColorAt(0, col("#FFFFFF", 8)); gg.setColorAt(1, col("#FFFFFF", 0))
        p.fillRect(QRectF(0, gy + 1, W, H - gy), gg)
        if self._t is not None:
            ty = round(gy - self._t * sc) + .5
            q = QPen(col("#FFFFFF", 70), 1); q.setStyle(Qt.PenStyle.CustomDashLine); q.setDashPattern([2, 4]); p.setPen(q)
            p.drawLine(QPointF(16, ty), QPointF(sx, ty))
            draw_text(p, 16, ty - 5, f"TARGET {self._t:.2f} m", T.f_label(9), T.FAINT)
        k = max(0.7, min(1.4, W / 310.0))
        dx = 16 + (sx - 16) / 2; dy = max(top + 12 * k, gy - self._h * sc - 14 * k)
        # drone sits on its landing legs: body centre is 14k above the height reading
        p.setPen(QPen(col(T.ACC), 1)); p.drawLine(QPointF(round(dx) + .5, dy + 16 * k), QPointF(round(dx) + .5, gy))
        draw_drone_side(p, dx, dy, k)
        draw_text(p, dx + 10, gy - 8, f"{self._h:.2f} m", T.f_mono(11), T.ACC)
        p.setClipping(False)
        p.setPen(QPen(col("#FFFFFF", 30), 1)); p.setBrush(Qt.BrushStyle.NoBrush); p.drawPath(path)
        p.end()
