"""MissionTimeline: horizontal phase rail, nodes at their expected start times."""
from __future__ import annotations

from PyQt6.QtCore import QPointF, QRectF, QSize, Qt
from PyQt6.QtGui import QColor, QPainter, QPen, QRadialGradient
from PyQt6.QtWidgets import QWidget

from .. import theme as T
from . import col, draw_text, fmt_mmss, hline, new_painter, text_w

PHASES = ["safe", "ready", "armed", "takeoff", "climb", "hold", "land"]
LABELS = {"safe": "SAFE", "ready": "READY", "armed": "ARMED", "takeoff": "TAKE-OFF", "climb": "CLIMB", "hold": "HOLD", "land": "LAND"}
DEFAULT_EXPECTED = {"safe": 15.0, "ready": 15.0, "armed": 10.0, "takeoff": 10.0, "climb": 15.0, "hold": 30.0, "land": 15.0}


class MissionTimeline(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        T.load_fonts()
        self._phase = "ready"; self._elapsed = 0.0
        self._expected = dict(DEFAULT_EXPECTED)
        self._ml, self._mr = 72, 24
        self.setMinimumHeight(120)

    # ---- API
    def set_phase(self, name: str) -> None:
        name = str(name).lower().replace("-", "").replace("_", "")
        if name in PHASES and name != self._phase:
            self._phase = name; self.update()

    def phase(self) -> str:
        return self._phase

    def set_phase_elapsed(self, seconds: float) -> None:
        self._elapsed = max(0.0, float(seconds)); self.update()

    def set_expected(self, d: dict) -> None:
        for k, v in d.items():
            k = str(k).lower().replace("-", "").replace("_", "")
            if k in PHASES and v and v > 0:
                self._expected[k] = float(v)
        self.update()

    def set_margins(self, left: int, right: int) -> None:
        """Left/right plot margins (take HeightPlot.plot_margins()) so node x positions equal the plot's x axis."""
        self._ml, self._mr = int(left), int(right); self.update()

    def total_seconds(self) -> float:
        return sum(self._expected[k] for k in PHASES)

    def start_time(self, name: str) -> float:
        return sum(self._expected[k] for k in PHASES[:PHASES.index(name)])

    def node_x(self, name: str) -> float:
        total = self.total_seconds(); w = self.width() - self._ml - self._mr
        return self._ml + self.start_time(name) / total * w

    def sizeHint(self) -> QSize:
        return QSize(900, 124)

    # ---- paint
    def paintEvent(self, _):
        p = new_painter(self); w = self.width()
        cur = PHASES.index(self._phase)
        draw_text(p, 24, 16, "MISSION TIMELINE", T.f_label(11), T.DIM)
        el = f"{fmt_mmss(self._elapsed)} in phase"; f = T.f_mono(12)
        draw_text(p, w - self._mr, 16, el, f, T.DIM, "r")
        draw_text(p, w - self._mr - text_w(el, f) - 16, 16, LABELS[self._phase], T.f_label(11), T.ACC, "r")
        ry = 76.0
        x0, x1 = self._ml, w - self._mr
        hline(p, x0, x1, ry, T.HAIR2)
        xs = [self.node_x(k) for k in PHASES]
        # progress: through passed phases, plus elapsed inside the current phase
        frac = min(1.0, self._elapsed / self._expected[self._phase])
        xe = xs[cur] + frac * ((xs[cur + 1] if cur + 1 < len(xs) else x1) - xs[cur])
        p.fillRect(QRectF(round(x0), round(ry), round(xe) - round(x0), 1), col(T.ACC))
        for i, k in enumerate(PHASES):
            xn = round(xs[i]) + .5; c = i == cur; past = i < cur
            lf = T.f_label(11)
            if c:
                lf.setWeight(lf.Weight.Black)
            draw_text(p, xn, ry - 20, LABELS[k], lf, T.ACC if c else (T.TXT if past else T.DIM), "c")
            dur = "—" if k == "safe" else fmt_mmss(self._expected[k])
            draw_text(p, xn, ry + 28, dur, T.f_mono(11), T.TXT if c else T.FAINT, "c")
            if c:
                g = QRadialGradient(QPointF(xn, ry + .5), 18); g.setColorAt(0, col(T.ACC, 70)); g.setColorAt(1, col(T.ACC, 0))
                p.fillRect(QRectF(xn - 18, ry - 18, 36, 36), g)
                p.setBrush(col(T.BG)); p.setPen(QPen(col(T.ACC), 2)); p.drawEllipse(QPointF(xn, ry + .5), 6, 6)
                p.setPen(Qt.PenStyle.NoPen); p.setBrush(col(T.ACC)); p.drawEllipse(QPointF(xn, ry + .5), 2.5, 2.5)
            elif past:
                p.setPen(Qt.PenStyle.NoPen); p.setBrush(col(T.DIM)); p.drawEllipse(QPointF(xn, ry + .5), 4, 4)
            else:
                p.setBrush(col(T.BG)); p.setPen(QPen(col(T.FAINT), 1.5)); p.drawEllipse(QPointF(xn, ry + .5), 4, 4)
        p.setBrush(col(T.BG)); p.setPen(QPen(col(T.FAINT), 1.5)); p.drawEllipse(QPointF(round(x1) + .5, ry + .5), 3, 3)
        p.end()
