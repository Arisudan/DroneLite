import csv
import glob
import os
import tempfile
import time
import unittest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PyQt6.QtWidgets import QApplication, QCheckBox, QMessageBox  # noqa: E402

from nimbus_core import recorder                                # noqa: E402
from nimbus_gcs.main_window import apply_dark                   # noqa: E402
from nimbus_gcs import replay_page as R                         # noqa: E402

_app = QApplication.instance() or QApplication([])
apply_dark(_app)


def _wait(page, pred, s=5.0):
    end = time.time() + s
    while time.time() < end and not pred():
        _app.processEvents(); time.sleep(0.01)


def _write(folder, name, n=50, armed=True):
    p = os.path.join(folder, name + ".csv")
    with open(p, "w", newline="") as f:
        w = csv.DictWriter(f, recorder.FIELDS); w.writeheader()
        for i in range(n):
            w.writerow({"t": i * 0.1, "phase": "hover", "state": "ok", "cmd_arm": 1 if armed else 0, "z_est": i * 0.01, "z_ref": 1.0,
                        "range_m": i * 0.01, "pitch_deg": 1.0, "roll_deg": -3.0, "batt_v": 14.0, "lq": 90, "m1": 1200})
    with open(p[:-4] + ".events.txt", "w") as f: f.write("    0.50s  takeoff\n    2.00s  landed\n")
    with open(p[:-4] + ".summary.txt", "w") as f: f.write("rows: %d\narmed: %s s (commanded)\n" % (n, "4.0" if armed else "0.0"))
    return p


class ReplayTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); os.environ["DRONEFORGE_FLIGHTS"] = self.tmp.name
        self.p1 = _write(self.tmp.name, "2026-11-06_153245_real-fc")
        _write(self.tmp.name, "2026-11-06_160000_simulator", armed=False)
        self.clock = [0.0]; self.page = R.ReplayPage(None, clock=lambda: self.clock[0])

    def tearDown(self):
        os.environ.pop("DRONEFORGE_FLIGHTS", None); self.tmp.cleanup()

    def _load(self, path):
        self.page.open_file(path); _wait(self.page, lambda: self.page.data is not None or "Cannot" in self.page.status.text())

    def test_list_and_filter(self):
        self.assertEqual(self.page.list.count(), 2)
        self.assertIn("simulator", self.page.list.item(0).text())          # newest first
        self.assertIn("not armed", self.page.list.item(0).text())
        self.page.kind.setCurrentText("real-fc"); self.assertEqual(self.page.list.count(), 1)

    def test_load_and_readout(self):
        self._load(self.p1)
        self.assertIsNotNone(self.page.data); self.assertEqual(len(self.page.data["events"]), 2)
        self.assertIn("armed:", self.page.summary.toPlainText())
        self.page.seek(2.0); txt = self.page.now.text()
        self.assertIn("2.00 s", txt); self.assertIn("hover", txt); self.assertIn("0.20 m", txt); self.assertIn("14.00 V", txt)
        self.page.events.setCurrentRow(1); self.assertAlmostEqual(self.page.cur, 2.0)

    def test_playback_fake_clock(self):
        self._load(self.p1); self.page.speed.setCurrentText("2x"); self.page.start()
        self.clock[0] += 0.5; self.page.tick()
        self.assertAlmostEqual(self.page.cur, 1.0, places=3)
        self.page.toggle(); self.assertFalse(self.page.playing)

    def test_garbage_and_empty(self):
        g = os.path.join(self.tmp.name, "2026-11-07_000000_real-fc.csv"); open(g, "wb").write(b"\x00\xff garbage\nnot,csv\n")
        self._load(g); self.assertIn("Cannot show", self.page.status.text())
        e = os.path.join(self.tmp.name, "2026-11-07_000001_real-fc.csv"); open(e, "w").close()
        self._load(e); self.assertIn("Cannot show", self.page.status.text())

    def test_no_dialog_widgets(self):
        self.assertEqual(self.page.findChildren(QCheckBox), []); self.assertEqual(self.page.findChildren(QMessageBox), [])

    def test_real_recordings(self):
        os.environ.pop("DRONEFORGE_FLIGHTS")
        files = sorted(glob.glob(os.path.expanduser("~/Music/DroneForge/docs/flights/*real-fc.csv")))[-3:]
        if not files: self.skipTest("no recordings")
        for f in files:
            d = R.load_session(f); self.assertTrue(d["t"])


if __name__ == "__main__":
    unittest.main()
