import os, unittest
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
from PyQt6.QtWidgets import QApplication
from nimbus_gcs.viz.drone_3d import Drone3DView

_app = QApplication.instance() or QApplication([])


class TestDrone3D(unittest.TestCase):
    def test_states_orbit_and_click(self):
        v = Drone3DView(); v.resize(600, 500); v.show(); got = []
        v.motor_clicked.connect(got.append)
        v.grab(); self.assertTrue(v.stale)
        v.set_outputs([1100] * 4, False); v.set_selected(2); v.set_seen([None, False, None, None]); v.grab()
        self.assertTrue(v.running()); y = v.yaw; v.yaw += 1; v.reset_view(); self.assertEqual(v.yaw, y)
        c, _r = v._hit[3]; v.click_at(c); self.assertEqual(got, [3])
        v.set_outputs(None, True); self.assertTrue(v.stale)


if __name__ == "__main__":
    unittest.main()
