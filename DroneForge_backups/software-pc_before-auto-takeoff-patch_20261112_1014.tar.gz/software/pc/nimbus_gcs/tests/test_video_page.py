import os
import tempfile
import time
import unittest
from types import SimpleNamespace

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
os.environ["DRONEFORGE_VIDEO_STATE"] = os.path.join(tempfile.mkdtemp(), "video.json")

import numpy as np
from PyQt6.QtWidgets import QApplication, QCheckBox, QMessageBox, QPushButton  # noqa: E402

from nimbus_gcs.main_window import apply_dark               # noqa: E402
from nimbus_gcs import video_page as VP                     # noqa: E402
from nimbus_gcs.video_source import VideoSource             # noqa: E402
from nimbus_gcs.video_pip import VideoPip                    # noqa: E402
from nimbus_gcs.video_source import FakeCapture              # noqa: E402
from nimbus_pc import vtx                                   # noqa: E402
from nimbus_pc.emulator import VTX_CONFIG                   # noqa: E402

_app = QApplication.instance() or QApplication([])
apply_dark(_app)


class FakeSess:
    def __init__(self, reply=True):
        self.sent = []; self.reply = reply

    def send_frame(self, f):
        self.sent.append(f)

    def request_msp(self, cmd, timeout=2.0):
        return {"cmd": cmd, "payload": VTX_CONFIG} if self.reply else None


def _win(connected=True, reply=True, decoded=None):
    sess = FakeSess(reply)
    model = SimpleNamespace(connected=connected, core=SimpleNamespace(sess=sess if connected else None),
                            state=SimpleNamespace(decoded=decoded or {}))
    return SimpleNamespace(model=model, video_source=VideoSource(opener=lambda k, t: None, load=False)), sess


class TestVideoPage(unittest.TestCase):
    def setUp(self):
        for n in ("question", "information", "warning", "critical"):
            setattr(QMessageBox, n, staticmethod(lambda *a, **k: (_ for _ in ()).throw(AssertionError("dialog"))))

    def test_builds_without_checkbox(self):
        win, _ = _win(); p = VP.VideoPage(win)
        self.assertEqual(p.findChildren(QCheckBox), [])
        self.assertEqual(p.band.count(), 6); self.assertEqual(p.channel.count(), 8); self.assertEqual(p.power.count(), 5)

    def test_apply_sends_expected_frames(self):
        win, sess = _win(); p = VP.VideoPage(win)
        p.band.setCurrentIndex(p.band.findData("F")); p.channel.setCurrentIndex(3); p.power.setCurrentIndex(1)
        p.apply_vtx()
        self.assertEqual([f.hex() for f in sess.sent], ["c80c7cc8ea5000590004001b0006", "c8087cc8ea41020044d7"])
        self.assertIn("Sent", p.vtx_status.text())

    def test_read_fills_dropdowns(self):
        win, _ = _win(); p = VP.VideoPage(win)
        p._on_config(p._do_read())
        self.assertEqual((p.band.currentData(), p.channel.currentData(), p.power.currentData()), ("F", 2, 2))
        self.assertIn("5800", p.vtx_status.text())

    def test_read_no_reply_inline(self):
        win, _ = _win(reply=False); p = VP.VideoPage(win)
        p._on_config(p._do_read())
        self.assertIn("No reply", p.vtx_status.text())

    def test_scan_sends_and_renders(self):
        data = bytes([10] * 48); data = data[:27] + b"\xc8" + data[28:]
        win, sess = _win(decoded={"vrx_top_channels": {"rssi_by_freq_order": list(data)}}); p = VP.VideoPage(win)
        p.scan()
        self.assertEqual(sess.sent[-1], vtx.scan_frame())
        p.chart.rows = None; p._tick()
        self.assertEqual(len(p.chart.rows), 48)
        self.assertEqual(p.chart.best[:2], ("F", 4))
        self.assertIn("band F channel 4", p.scan_status.text())
        p.chart.resize(500, 160); p.chart.grab()

    def test_not_connected_reasons(self):
        win, sess = _win(connected=False); p = VP.VideoPage(win)
        for b in (p.btn_read, p.btn_apply, p.btn_scan):
            self.assertFalse(b.isEnabled())
        p.apply_vtx(); p.scan()
        self.assertEqual(sess.sent, [])
        self.assertIn("Not connected", p.vtx_status.text()); self.assertIn("Not connected", p.scan_status.text())

    def test_source_kinds_show_hide_analog_cards(self):
        win, _ = _win(); p = VP.VideoPage(win); p.show()
        for data, analog in (("dji", False), ("usb", False), ("analog", True)):
            p.source.setCurrentIndex(p.source.findData(data))
            self.assertEqual(p.top.isVisibleTo(p), analog, data)
            self.assertEqual(p.url.isVisibleTo(p), data == "dji")
            self.assertEqual(p.device.isVisibleTo(p), data != "dji")
        self.assertEqual(p.findChildren(QCheckBox), [])

    def test_snapshot_writes_png(self):
        win, _ = _win(); p = VP.VideoPage(win)
        d = tempfile.mkdtemp(); VP.SNAP_DIR = d
        p.src._frame = np.full((40, 60, 3), 90, np.uint8)
        p.snapshot()
        files = os.listdir(d)
        self.assertEqual(len(files), 1); self.assertTrue(files[0].endswith("_snapshot.png"))
        self.assertIn("Saved", p.video_status.text())

    def test_snapshot_without_frame_inline(self):
        win, _ = _win(); p = VP.VideoPage(win); p.snapshot()
        self.assertIn("No frame", p.video_status.text())

    def test_live_frames_render(self):
        win, _ = _win(); p = VP.VideoPage(win)
        win.video_source._opener = lambda k, t: FakeCapture(lambda: np.zeros((48, 64, 3), np.uint8))
        p.source.setCurrentIndex(p.source.findData("dji")); p.url.setText("rtsp://x/y"); p.start_video()
        for _ in range(100):
            if win.video_source.state == "live": break
            time.sleep(0.02)
        p._tick(); p.view.resize(300, 200); p.view.grab()
        self.assertIn("Live", p.video_status.text())
        p.stop_video()


class TestPip(unittest.TestCase):
    def test_hidden_without_source_and_shows_live(self):
        win, _ = _win(); pip = VideoPip(win); pip.refresh()
        self.assertFalse(pip.isVisibleTo(None) and pip.isVisible())
        self.assertTrue(pip.isHidden())
        src = win.video_source
        src._opener = lambda k, t: FakeCapture(lambda: np.zeros((48, 64, 3), np.uint8))
        src.set_source("network", "rtsp://x"); src.start()
        for _ in range(100):
            if src.state == "live": break
            time.sleep(0.02)
        pip.refresh(); self.assertFalse(pip.isHidden()); pip.grab()
        src.stop(); pip.refresh(); self.assertTrue(pip.isHidden())
        self.assertEqual(pip.findChildren(QCheckBox), []); self.assertEqual(pip.findChildren(QPushButton), [])


if __name__ == "__main__":
    unittest.main()
