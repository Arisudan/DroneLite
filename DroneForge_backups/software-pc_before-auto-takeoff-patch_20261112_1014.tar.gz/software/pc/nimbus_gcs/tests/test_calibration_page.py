import math
import os
import unittest
from types import SimpleNamespace

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PyQt6.QtWidgets import QApplication, QCheckBox, QMessageBox  # noqa: E402

from nimbus_core import settings as S                       # noqa: E402
from nimbus_core.director import Result                    # noqa: E402
from nimbus_gcs.main_window import apply_dark               # noqa: E402
from nimbus_gcs import theme
from nimbus_gcs.calibration_page import CalibrationPage     # noqa: E402

_app = QApplication.instance() or QApplication([])
apply_dark(_app)


def _fake(raw=14.0, deg=(0.2, 0.1), sim=False, **core_kw):
    au = SimpleNamespace(settings=S.FlightSettings(), fc_armed=False, phase="idle")
    calls = []

    def apply(new, persist=True):
        calls.append(new); au.settings = new; return Result(True, "Settings applied")
    att = {"pitch_rad": math.radians(deg[0]), "roll_rad": math.radians(deg[1])}
    core = SimpleNamespace(autonomy=au, director=SimpleNamespace(apply_settings=apply), connected=True, state_source="live",
                           source="idle", ramp=SimpleNamespace(phase="idle"), state=SimpleNamespace(decoded={"attitude": att}),
                           safety=SimpleNamespace(cfg=SimpleNamespace(cells=4)), **core_kw)
    model = SimpleNamespace(core=core, is_sim=sim, raw_vbat=lambda: raw)
    return SimpleNamespace(model=model), calls


class TestCalibrationPage(unittest.TestCase):
    def setUp(self):
        for n in ("question", "information", "warning", "critical"):
            setattr(QMessageBox, n, staticmethod(lambda *a, **k: (_ for _ in ()).throw(AssertionError("dialog"))))

    def test_builds_no_checkbox(self):
        win, _ = _fake(); p = CalibrationPage(win)
        self.assertEqual(p.findChildren(QCheckBox), [])
        self.assertFalse(p.btn_level.isEnabled()); self.assertIn("not available yet", p.res_level.text())

    def test_tilt_colours(self):
        for deg, col in (((0.2, 0.1), theme.ACC), ((1.0, 0.0), theme.AMB), ((0.0, 2.0), theme.RED)):
            win, _ = _fake(deg=deg); p = CalibrationPage(win)
            self.assertIn(col, p.lbl_tilt.styleSheet())
        self.assertIn("pitch +1.0", CalibrationPage(_fake(deg=(1.0, 0))[0]).lbl_tilt.text())

    def test_gyro_refusals_disable(self):
        win, _ = _fake(); win.model.core.autonomy.fc_armed = True
        p = CalibrationPage(win); self.assertFalse(p.btn_gyro.isEnabled()); self.assertIn("disarm", p.res_gyro.text())
        win, _ = _fake(); win.model.core.connected = False
        p = CalibrationPage(win); self.assertFalse(p.btn_gyro.isEnabled()); self.assertIn("connect", p.res_gyro.text().lower())
        win, _ = _fake(); win.model.core.autonomy.phase = "flying"
        self.assertIn("Autonomy", CalibrationPage(win).res_gyro.text())

    def test_gyro_enabled_when_idle(self):
        p = CalibrationPage(_fake()[0]); self.assertTrue(p.btn_gyro.isEnabled())

    def test_battery_calibrate_and_reset(self):
        win, calls = _fake(raw=14.0); p = CalibrationPage(win)
        self.assertIn("14.00 V", p.lbl_batt.text())
        p.btn_cal.click()
        self.assertAlmostEqual(calls[-1].battery_scale, round(4 * 4.16 / 14.0, 2))
        self.assertIn("Factor", p.res_batt.text()); self.assertTrue(p.btn_cal_reset.isEnabled())
        p.btn_cal_reset.click(); self.assertEqual(calls[-1].battery_scale, 1.0)

    def test_battery_refusals(self):
        win, calls = _fake(raw=9.0); p = CalibrationPage(win); p.btn_cal.click()
        self.assertIn("too low", p.res_batt.text()); self.assertEqual(calls, [])
        win, _ = _fake(sim=True); p = CalibrationPage(win); self.assertFalse(p.btn_cal.isEnabled())
        win, _ = _fake(raw=None); p = CalibrationPage(win); self.assertFalse(p.btn_cal.isEnabled())


if __name__ == "__main__":
    unittest.main()
