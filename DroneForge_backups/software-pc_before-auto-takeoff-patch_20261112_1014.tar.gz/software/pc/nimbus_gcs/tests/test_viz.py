"""Offscreen tests for nimbus_gcs.viz widgets."""
import os
import unittest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
from PyQt6.QtGui import QColor, QImage
from PyQt6.QtWidgets import QApplication, QCheckBox, QMessageBox, QWidget

from nimbus_gcs import theme
from nimbus_gcs.viz.bottom_strip import BottomStrip
from nimbus_gcs.viz.flight_view_mini import FlightViewMini
from nimbus_gcs.viz.height_plot import HeightPlot
from nimbus_gcs.viz.mission_timeline import MissionTimeline
from nimbus_gcs.viz.preflight_list import PreflightList
from nimbus_gcs.viz.scene_view import SceneView

app = QApplication.instance() or QApplication([])
theme.load_fonts()
SIZES = [(1280, 720), (1920, 1080)]


def colours(img: QImage) -> int:
    seen = set()
    for y in range(0, img.height(), 3):
        for x in range(0, img.width(), 3):
            seen.add(img.pixel(x, y))
    return len(seen)


def grab(w, size):
    w.resize(*size); w.show(); return w.grab().toImage()


class VizTests(unittest.TestCase):
    def test_all_paint_non_blank(self):
        rows = [("a", "Link", "ready", "ok"), ("b", "Battery", "13.8 V", "caution")]
        for size in SIZES:
            for mk in (MissionTimeline, HeightPlot, FlightViewMini, SceneView, BottomStrip, PreflightList):
                w = mk()
                if mk is PreflightList:
                    w.set_checks(rows)
                s = (size[0] // 2, size[1] // 3) if mk in (FlightViewMini, PreflightList) else size
                if mk in (MissionTimeline, BottomStrip):
                    s = (size[0], 130)
                self.assertGreater(colours(grab(w, s)), 4, f"{mk.__name__} blank at {size}")

    def test_phase_mapping_and_nodes(self):
        t = MissionTimeline(); t.resize(1000, 130)
        for n in ("safe", "ready", "armed", "takeoff", "climb", "hold", "land"):
            t.set_phase(n); self.assertEqual(t.phase(), n)
        t.set_phase("bogus"); self.assertEqual(t.phase(), "land")
        t.set_expected({"ready": 30}); self.assertEqual(t.total_seconds(), 125)
        xs = [t.node_x(n) for n in ("safe", "ready", "armed", "takeoff", "climb", "hold", "land")]
        self.assertEqual(xs, sorted(xs)); self.assertAlmostEqual(xs[0], 72)
        self.assertAlmostEqual(xs[2] - xs[1], 30 / 125 * (1000 - 72 - 24))
        p = HeightPlot(); t.set_margins(*p.plot_margins()); self.assertEqual(t.node_x("safe"), p.plot_margins()[0])
        t.set_phase_elapsed(9); t.update()

    def test_plot_ring_buffer(self):
        p = HeightPlot(); p.set_window(10)
        for i in range(100):
            p.push(i, 0.5, i / 200, 0.0)
        pts = p.points()
        self.assertLessEqual(pts[0][0], 100); self.assertGreaterEqual(pts[0][0], 88); self.assertEqual(pts[-1][0], 99)
        self.assertEqual(p.view_range(), (89, 99))
        p.clear(); self.assertEqual(p.points(), [])
        p.load_series([0, 1, 2], [0, .5, .5], [0, .2, .4], [0, 0, 0]); self.assertEqual(len(p.points()), 3)
        self.assertGreater(colours(grab(p, (900, 260))), 4)

    def test_scene_with_and_without_frame(self):
        s = SceneView(); s.set_values(0.52, 47, 0.12)
        a = grab(s, (1280, 720)); self.assertFalse(s.has_frame())
        img = QImage(640, 360, QImage.Format.Format_RGB32); img.fill(QColor("#336699"))
        s.set_frame(img); b = grab(s, (1280, 720)); self.assertTrue(s.has_frame()); self.assertNotEqual(a, b)
        s.set_frame(None); self.assertFalse(s.has_frame())

    def test_pip_click(self):
        s = SceneView(); f = FlightViewMini(); s.set_pip_widget(f); s.resize(1280, 720); s.show()
        got = []; s.pip_clicked.connect(lambda: got.append(1))
        from PyQt6.QtTest import QTest
        from PyQt6.QtCore import Qt
        QTest.mouseClick(f, Qt.MouseButton.LeftButton)
        self.assertEqual(got, [1])
        r = s.pip_rect(); self.assertEqual(f.geometry().getRect(), r)
        self.assertLess(r[0] + r[2], 1280 // 2)

    def test_preflight_rows_and_signal(self):
        l = PreflightList(); l.resize(376, 300)
        l.set_checks([("link", "Link and RC", "ready", "ok"), ("batt", "Battery", "13.8 V · warning only", "caution"), ("fc", "Flight controller", "no heartbeat", "blocking")])
        self.assertEqual(l.ready_count(), 2)
        got = []; l.row_clicked.connect(got.append)
        from PyQt6.QtTest import QTest
        from PyQt6.QtCore import Qt, QPoint
        l.show(); QTest.mouseClick(l, Qt.MouseButton.LeftButton, pos=QPoint(100, 32 + 40 + 20))
        self.assertEqual(got, ["batt"])
        img = grab(l, (376, 260)); self.assertGreater(colours(img), 6)

    def test_bottom_strip_caution(self):
        b = BottomStrip(); b.set_values({"HEIGHT": "0.52", "BATT": "13.8"})
        a = grab(b, (1280, 80)); b.set_caution("BATT", True); c = grab(b, (1280, 80)); self.assertNotEqual(a, c)

    def test_no_forbidden_widgets(self):
        import nimbus_gcs.viz as v, pathlib
        for f in pathlib.Path(v.__file__).parent.glob("*.py"):
            src = f.read_text(); self.assertNotIn("QCheckBox", src); self.assertNotIn("QMessageBox", src)


if __name__ == "__main__":
    unittest.main()
