import os
import tempfile
import time
import unittest

import numpy as np

from nimbus_gcs import video_source as VS


def wait(cond, t=3.0):
    end = time.monotonic() + t
    while time.monotonic() < end:
        if cond(): return True
        time.sleep(0.01)
    return False


FRAME = np.full((24, 32, 3), 7, np.uint8)


class TestSource(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp(); os.environ["DRONEFORGE_VIDEO_STATE"] = os.path.join(self.tmp, "v.json")

    def tearDown(self):
        os.environ.pop("DRONEFORGE_VIDEO_STATE", None)

    def test_connect_live_stall_reconnect(self):
        mode = {"m": "ok", "opens": 0}
        def opener(k, t):
            mode["opens"] += 1
            return VS.FakeCapture(lambda: (FRAME if mode["m"] == "ok" else (time.sleep(0.05) or FRAME if mode["m"] == "slow" else None)))
        s = VS.VideoSource(opener=opener, stall_s=0.2, backoff=(0.05,), load=False)
        s.set_source("network", "rtsp://a"); s.start()
        self.assertTrue(wait(lambda: s.state == "live")); self.assertGreater(s.frame_count, 0)
        self.assertEqual(s.latest().shape, (24, 32, 3))
        s._last_t -= 1.0                                    # frames stop arriving
        self.assertEqual(s.state, "stalled")
        mode["m"] = "bad"                                   # read failures -> error -> reconnect
        self.assertTrue(wait(lambda: s.state.startswith("error") or mode["opens"] > 1))
        mode["m"] = "ok"
        self.assertTrue(wait(lambda: s.state == "live" and mode["opens"] > 1))
        s.stop(); self.assertEqual(s.state, "stopped"); self.assertIsNone(s.latest())

    def test_open_error_retries(self):
        n = {"c": 0}
        def opener(k, t):
            n["c"] += 1; return VS.FakeCapture(lambda: FRAME, opened=n["c"] > 2)
        s = VS.VideoSource(opener=opener, backoff=(0.02,), load=False)
        s.set_source("network", "x"); s.start()
        self.assertTrue(wait(lambda: s.state.startswith("error") or n["c"] >= 2))
        self.assertTrue(wait(lambda: s.state == "live")); s.stop()

    def test_no_url_is_error_not_thread(self):
        s = VS.VideoSource(opener=lambda k, t: None, load=False)
        s.set_source("network", ""); s.start()
        self.assertTrue(s.state.startswith("error")); self.assertFalse(s.running)

    def test_persistence_roundtrip(self):
        s = VS.VideoSource(opener=lambda k, t: None, load=False)
        s.set_source("network", "http://h/mjpeg", analog=False)
        s2 = VS.VideoSource(opener=lambda k, t: None)
        self.assertEqual((s2.kind, s2.target, s2.analog), ("network", "http://h/mjpeg", False))
        s.set_source("usb", "/dev/video2", analog=True)
        self.assertTrue(VS.load_choice()["analog"])

    def test_bad_state_file_is_safe(self):
        open(os.environ["DRONEFORGE_VIDEO_STATE"], "w").write("{nope")
        self.assertEqual(VS.load_choice()["kind"], "none")
        os.environ["DRONEFORGE_VIDEO_STATE"] = "/proc/nope/x.json"
        VS.save_choice("none", "")                          # must not raise

    def test_snapshot(self):
        s = VS.VideoSource(opener=lambda k, t: None, load=False)
        p = os.path.join(self.tmp, "a", "s.png")
        self.assertFalse(s.snapshot_png(p))
        s._frame = FRAME; self.assertTrue(s.snapshot_png(p)); self.assertGreater(os.path.getsize(p), 0)

    def test_cv2_missing(self):
        orig = VS.cv2; VS.cv2 = None
        try:
            s = VS.VideoSource(load=False); s.set_source("network", "rtsp://x"); s.start()
            self.assertIn("OpenCV not installed", s.state); self.assertFalse(s.running)
        finally:
            VS.cv2 = orig


if __name__ == "__main__":
    unittest.main()
