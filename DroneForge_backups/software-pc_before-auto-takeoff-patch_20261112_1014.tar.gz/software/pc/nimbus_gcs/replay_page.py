"""Replay: step through a recorded GCS session (CSV from the recorder) with charts, a moving cursor, a 'now' card and event markers.
No dialogs, no tick boxes: errors and status are inline. CSV loading runs in a worker thread."""
from __future__ import annotations

import bisect
import csv
import os
import re
import threading
import time
from typing import Callable, List, Optional

from PyQt6.QtCore import QPointF, QRectF, Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QColor, QPainter, QPen
from PyQt6.QtWidgets import (QComboBox, QHBoxLayout, QLabel, QListWidget, QListWidgetItem, QPlainTextEdit, QPushButton, QSlider,
                             QVBoxLayout, QWidget)

from nimbus_core import recorder
from . import theme
from .analysis_page import StaticChart, look
from .components import Card

KINDS = ("real-fc", "simulator", "bench-props-off")
_NAME = re.compile(r"^(\d{4}-\d\d-\d\d)_(\d\d)(\d\d)(\d\d)_(.+)\.csv$")
_EVENT = re.compile(r"^\s*(-?\d+(?:\.\d+)?)s\s+(.*)$")
NUM = ("range_m", "z_est", "z_ref", "fc_z", "pitch_deg", "roll_deg", "batt_v", "lq", "m1", "m2", "m3", "m4")


def flights_dir() -> str:
    return os.environ.get("DRONEFORGE_FLIGHTS", recorder.DIR)


def _tail_time(path: str) -> Optional[float]:
    try:
        with open(path, "rb") as f:
            f.seek(0, os.SEEK_END); n = f.tell(); f.seek(max(0, n - 4096))
            lines = f.read().decode("utf-8", "ignore").strip().splitlines()
        return float(lines[-1].split(",")[0])
    except (OSError, ValueError, IndexError):
        return None


def _armed_from_summary(base: str) -> Optional[bool]:
    try:
        with open(base + ".summary.txt", errors="ignore") as f: txt = f.read()
        m = re.search(r"^armed:\s*([\d.]+)\s*s", txt, re.M)
        return float(m.group(1)) > 0 if m else None
    except (OSError, ValueError):
        return None


def scan_sessions(folder: Optional[str] = None) -> List[dict]:
    folder = folder or flights_dir(); out = []
    try: names = sorted(os.listdir(folder), reverse=True)
    except OSError: return out
    for n in names:
        m = _NAME.match(n)
        if not m: continue
        path = os.path.join(folder, n); base = path[:-4]
        out.append({"path": path, "name": n, "kind": m.group(5), "when": f"{m.group(1)} {m.group(2)}:{m.group(3)}:{m.group(4)}",
                    "duration": _tail_time(path), "armed": _armed_from_summary(base)})
    return out


def load_session(path: str) -> dict:
    """Parse a recording. Raises ValueError with a readable message when it is empty or not a recording."""
    base = path[:-4] if path.endswith(".csv") else path
    try:
        with open(path, newline="", errors="replace") as f:
            rd = csv.DictReader(f)
            if not rd.fieldnames or "t" not in rd.fieldnames:
                raise ValueError("this file has no recording header (no 't' column)")
            rows = []
            for r in rd:
                try: t = float(r["t"])
                except (ValueError, TypeError, KeyError): continue
                rows.append((t, r))
    except OSError as e:
        raise ValueError(f"cannot read the file: {e}")
    if not rows:
        raise ValueError("the recording has no data rows")
    rows.sort(key=lambda x: x[0])
    t = [a for a, _ in rows]
    cols = {k: [] for k in NUM}
    for _, r in rows:
        for k in NUM:
            try: v = float(r[k]) if r.get(k, "") != "" else float("nan")
            except ValueError: v = float("nan")
            cols[k].append(v)
    cols["tilt"] = [max(abs(a), abs(b)) if a == a and b == b else float("nan") for a, b in zip(cols["pitch_deg"], cols["roll_deg"])]
    cols["phase"] = [r.get("phase", "") for _, r in rows]; cols["state"] = [r.get("state", "") for _, r in rows]
    armed = any(r.get("cmd_arm") == "1" for _, r in rows)
    events = []
    try:
        with open(base + ".events.txt", errors="ignore") as f:
            for line in f:
                m = _EVENT.match(line)
                if m: events.append((float(m.group(1)), m.group(2).strip()))
    except OSError:
        pass
    try:
        with open(base + ".summary.txt", errors="ignore") as f: summary = f.read().strip()
    except OSError: summary = "(no summary file for this recording)"
    return {"t": t, "cols": cols, "events": events, "summary": summary, "armed": armed}


class ReplayChart(StaticChart):
    """StaticChart plus a moving cursor line and event markers."""

    def __init__(self, *a, **k) -> None:
        super().__init__(*a, **k); self.cursor = 0.0; self.marks: List[float] = []

    def paintEvent(self, e) -> None:
        super().paintEvent(e)
        left, right, top = 46, 10, 20; bottom = 22 if self.show_axis else 6
        w, h = self.width(), self.height(); pw = max(w - left - right, 10)
        p = QPainter(self)
        p.setPen(QPen(QColor(theme.DIM), 1, Qt.PenStyle.DotLine))
        for m in self.marks:
            x = left + pw * m / self.xmax
            if left <= x <= left + pw: p.drawLine(QPointF(x, top), QPointF(x, h - bottom))
        p.setPen(QPen(QColor(theme.TXT), 1.5)); x = left + pw * min(max(self.cursor, 0.0), self.xmax) / self.xmax
        p.drawLine(QPointF(x, top), QPointF(x, h - bottom)); p.end()


class ReplayPage(QWidget):
    sig_loaded = pyqtSignal(int, object, str)

    def __init__(self, win, clock: Callable[[], float] = time.monotonic) -> None:
        super().__init__()
        self.win, self.clock = win, clock
        self.token = 0; self.data: Optional[dict] = None; self.cur = 0.0; self.playing = False; self._last = 0.0
        self.sessions: List[dict] = []
        root = QHBoxLayout(self); root.setContentsMargins(0, 0, 0, 0); root.setSpacing(theme.SP["m"])
        # left: sessions
        lc = Card("Recordings"); lc.setFixedWidth(336); self.list_card = lc; root.addWidget(lc)
        self.kind = QComboBox(); self.kind.addItem("All kinds"); self.kind.addItems(KINDS); self.kind.currentIndexChanged.connect(self._fill)
        lc.body.addWidget(self.kind)
        self.list = QListWidget(); self.list.setMinimumWidth(280); self.list.currentRowChanged.connect(self._picked); lc.body.addWidget(self.list, 1)
        self.list_note = QLabel(""); self.list_note.setObjectName("dim"); self.list_note.setWordWrap(True); lc.body.addWidget(self.list_note)
        # right
        right = QVBoxLayout(); right.setSpacing(theme.SP["m"]); root.addLayout(right, 1)
        nc = Card("Now"); self.now_card = nc; right.addWidget(nc)
        self.status = QLabel("Choose a recording on the left."); self.status.setWordWrap(True); self.status.setObjectName("dim"); nc.body.addWidget(self.status)
        self.now = QLabel(""); self.now.setObjectName("mono"); self.now.setFont(theme.f_mono(13)); self.now.setWordWrap(True); nc.body.addWidget(self.now)
        k = lambda i: look(i)[0]
        self.charts = [
            ReplayChart("Height", [("z_est", "estimate", k(0)), ("z_ref", "target", k(2)), ("range_m", "range", k(1))], "m"),
            ReplayChart("Attitude", [("pitch_deg", "pitch", k(0)), ("roll_deg", "roll", k(2))], "deg"),
            ReplayChart("Battery", [("batt_v", "V", k(1))], "V"),
            ReplayChart("Link", [("lq", "lq", k(0))], "%"),
            ReplayChart("Motors", [("m1", "M1", k(0)), ("m2", "M2", k(1)), ("m3", "M3", k(2)), ("m4", "M4", k(3))], "us"),
        ]
        cc = Card("Session", "DOTTED = EVENT"); cc.layout().setContentsMargins(16, 16, 16, 16); self.charts_card = cc
        for c in self.charts: cc.body.addWidget(c, 1)
        right.addWidget(cc, 1)
        tc = Card("Transport"); self.transport_card = tc; right.addWidget(tc)
        bar = QHBoxLayout(); bar.setSpacing(theme.SP["s"]); tc.body.addLayout(bar)
        self.play = QPushButton("Play"); self.play.setObjectName("primary"); self.play.setMinimumWidth(96); self.play.clicked.connect(self.toggle); bar.addWidget(self.play)
        self.slider = QSlider(Qt.Orientation.Horizontal); self.slider.setRange(0, 1000); self.slider.valueChanged.connect(self._slid); bar.addWidget(self.slider, 1)
        self.speed = QComboBox(); self.speed.addItems(["0.5x", "1x", "2x", "4x"]); self.speed.setCurrentIndex(1); bar.addWidget(self.speed)
        low = QHBoxLayout(); low.setSpacing(theme.SP["m"]); tc.body.addLayout(low)
        self.events = QListWidget(); self.events.setMaximumHeight(96); self.events.currentRowChanged.connect(self._event_picked); low.addWidget(self.events, 1)
        self.summary = QPlainTextEdit(); self.summary.setReadOnly(True); self.summary.setMaximumHeight(96); self.summary.setFont(theme.f_mono(12)); low.addWidget(self.summary, 1)
        self.timer = QTimer(self); self.timer.setInterval(40); self.timer.timeout.connect(self.tick)
        self.sig_loaded.connect(self._loaded)
        self.refresh()

    # ---- session list
    def refresh(self) -> None:
        self.sessions = scan_sessions(); self._fill()

    def _fill(self) -> None:
        k = self.kind.currentText(); self.list.blockSignals(True); self.list.clear()
        self.shown = [s for s in self.sessions if k == "All kinds" or s["kind"] == k]
        for s in self.shown:
            d = s["duration"]; dur = "?" if d is None else (f"{d:.0f} s" if d < 120 else f"{d / 60:.1f} min")
            arm = {True: "armed", False: "not armed", None: ""}[s["armed"]]
            it = QListWidgetItem(f"{s['when']}  {s['kind']}\n    {dur}  {arm}".rstrip()); it.setData(Qt.ItemDataRole.UserRole, s["path"]); self.list.addItem(it)
        self.list.blockSignals(False)
        self.list_note.setText(f"{len(self.shown)} recording(s) in {flights_dir()}" if self.shown else f"No recordings found in {flights_dir()}")

    def _picked(self, row: int) -> None:
        if 0 <= row < len(self.shown): self.open_file(self.shown[row]["path"])

    # ---- loading
    def open_file(self, path: str) -> None:
        self.token += 1; tok = self.token; self.pause()
        self.status.setText(f"Loading {os.path.basename(path)} ..."); self.status.setStyleSheet(f"color:{theme.DIM};")
        threading.Thread(target=self._work, args=(path, tok), daemon=True).start()

    def _work(self, path: str, tok: int) -> None:
        try: self.sig_loaded.emit(tok, load_session(path), "")
        except Exception as e:                                   # a damaged file must give a message, never a crash
            self.sig_loaded.emit(tok, None, str(e) or type(e).__name__)

    def _loaded(self, tok: int, data, err: str) -> None:
        if tok != self.token: return
        if data is None:
            self.data = None; self.status.setText(f"Cannot show this recording: {err}"); self.status.setStyleSheet(f"color:{theme.RED};")
            self.summary.setPlainText(""); self.events.clear(); self.now.setText("")
            for c in self.charts: c.set_data([], {}, 1.0)
            return
        self.data = data; t = data["t"]; xmax = t[-1]
        self.status.setText(f"{len(t)} samples, {xmax:.1f} s" + ("" if data["armed"] else "  (never armed)")); self.status.setStyleSheet(f"color:{theme.DIM};")
        self.summary.setPlainText(data["summary"])
        self.events.clear()
        for ts, txt in data["events"]: self.events.addItem(f"{ts:7.2f} s  {txt}")
        marks = [e[0] for e in data["events"]]
        for i, c in enumerate(self.charts):
            c.marks = marks
            if c.title == "Motors":
                has = any(v == v for k in ("m1", "m2", "m3", "m4") for v in data["cols"][k]); c.setVisible(has)
            c.set_data(*self._plot_data(data), xmax, show_axis=(i == len(self.charts) - 1))
        self.seek(0.0)

    @staticmethod
    def _plot_data(data: dict):
        """Chart data: gaps (NaN) held at the last valid value (0 if none), thinned to about 3000 points."""
        t = data["t"]; step = max(1, len(t) // 3000); idx = range(0, len(t), step)
        out = {}
        for k in NUM:
            col = data["cols"][k]; first = next((v for v in col if v == v), 0.0); last = first; vals = []
            for v in col:
                if v == v: last = v
                vals.append(last)
            out[k] = [vals[i] for i in idx]
        return [t[i] for i in idx], out

    # ---- cursor / playback
    @property
    def duration(self) -> float:
        return self.data["t"][-1] if self.data else 0.0

    def seek(self, t: float) -> None:
        self.cur = min(max(t, 0.0), self.duration)
        for c in self.charts: c.cursor = self.cur; c.update()
        self.slider.blockSignals(True); self.slider.setValue(int(1000 * self.cur / self.duration) if self.duration else 0); self.slider.blockSignals(False)
        self.now.setText(self.readout(self.cur))

    def readout(self, t: float) -> str:
        d = self.data
        if not d: return ""
        i = max(bisect.bisect_right(d["t"], t) - 1, 0); c = d["cols"]
        f = lambda k, fmt: "-" if c[k][i] != c[k][i] else format(c[k][i], fmt)
        return (f"time {t:6.2f} s   phase {c['phase'][i] or '-'}   state {c['state'][i] or '-'}\n"
                f"height {f('z_est', '.2f')} m   target {f('z_ref', '.2f')} m   tilt {f('tilt', '.1f')} deg   battery {f('batt_v', '.2f')} V   link {f('lq', '.0f')} %")

    def _slid(self, v: int) -> None:
        self.seek(self.duration * v / 1000.0)

    def _event_picked(self, row: int) -> None:
        if self.data and 0 <= row < len(self.data["events"]): self.seek(self.data["events"][row][0])

    def speed_value(self) -> float:
        return float(self.speed.currentText().rstrip("x"))

    def toggle(self) -> None:
        self.pause() if self.playing else self.start()

    def start(self) -> None:
        if not self.data: return
        if self.cur >= self.duration: self.seek(0.0)
        self.playing = True; self._last = self.clock(); self.play.setText("Pause"); self.timer.start()

    def pause(self) -> None:
        self.playing = False; self.play.setText("Play"); self.timer.stop()

    def tick(self) -> None:
        now = self.clock(); dt, self._last = now - self._last, now
        if not self.playing: return
        self.seek(self.cur + dt * self.speed_value())
        if self.cur >= self.duration: self.pause()
