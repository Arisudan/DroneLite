"""python3 -m nimbus_gcs [--port P] [--connect] [--screenshot out.png --seconds N]"""
import argparse
import sys

from PyQt6.QtCore import QTimer
from PyQt6.QtWidgets import QApplication

from .main_window import MainWindow, apply_dark


def main() -> int:
    ap = argparse.ArgumentParser(prog="nimbus_gcs", description="DroneForge ground control station (props off when arming is allowed!)")
    ap.add_argument("--port", help="serial port feeding the dongle's CRSF UART (default: first CP2102)")
    ap.add_argument("--connect", action="store_true", help="connect on start")
    ap.add_argument("--screenshot", metavar="PNG", help="render the window to a PNG after --seconds and exit (also works with QT_QPA_PLATFORM=offscreen)")
    ap.add_argument("--seconds", type=float, default=6.0)
    args = ap.parse_args()
    app = QApplication(sys.argv[:1])
    apply_dark(app)
    win = MainWindow()
    if args.port:
        win.port_box.setCurrentText(args.port)
    win.show()
    if args.connect:
        QTimer.singleShot(200, win.toggle_connection)
    if args.screenshot:
        QTimer.singleShot(int(args.seconds * 1000), lambda: (win.grab().save(args.screenshot), win.close(), app.quit()))
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
