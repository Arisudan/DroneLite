"""SETTINGS > Diagnostics: link summary, commands sent to the drone, arming checklist, gamepad, throttle test and the events log.
No dialogs: refusals are inline notes."""
from __future__ import annotations

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QComboBox, QDoubleSpinBox, QGridLayout, QHBoxLayout, QLabel, QPlainTextEdit, QPushButton, QVBoxLayout, QWidget

from . import theme
from .components import Card
from .common import mono


def card(title):
    c = Card(title); return c, c.body
from .widgets import ChannelBars

GREEN, AMBER, RED = theme.ACC, theme.AMB, theme.RED


class DiagnosticsPage(QWidget):
    def __init__(self, win) -> None:
        super().__init__()
        self.win = win
        top = Qt.AlignmentFlag.AlignTop
        s, sl = card("Summary")
        self.summary = QLabel(""); self.summary.setObjectName("mono"); self.summary.setWordWrap(True); sl.addWidget(self.summary)
        c, cl = card("Commands out")
        self.bars = ChannelBars(); cl.addWidget(self.bars)
        self.cmd_info = QLabel(""); self.cmd_info.setObjectName("mono"); self.cmd_info.setWordWrap(True); cl.addWidget(self.cmd_info)
        r, rl = card("Arming checklist")
        self.arm_list = QLabel("--"); self.arm_list.setObjectName("mono"); self.arm_list.setWordWrap(True); rl.addWidget(self.arm_list)
        self.arm_why = QLabel(""); self.arm_why.setWordWrap(True); self.arm_why.setStyleSheet("font-weight:700"); rl.addWidget(self.arm_why)
        gp, gpl = card("Gamepad")
        self.pad_box = QComboBox(); self.pad_box.setMinimumContentsLength(14); self.pad_box.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.pad_box.setToolTip("Optional manual controller. The flight buttons on the Fly page do not need it.")
        self.pad_box.activated.connect(self.on_pad_changed); gpl.addWidget(self.pad_box)
        ev, evl = card("Events")
        self.events = QPlainTextEdit(); self.events.setReadOnly(True); self.events.setFixedHeight(110); self.events.setFont(mono(9)); self._event_count = 0
        evl.addWidget(self.events)
        t, tl = card("Throttle test  -  props on, tethered")
        def pct(lo, hi, val, step, suffix=" %"):
            sp = QDoubleSpinBox(); sp.setRange(lo, hi); sp.setValue(val); sp.setSingleStep(step); sp.setSuffix(suffix); sp.setDecimals(1); return sp
        self.tt_start, self.tt_cap = pct(5, 85, 10, 5), pct(10, 95, 35, 5)
        self.tt_rate, self.tt_hold = pct(0.2, 20, 1.5, 0.5, " %/s"), pct(0, 30, 3, 1, " s")
        tg = QGridLayout(); tg.setHorizontalSpacing(12); tg.setVerticalSpacing(8)
        for i, (name, wd) in enumerate((("Start", self.tt_start), ("Cap", self.tt_cap), ("Raise by", self.tt_rate), ("Hold at cap", self.tt_hold))):
            k = QLabel(name); k.setObjectName("dim"); tg.addWidget(k, i, 0); tg.addWidget(wd, i, 1)
        tg.setColumnStretch(1, 1)
        warn = QLabel("THIS ARMS THE DRONE and raises the throttle. Props on: tether it with short slack, clear area, someone on SAFE.")
        warn.setWordWrap(True); warn.setStyleSheet(f"background:transparent;color:{theme.RED};border:1px solid {theme.RED};padding:8px 12px;border-radius:4px;font-weight:700")
        tl.addWidget(warn); tl.addLayout(tg)
        self.tt_status = QLabel("idle"); self.tt_status.setObjectName("mono"); self.tt_status.setWordWrap(True); tl.addWidget(self.tt_status)
        tr = QHBoxLayout(); self.btn_tt_run = QPushButton("Run test"); self.btn_tt_run.setObjectName("primary"); self.btn_tt_run.clicked.connect(self.on_tt_run)
        self.btn_tt_stop = QPushButton("Stop"); self.btn_tt_stop.clicked.connect(self.on_tt_stop)
        tr.addWidget(self.btn_tt_run, 2); tr.addWidget(self.btn_tt_stop, 1); tl.addLayout(tr)
        self._tt_reported = None; self._tt_armed = False
        self.tt_note = QLabel(""); self.tt_note.setWordWrap(True); self.tt_note.setStyleSheet(f"color:{RED};font-weight:700"); tl.addWidget(self.tt_note)
        g = QGridLayout(self); g.setContentsMargins(24, 16, 24, 16); g.setSpacing(16)
        g.addWidget(s, 0, 0, top); g.addWidget(c, 0, 1, top); g.addWidget(r, 1, 0, top); g.addWidget(t, 1, 1, 2, 1, top)
        g.addWidget(gp, 2, 0, top); g.addWidget(ev, 3, 0, 1, 2, top)
        g.setRowStretch(4, 1); g.setColumnStretch(0, 1); g.setColumnStretch(1, 1)
        self.fill_pads()

    # --- gamepad ------------------------------------------------------------------------------
    def fill_pads(self) -> None:
        from .model import list_gamepads
        self.pad_box.clear(); self.pad_box.addItem("None", "")
        for path, name in list_gamepads():
            self.pad_box.addItem(f"{path.rsplit('/', 1)[-1]}  {name}", path)

    def on_pad_changed(self, _=None) -> None:
        """Optional manual gamepad. Not used for flying through the Fly page (the director owns the control source)."""
        if self.win.fly.director.state().phase in ("armed", "arming", "takeoff", "climbing", "holding", "landing"):
            return
        path = self.pad_box.currentData() or ""
        self.win.model.set_source("gamepad" if path else "idle", path)

    # --- throttle test ------------------------------------------------------------------------
    def _tt_gate(self) -> tuple[bool, str]:
        m = self.win.model
        if not m.connected:
            return False, "Not connected: connect the drone (or Sim) first."
        if self.win.fly.director.state().phase not in ("ready", "landed"):
            return False, "Only while disarmed on the ground."
        if m.core.ramp.phase in ("arming", "ramping"):
            return False, ""
        if not (m.is_sim or m.is_bench) and self.tt_cap.value() > 70:
            return False, "A cap above 70 % is not allowed on the real drone: lower the cap."
        return True, "" if (m.is_sim or m.is_bench) else "Real drone: THIS ARMS IT with the props on."

    def on_tt_run(self) -> None:
        m = self.win.model
        ok, note = self._tt_gate()
        if not ok:
            self.tt_note.setText(note); return
        m.set_allow_arm(True); m.set_source("external"); self._tt_armed = True
        from nimbus_core.throttle_ramp import RampConfig
        m.core.ramp.cfg = RampConfig(start_thr=self.tt_start.value() / 100, cap_thr=max(self.tt_cap.value(), self.tt_start.value()) / 100,
                                     rate_per_s=self.tt_rate.value() / 100, hold_at_cap_s=self.tt_hold.value())
        self._tt_reported = None
        if not m.core.ramp.start():
            self.tt_note.setText("Cannot start: a flight or test is already running.")

    def on_tt_stop(self) -> None:
        self.win.model.core.ramp.stop("operator")

    # --- refresh ------------------------------------------------------------------------------
    def refresh(self, s: dict) -> None:
        m = self.win.model; st = m.state
        rp = m.core.ramp
        busy = rp.phase in ("arming", "ramping")
        gate_ok, gate_note = self._tt_gate()
        self.btn_tt_run.setEnabled(gate_ok); self.btn_tt_stop.setEnabled(busy)
        if gate_note or not busy:
            self.tt_note.setText(gate_note)
        for wd in (self.tt_start, self.tt_cap, self.tt_rate, self.tt_hold):
            wd.setEnabled(not busy)
        if busy:
            self.tt_status.setText(f"{rp.phase.upper()}  throttle {rp.thr * 100:.1f} %  range {rp._range if rp._range is not None else float('nan'):.2f} m  "
                                   f"tilt {max(abs(rp._pitch or 0), abs(rp._roll or 0)):.1f} deg   (keep the drone STILL until it says RAMPING)")
        elif rp.result is not None:
            r = rp.result
            self.tt_status.setText(f"LIFT-OFF at {r['lift_throttle'] * 100:.1f} %  ->  hover throttle about {r['hover_throttle_est'] * 100:.1f} %  (enter it in Settings > Controller)" if r["lift_throttle"] is not None
                                   else f"stopped: {r['reason']}  (last throttle {r['last_throttle'] * 100:.1f} %, no lift-off)")
            if self._tt_armed:                                        # the test is over: drop the arming permission it needed
                self._tt_armed = False
                if self.win.fly.director.state().phase in ("ready", "landed", "disconnected"):
                    m.set_allow_arm(False)
        lq = s["lq"]; pct = s["battery_pct"]
        bat = "--" if (s["battery_v"] is None or pct is None) else f"{s['battery_v']:.2f} V ({pct:.0f}%)"
        self.summary.setText(f"LQ {'--' if lq is None else f'{lq}%'}  RSSI {'--' if s['rssi'] is None else s['rssi']} dBm  SNR {'--' if s['snr'] is None else s['snr']} dB\n"
                             f"battery {bat}   mode {s['mode'] or '--'}\nOUT {s['fps']:.0f}/s (max gap {s['max_gap_ms']:.1f} ms)   CRC errors {s['crc_errors']}   source {s['source']}")
        self.bars.set_values(m.channels_us())
        c = m.last_controls
        self.cmd_info.setText(f"source {s['source']}\nroll {c.roll:+.2f} pitch {c.pitch:+.2f} yaw {c.yaw:+.2f} thr {c.throttle:.2f}\n"
                              f"allow_arm {s['allow_arm']}  arm {'HIGH' if s['arm_high'] else 'low'}\nfailsafe {'ON' if s['failsafe'] else 'off'}  watchdog {s['watchdog']}")
        mark = {True: "OK   ", False: "NO   ", None: " --  "}
        self.arm_list.setText("\n".join(f"{mark[ok]}{name}" + (f"  ({dtl})" if dtl else "") for name, ok, dtl in m.arming_status()))
        why = m.arming_summary()
        self.arm_why.setText(why)
        self.arm_why.setStyleSheet("font-weight:bold;color:%s" % (GREEN if why.startswith("Ready") else AMBER))
        evs = list(st.events)
        if len(evs) != self._event_count:
            self._event_count = len(evs)
            self.events.setPlainText("\n".join(f"+{t:7.1f}s  {txt}" for t, txt in evs))
            self.events.verticalScrollBar().setValue(self.events.verticalScrollBar().maximum())


class SetupPage(QWidget):
    """SETUP as one page: QGC-style sidebar (status dot + text state) over the existing Sensors / Motor test / Calibration / Radio sections."""

    SECTIONS = (("sensors", "Sensors", "sensor_tab", "SensorTab"), ("motors", "Motor test", "motor_tab", "MotorTab"),
                ("calibration", "Calibration", "calibration_page", "CalibrationPage"), ("radio", "Radio", "radio_page", "RadioPage"))

    def __init__(self, win) -> None:
        super().__init__()
        import importlib
        from .components.sidebar_nav import SectionStack
        self.win = win
        self.setObjectName("body"); self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.sections: dict[str, QWidget] = {}
        lay = QVBoxLayout(self); lay.setContentsMargins(0, 0, 0, 0)
        self.hub = SectionStack(); lay.addWidget(self.hub)
        for key, title, mod, cls in self.SECTIONS:
            page = getattr(importlib.import_module(f"{__package__}.{mod}"), cls)(win)
            self.sections[key] = page; self.hub.add_section(key, title, page, "setup")
        self.nav = self.hub.nav

    def refresh(self, s: dict | None = None) -> None:
        for key, page in self.sections.items():                      # every section stays live, shown or not (as separate sub-tabs did)
            try:
                (page.refresh(s) if s is not None else None) if key == "radio" else page.refresh()
            except TypeError:
                page.refresh(s)
        try:
            m = self.win.model; st = m.state
            fresh = lambda n: (st.age(n) or 99.0) < 1.0
            self.nav.set_state("sensors", "ok" if fresh("optrange") and fresh("kinematic") else "setup")
            self.nav.set_state("motors", "ok" if m.connected else "setup")
            self.nav.set_state("calibration", "ok" if abs(float(m.core.autonomy.settings.battery_scale) - 1.0) > 1e-9 else "caution")
            self.nav.set_state("radio", "ok" if m.connected else "setup")
        except Exception:
            pass
