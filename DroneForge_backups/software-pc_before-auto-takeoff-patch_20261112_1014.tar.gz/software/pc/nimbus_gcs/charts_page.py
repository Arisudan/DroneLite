"""ANALYZE > Live charts: the last 60 seconds of link, battery, range and attitude."""
from __future__ import annotations

from PyQt6.QtWidgets import QGridLayout, QVBoxLayout, QWidget

from PyQt6.QtGui import QColor

from . import theme
from .components import Card
from .widgets import StripChart

ACCENT, GOOD, WARN = QColor(theme.ACC), QColor(theme.TXT), QColor(theme.DIM)     # blue accent, white, grey: no other hues


class ChartsPage(QWidget):
    def __init__(self, win) -> None:
        super().__init__()
        self.win = win
        chc = Card("Live charts", "LAST 60 S"); chl = chc.body
        cg = QGridLayout(); cg.setSpacing(theme.SP["m"])
        self.ch_link = StripChart("Radio link", [("up_lq", "up LQ", GOOD), ("down_lq", "down LQ", ACCENT)], "%", 0, 100)
        self.ch_batt = StripChart("Battery", [("battery_v", "pack", WARN)], " V", None, None)
        self.ch_range = StripChart("Range sensor + flow", [("range_m", "range", GOOD), ("flow_q", "flow q/100", ACCENT)], "", None, None)
        self.ch_att = StripChart("Attitude (deg)", [("pitch", "pitch", ACCENT), ("roll", "roll", WARN)], "", None, None)
        for i, c in enumerate((self.ch_link, self.ch_batt, self.ch_range, self.ch_att)):
            c.setMinimumHeight(176); cg.addWidget(c, i // 2, i % 2)
        chl.addLayout(cg)
        l = QVBoxLayout(self); l.setContentsMargins(0, 0, 0, 0); l.addWidget(chc, 1)

    def refresh(self, s: dict) -> None:
        h = {k: list(v) for k, v in self.win.model.history.items()}
        self.ch_link.set_data(h); self.ch_batt.set_data(h)
        self.ch_range.set_data({"range_m": h["range_m"], "flow_q": [(t, q / 100.0) for t, q in h["flow_q"]]}); self.ch_att.set_data(h)
