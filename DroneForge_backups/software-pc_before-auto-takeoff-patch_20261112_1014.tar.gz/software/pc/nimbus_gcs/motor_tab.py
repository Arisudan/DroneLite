"""MOTORS tab (3D drone view + control panel, layout after the older Flop ground station): arm at a tiny throttle (0..10 %) and check that every motor turns.

Design taken from the older Flop ground station (scripts/gcs/ui/motor_widget.py): a drawing of the aircraft from above with each rotor where it physically is, live output
gauges, spinning blades, and hard limits on the test. Differences: this drone is Betaflight, so there is no per-motor MAVLink test; ARMING at a very low throttle makes the FC
run all four motors at idle, and the FC reports the four motor outputs it sends over the radio (flight-mode text, see nimbus_pc.crsf.decode_flight_mode).

What it tells you: the FC's output for each motor (microseconds, 1000 = stopped) and, once you mark which motors you SEE turning, whether the fault is in the FC or outside it
(ESC signal wire, ESC, motor connector/phases, motor). It runs on the throttle-ramp logic (gyro calibration disarmed, arm at zero, soft start), limited to MAX_PCT, and
stops by itself after AUTO_STOP_S, on a tilt, on a lost link, or when the drone lifts.
"""
from __future__ import annotations

import time
from typing import List, Optional

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QComboBox, QDoubleSpinBox, QGridLayout, QHBoxLayout, QLabel, QPushButton, QVBoxLayout, QWidget

from nimbus_core import topics as T
from . import theme
from .viz.drone_3d import Drone3DView

MAX_PCT = 10.0                     # hard ceiling of the test throttle (a hover needs about 70 %: this cannot lift the drone)
AUTO_STOP_S = 45.0
FRESH_S = 2.0                      # motor numbers older than this are shown as stale
# Betaflight default quad-X motor order (check it against YOUR wiring): number, label, position (right+, forward+)
MOTORS = [(1, "rear right", (+1.0, -1.0)), (2, "front right", (+1.0, +1.0)), (3, "rear left", (-1.0, -1.0)), (4, "front left", (-1.0, +1.0))]

def diagnose(outputs: Optional[List[int]], seen: List[Optional[bool]]) -> List[str]:
    """outputs: the four FC outputs in microseconds (None = no data); seen[i]: True = the pilot sees motor i+1 turning, False = not turning, None = not answered.
    Returns plain-language lines."""
    if outputs is None:
        return ["No motor numbers from the FC yet (not armed, no link, or the FC firmware without the motor read-out)."]
    out = []
    spread = max(outputs) - min(outputs)
    running = max(outputs) >= 1030
    if not running:
        out.append("The FC is sending no motor signal (all at 1000): arm first.")
    elif spread > 60:
        out.append(f"The FC's four outputs differ by {spread} us at a tiny throttle: it is correcting something (tilt or a wound-up integrator); level the drone and retry.")
    else:
        out.append(f"The FC sends the same signal to all four motors ({min(outputs)}..{max(outputs)} us).")
    for i, s in enumerate(seen):
        n = i + 1
        if s is False and running:
            if outputs[i] >= 1030 and spread <= 60:
                out.append(f"M{n}: the FC sends {outputs[i]} us (same as the others) but you see it NOT turning -> the fault is OUTSIDE the FC: M{n}'s ESC signal wire/solder pad, the ESC, "
                           f"the motor wires/connector, or the motor itself.")
            elif outputs[i] < 1030:
                out.append(f"M{n}: the FC itself sends only {outputs[i]} us: FC side (motor mapping/disabled).")
            else:
                out.append(f"M{n}: not turning while the FC sends {outputs[i]} us.")
    if running and all(s is True for s in seen):
        out.append("All four motors turn and the FC sends equal outputs: the motors are fine.")
    elif running and all(s is None for s in seen):
        out.append("Now look at each motor and mark below whether it turns.")
    return out


class MotorTab(QWidget):
    def __init__(self, win) -> None:
        super().__init__()
        self.win, self.model = win, win.model
        self.outputs: Optional[List[int]] = None; self.thr_us: Optional[int] = None; self.t_out = 0.0
        self._t_start: Optional[float] = None
        l = QVBoxLayout(self); l.setContentsMargins(0, 0, 0, 0); l.setSpacing(16)
        warn = QLabel("THIS ARMS THE DRONE: all four motors spin at idle (props on). Hold or tether the drone, keep hands and cables clear, someone on SAFE.")
        warn.setWordWrap(True); warn.setStyleSheet(f"background:transparent;color:{theme.RED};border:1px solid {theme.RED};padding:8px 12px;border-radius:4px;font-weight:700"); l.addWidget(warn)
        body = QHBoxLayout(); body.setSpacing(12); l.addLayout(body, 1)
        self.view = Drone3DView(); body.addWidget(self.view, 5)                             # left: the 3D drone (drag to orbit)
        self.view.motor_clicked.connect(self.view.set_selected)
        right = QVBoxLayout(); right.setSpacing(8); body.addLayout(right, 2); right.addStretch(0)               # right: controls, the pilot's check, the verdict
        row = QHBoxLayout(); row.setSpacing(8)
        row.addWidget(QLabel("Test throttle"))
        self.sp = QDoubleSpinBox(); self.sp.setRange(0.0, MAX_PCT); self.sp.setSingleStep(0.5); self.sp.setDecimals(1); self.sp.setSuffix(" %"); self.sp.setValue(1.0)
        self.sp.setToolTip(f"0 to {MAX_PCT:g} %. About 70 % is needed to hover, so this cannot lift the drone. Changes apply immediately while running.")
        self.sp.valueChanged.connect(self._on_throttle); row.addWidget(self.sp); row.addStretch(1)
        right.addLayout(row)
        self.btn_arm = QPushButton("ARM + SPIN"); self.btn_arm.setObjectName("primary"); self.btn_arm.setMinimumHeight(38); self.btn_arm.clicked.connect(self.on_arm); right.addWidget(self.btn_arm)
        self.btn_stop = QPushButton("STOP / DISARM"); self.btn_stop.setObjectName("ghost"); self.btn_stop.setMinimumHeight(38); self.btn_stop.clicked.connect(self.on_stop); right.addWidget(self.btn_stop)
        self.note = QLabel(""); self.note.setWordWrap(True); right.addWidget(self.note)
        self.status = QLabel("idle"); self.status.setWordWrap(True); right.addWidget(self.status)
        g = QGridLayout(); g.setHorizontalSpacing(8); g.setVerticalSpacing(2)
        self.combo: List[QComboBox] = []
        for i, (n, lab, _pos) in enumerate(MOTORS):
            g.addWidget(QLabel(f"M{n} ({lab})"), (i // 2) * 2, i % 2)
            c = QComboBox(); c.addItems(["? (not checked)", "turns", "NOT turning"]); c.currentIndexChanged.connect(self.refresh); self.combo.append(c); g.addWidget(c, (i // 2) * 2 + 1, i % 2)
        right.addLayout(g)
        self.verdict = QLabel(""); self.verdict.setWordWrap(True); self.verdict.setAlignment(Qt.AlignmentFlag.AlignTop); self.verdict.setStyleSheet("padding:2px"); right.addWidget(self.verdict, 1)
        win.model.core.bus.subscribe(T.TELEMETRY, self._on_tel)

    # --- data -----------------------------------------------------------------------------
    def _on_tel(self, msg) -> None:
        name, d = msg
        if name == "flight_mode" and "motors" in d:
            self.outputs, self.thr_us, self.t_out = list(d["motors"]), d.get("thr_us"), time.monotonic()

    def running(self) -> bool:
        return self.model.core.ramp.phase in ("arming", "ramping")

    # --- actions --------------------------------------------------------------------------
    def _on_throttle(self, _v=None) -> None:
        if self.running():
            v = self.sp.value() / 100.0
            self.model.core.ramp.cfg.start_thr = self.model.core.ramp.cfg.cap_thr = v

    def _block_reason(self) -> str:
        m = self.model
        if not m.connected:
            return "Connect to the drone first."
        if m.core.autonomy.phase != "idle" or self.running():
            return "A flight or test is already running."
        return ""

    def _note(self, text: str, level: str = "ok") -> None:
        col = {"ok": theme.ACC, "warning": theme.AMB, "error": theme.RED}.get(level, theme.TXT)
        self.note.setText(text); self.note.setStyleSheet(f"padding:2px;color:{col}")

    def on_arm(self) -> None:
        m = self.model
        why = self._block_reason()
        if why:
            self._note(why, "warning"); return
        if m.source != "external":
            m.set_source("external"); self.win._set_combo(self.win.source_box, "external")
        if not m.allow_arm:
            m.set_allow_arm(True); self.win.chk_arm.blockSignals(True); self.win.chk_arm.setChecked(True); self.win.chk_arm.blockSignals(False)
        from nimbus_core.throttle_ramp import RampConfig
        v = min(self.sp.value(), MAX_PCT) / 100.0
        m.core.ramp.cfg = RampConfig(start_thr=v, cap_thr=v, rate_per_s=0.0, hold_at_cap_s=AUTO_STOP_S, lift_height_m=0.12, tilt_stop_deg=15.0)
        self.outputs = None
        if not m.core.ramp.start():
            self._note("Cannot start: arming must be allowed and the controls source external.", "error"); return
        self._note("Motor test started.", "ok")
        self._t_start = time.monotonic()

    def on_stop(self) -> None:
        self.model.core.ramp.stop("operator")

    # --- display --------------------------------------------------------------------------
    def refresh(self, *_a) -> None:
        run = self.running(); ramp = self.model.core.ramp
        fresh = self.outputs is not None and time.monotonic() - self.t_out < FRESH_S
        self.view.set_outputs(list(self.outputs) if fresh else None, not fresh)
        seen = [None if c.currentIndex() == 0 else (c.currentIndex() == 1) for c in self.combo]
        self.view.set_seen(seen)
        why = self._block_reason()
        self.btn_arm.setEnabled(not why); self.btn_stop.setEnabled(run)
        if why:
            self._note(why, "warning")
        elif self.note.text() == "Connect to the drone first." or self.note.text().startswith("A flight or test"):
            self._note("")
        if run:
            left = max(0.0, AUTO_STOP_S - (time.monotonic() - (self._t_start or time.monotonic())))
            self.status.setText(f"{ramp.phase.upper()}  throttle {ramp.thr * 100:.1f} %   (gyro calibration and arming take about 6 s first; stops itself in ~{left:.0f} s)")
        else:
            res = ramp.result
            self.status.setText("idle" if not res else f"stopped: {res.get('reason')}")
        lines = diagnose(list(self.outputs) if fresh else None, seen)
        self.verdict.setText("\n".join(lines))
        bad = any(("OUTSIDE" in s or "FC itself" in s or "differ" in s) for s in lines)
        self.verdict.setStyleSheet("padding:4px;color:%s" % (theme.RED if bad else theme.TXT))
