"""Shared video source (DJI O4 via CosmoStreamer URL, USB capture, none). Qt-light: no widgets here.

One instance lives on `win.video_source` (see `get_source`), used by VideoPage and VideoPip.
A capture thread (cv2.VideoCapture, any URL OpenCV/FFmpeg opens: rtsp://, http://.../mjpeg, udp://, a file)
keeps the latest BGR frame. Auto-reconnect with backoff. Tests inject an `opener` so no camera/network is needed.
"""
from __future__ import annotations

import json
import os
import threading
import time

try:                                                        # optional dependency
    import cv2                                              # type: ignore
except Exception:                                           # noqa: BLE001
    cv2 = None

KINDS = ("network", "usb", "none")
NO_CV2 = "OpenCV not installed (pip install opencv-python)"


def state_path() -> str:
    return os.environ.get("DRONEFORGE_VIDEO_STATE") or os.path.expanduser("~/.config/droneforge/video.json")


def load_choice() -> dict:
    try:
        with open(state_path()) as f:
            d = json.load(f)
        kind = d.get("kind", "none")
        return {"kind": kind if kind in KINDS else "none", "target": str(d.get("target", "")),
                "analog": bool(d.get("analog", False))}
    except Exception:                                       # noqa: BLE001
        return {"kind": "none", "target": "", "analog": False}


def save_choice(kind: str, target: str, analog: bool = False) -> None:
    try:
        p = state_path(); os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "w") as f:
            json.dump({"kind": kind, "target": target, "analog": analog}, f)
    except Exception:                                       # noqa: BLE001
        pass


class FakeCapture:
    """Test helper: wraps `fn() -> ndarray | None` (None = read failure) as a cv2-like capture."""
    def __init__(self, fn, opened: bool = True) -> None:
        self.fn = fn; self.opened = opened

    def isOpened(self) -> bool:
        return self.opened

    def read(self):
        f = self.fn()
        return (f is not None, f)

    def release(self) -> None:
        self.opened = False


def default_open(kind: str, target: str):
    if cv2 is None:
        raise RuntimeError(NO_CV2)
    if kind == "usb":
        digits = "".join(c for c in target if c.isdigit())
        return cv2.VideoCapture(int(digits)) if digits else cv2.VideoCapture(target)
    from .video_udp import open_udp, parse_udp_target         # `udp://0.0.0.0:3000` / `3000`: raw H.264/H.265 or MPEG-TS, recognised and relayed here
    port = parse_udp_target(target)
    if port is not None:
        return open_udp(port)
    # Network streams: lowest-latency FFmpeg options (no input buffering, no probing, no frame re-ordering delay). Set before the capture opens;
    # an owner-set OPENCV_FFMPEG_CAPTURE_OPTIONS always wins. UDP also gets a larger receive FIFO so bursts are not dropped.
    import os
    os.environ.setdefault("OPENCV_FFMPEG_CAPTURE_OPTIONS", "fflags;nobuffer|flags;low_delay|probesize;32768|analyzeduration;0|max_delay;0|timeout;5000000")
    if target.lower().startswith("udp://") and "fifo_size" not in target:
        target += ("&" if "?" in target else "?") + "fifo_size=1000000&overrun_nonfatal=1"
    cap = cv2.VideoCapture(target, cv2.CAP_FFMPEG)
    try:
        cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
    except Exception:
        pass
    return cap


class VideoSource:
    def __init__(self, opener=None, stall_s: float = 3.0, backoff=(1.0, 2.0, 4.0, 8.0), load: bool = True) -> None:
        self._opener = opener or default_open
        self.stall_s = stall_s; self.backoff = tuple(backoff)
        self.kind = "none"; self.target = ""; self.analog = False
        if load:
            c = load_choice(); self.kind, self.target, self.analog = c["kind"], c["target"], c["analog"]
        self._lock = threading.Lock()
        self._frame = None; self.frame_count = 0; self._last_t = 0.0; self._t0 = 0.0; self._fps_n = 0; self.fps = 0.0
        self._state = "stopped"; self.running = False
        self._thread = None; self._stop = threading.Event()
        if opener is None and cv2 is None:
            self._state = NO_CV2

    # ---- config
    def set_source(self, kind: str, target: str = "", analog: bool | None = None) -> None:
        if kind not in KINDS:
            kind = "none"
        was = self.running
        self.stop()
        self.kind, self.target = kind, target.strip()
        if analog is not None:
            self.analog = analog
        save_choice(self.kind, self.target, self.analog)
        if was and kind != "none":
            self.start()

    # ---- state
    @property
    def state(self) -> str:
        with self._lock:
            s = self._state
        if s == "live" and self.frame_age() > self.stall_s:
            return "stalled"
        return s

    def frame_age(self) -> float:
        return (time.monotonic() - self._last_t) if self._last_t else float("inf")

    def latest(self):
        with self._lock:
            return self._frame

    def _set(self, s: str) -> None:
        with self._lock:
            self._state = s

    # ---- run
    def start(self) -> None:
        if self.running:
            return
        if self.kind == "none" or (self.kind == "network" and not self.target):
            self._set("error: no source set" if self.kind != "none" else "stopped"); return
        if self._opener is default_open and cv2 is None:
            self._set(NO_CV2); return
        self._stop.clear(); self.running = True; self._set("connecting")
        self._thread = threading.Thread(target=self._run, daemon=True); self._thread.start()

    def stop(self) -> None:
        self._stop.set(); self.running = False
        t = self._thread
        if t is not None and t is not threading.current_thread():
            t.join(timeout=3)
        self._thread = None
        with self._lock:
            self._frame = None
            if not self._state.startswith("OpenCV"):
                self._state = "stopped"
        self._last_t = 0.0; self.fps = 0.0

    def _run(self) -> None:
        attempt = 0
        while not self._stop.is_set():
            self._set("connecting"); cap = None
            try:
                cap = self._opener(self.kind, self.target)
                if cap is None or not cap.isOpened():
                    raise RuntimeError("cannot open " + (self.target or "device"))
                attempt = 0; self._t0 = time.monotonic(); self._fps_n = 0
                while not self._stop.is_set():
                    ok, frame = cap.read()
                    if not ok or frame is None:
                        raise RuntimeError("lost frames")
                    now = time.monotonic()
                    with self._lock:
                        self._frame = frame; self.frame_count += 1; self._state = "live"
                    self._last_t = now; self._fps_n += 1
                    if now - self._t0 >= 1.0:
                        self.fps = self._fps_n / (now - self._t0); self._t0 = now; self._fps_n = 0
                    time.sleep(0.001)
            except Exception as e:                          # noqa: BLE001
                if self._stop.is_set():
                    break
                self._set(f"error: {e}")
            finally:
                try:
                    if cap is not None:
                        cap.release()
                except Exception:                           # noqa: BLE001
                    pass
            wait = self.backoff[min(attempt, len(self.backoff) - 1)]; attempt += 1
            self._stop.wait(wait)

    # ---- snapshot
    def snapshot_png(self, path: str) -> bool:
        f = self.latest()
        if f is None:
            return False
        try:
            os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
            if cv2 is not None:
                return bool(cv2.imwrite(path, f))
            from PyQt6.QtGui import QImage
            h, w = f.shape[:2]
            return QImage(f.tobytes(), w, h, 3 * w, QImage.Format.Format_BGR888).save(path, "PNG")
        except Exception:                                   # noqa: BLE001
            return False


def get_source(win) -> VideoSource:
    src = getattr(win, "video_source", None)
    if src is None:
        src = VideoSource(); win.video_source = src
    return src
