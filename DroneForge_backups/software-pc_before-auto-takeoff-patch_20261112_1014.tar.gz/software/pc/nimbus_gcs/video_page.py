"""VIDEO workspace: DJI O4 via CosmoStreamer URL / USB capture / analog (VTX settings (over the FC, MSP-over-CRSF), VRX channel scan (TX frame 0xE1) and a UVC/V4L2 preview.

No dialogs, no check boxes, no yes/no questions: every outcome is an inline colour-coded status line.
Nothing here arms or flies. Logic lives in nimbus_pc/vtx.py (Qt-free).
"""
from __future__ import annotations

import glob
import os
import threading
import time

from PyQt6.QtCore import QRectF, Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QColor, QImage, QPainter, QPixmap
from PyQt6.QtWidgets import QButtonGroup, QComboBox, QGridLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QSizePolicy, QVBoxLayout, QWidget

from nimbus_pc import vtx
from .video_pip import frame_to_pixmap
from .video_source import get_source, load_choice
from . import theme
from .components import Card

ACCENT, BAD, DIM, GOOD, WARN = theme.ACC, theme.RED, theme.DIM, theme.TXT, theme.AMB   # ok text = primary, caution amber, alarm red
VTX_COL_W = 54 * theme.GRID                                                              # 432 px side column (analog only)

SNAP_DIR = "/home/htic/Music/DroneForge/docs/video_snapshots"

NOT_CONNECTED = "Not connected: press Connect first."


def _card(title: str, meta: str = ""):
    c = Card(title, meta)
    return c, c.body


def _status(label: QLabel, text: str, color: str) -> None:
    label.setText(text); label.setFont(theme.f_body(13)); label.setStyleSheet(f"color:{QColor(color).name()};")


class ScanChart(QWidget):
    """48 vertical bars (6 bands x 8 channels), best channel highlighted."""
    def __init__(self) -> None:
        super().__init__()
        self.rows = None; self.best = None
        self.setMinimumHeight(150); self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

    def set_scan(self, payload) -> None:
        self.rows = vtx.parse_scan(bytes(payload)) if payload is not None else None
        self.best = vtx.best_channel(bytes(payload)) if self.rows else None
        self.update()

    def paintEvent(self, _e) -> None:
        p = QPainter(self); p.fillRect(self.rect(), QColor(theme.BG))
        w, h = self.width() - 12, self.height() - 22
        if not self.rows:
            p.setPen(QColor(DIM)); p.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, "No scan yet. Press Scan.")
            return
        bw = w / 48
        for i, (band, ch, _mhz, rssi) in enumerate(self.rows):
            hit = self.best is not None and (band, ch) == (self.best[0], self.best[1])
            bh = h * rssi / 255
            p.fillRect(QRectF(6 + i * bw + 1, 4 + h - bh, max(bw - 2, 1), bh), QColor(theme.TXT if hit else theme.ACC_DEEP))
            if ch == 1:
                p.setPen(QColor(DIM)); p.drawText(QRectF(6 + i * bw, h + 6, bw * 8, 14), Qt.AlignmentFlag.AlignLeft, f"band {band}")


class VideoView(QWidget):
    """Live frame (aspect kept) with an on-image status line."""
    def __init__(self) -> None:
        super().__init__()
        self.frame = None; self.text = ""; self.setMinimumHeight(260)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

    def set_frame(self, frame, text: str) -> None:
        self.frame = frame; self.text = text; self.update()

    def paintEvent(self, _e) -> None:
        p = QPainter(self); p.fillRect(self.rect(), QColor(theme.BG))
        if self.frame is not None:
            pm = frame_to_pixmap(self.frame, self.size())
            p.drawPixmap((self.width() - pm.width()) // 2, (self.height() - pm.height()) // 2, pm)
        p.setPen(QColor(DIM if self.frame is None else theme.TXT))
        r = self.rect().adjusted(10, 8, -10, -8)
        p.drawText(r, Qt.AlignmentFlag.AlignCenter if self.frame is None else (Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignBottom),
                   self.text if self.frame is not None else (self.text or "No video"))


class VideoPage(QWidget):
    config_ready = pyqtSignal(object)

    def __init__(self, win) -> None:
        super().__init__()
        self.win = win
        self.src = get_source(win)
        self._cfg = None
        root = QHBoxLayout(self); root.setContentsMargins(0, 0, 0, 0); root.setSpacing(theme.SP["m"])

        # --- VTX card
        c, v = _card("Video transmitter (VTX)")
        g = QGridLayout(); g.setHorizontalSpacing(theme.SP["s"])
        self.band = QComboBox(); self.channel = QComboBox(); self.power = QComboBox()
        for b in vtx.BANDS:
            self.band.addItem(vtx.BAND_NAMES[b], b)
        self.band.currentIndexChanged.connect(self._fill_channels)
        self._fill_channels(); self._fill_power(None)
        for i, (name, w) in enumerate((("Band", self.band), ("Channel", self.channel), ("Power", self.power))):
            k = QLabel(name.upper()); k.setObjectName("label"); g.addWidget(k, 0, i); g.addWidget(w, 1, i)
        v.addLayout(g)
        row = QHBoxLayout(); self.btn_read = QPushButton("Read"); self.btn_apply = QPushButton("Apply"); self.btn_apply.setObjectName("primary")
        self.btn_read.clicked.connect(self.read_vtx); self.btn_apply.clicked.connect(self.apply_vtx)
        row.addWidget(self.btn_read); row.addWidget(self.btn_apply); row.addStretch(1); v.addLayout(row)
        self.vtx_status = QLabel(""); self.vtx_status.setFont(theme.f_body(13)); self.vtx_status.setWordWrap(True); v.addWidget(self.vtx_status)
        self.config_ready.connect(self._on_config)

        # --- VRX scan card
        s, sv = _card("Receiver channel scan (VRX)")
        self.chart = ScanChart(); sv.addWidget(self.chart)
        row = QHBoxLayout(); self.btn_scan = QPushButton("Scan"); self.btn_scan.setObjectName("primary"); self.btn_scan.clicked.connect(self.scan)
        row.addWidget(self.btn_scan); row.addStretch(1); sv.addLayout(row)
        self.scan_status = QLabel(""); self.scan_status.setWordWrap(True); sv.addWidget(self.scan_status)

        # --- source bar + live view
        p, pv = _card("Video")
        row = QHBoxLayout(); row.setSpacing(8)
        self.source = QComboBox()
        self.source.addItem("DJI via CosmoStreamer (network URL)", "dji")
        self.source.addItem("USB capture device", "usb")
        self.source.addItem("Analog VTX/VRX (ELRS)", "analog")
        self.url = QLineEdit(); self.url.setPlaceholderText("udp://0.0.0.0:3000  (raw H.264/H.265 or MPEG-TS, detected automatically)  or  rtsp://\u2026  or  http://\u2026")
        self.device = QComboBox(); self.device.setMinimumContentsLength(16)
        self.btn_start = QPushButton("Start"); self.btn_start.setObjectName("primary"); self.btn_stop = QPushButton("Stop"); self.btn_snap = QPushButton("Snapshot")
        self.btn_start.clicked.connect(self.start_video); self.btn_stop.clicked.connect(self.stop_video)
        self.btn_snap.clicked.connect(self.snapshot)
        self.source.setVisible(False)                          # kept as the data model; the segmented buttons below drive it
        self.seg = QButtonGroup(self); self.seg.setExclusive(True)
        for i, (txt, _d) in enumerate((("DJI O4", "dji"), ("USB CAPTURE", "usb"), ("ANALOG", "analog"))):
            b = QPushButton(txt); b.setObjectName("seg"); b.setCheckable(True); self.seg.addButton(b, i)
            b.clicked.connect(lambda _c=False, i=i: self.source.setCurrentIndex(i)); row.addWidget(b)
        row.addSpacing(theme.SP["m"]); row.addWidget(self.source); row.addWidget(self.url, 1); row.addWidget(self.device, 1)
        row.addWidget(self.btn_start); row.addWidget(self.btn_stop); row.addWidget(self.btn_snap); pv.addLayout(row)
        self.view = VideoView(); pv.addWidget(self.view, 1)
        self.video_card = p
        self.video_status = QLabel(""); self.video_status.setWordWrap(True); pv.addWidget(self.video_status)
        self.frame = self.view                              # kept for older callers

        self.top = QWidget(); top = QVBoxLayout(self.top); top.setContentsMargins(0, 0, 0, 0); top.setSpacing(theme.SP["m"])
        top.addWidget(c); top.addWidget(s, 1); self.top.setFixedWidth(VTX_COL_W)
        root.addWidget(p, 1); root.addWidget(self.top)
        self.cards = (c, s)
        self.refresh_devices()
        ch = load_choice()
        self.source.setCurrentIndex(self.source.findData("analog" if ch["analog"] else ("usb" if ch["kind"] == "usb" else "dji")))
        if ch["kind"] == "network":
            self.url.setText(ch["target"])
        elif ch["kind"] == "usb" and self.device.findData(ch["target"]) >= 0:
            self.device.setCurrentIndex(self.device.findData(ch["target"]))
        self.source.currentIndexChanged.connect(self._source_changed)
        self._source_changed()
        self._timer = QTimer(self); self._timer.timeout.connect(self._tick); self._timer.start(200)
        self._tick()

    # ---- helpers
    def _sess(self):
        m = self.win.model
        return getattr(m.core, "sess", None) if getattr(m, "connected", False) else None

    def _fill_channels(self, *_a) -> None:
        band = self.band.currentData(); cur = self.channel.currentIndex()
        self.channel.clear()
        for ch in range(1, 9):
            self.channel.addItem(f"{ch}  ({vtx.freq_mhz(band, ch)} MHz)", ch)
        self.channel.setCurrentIndex(max(cur, 0))

    def _fill_power(self, levels) -> None:
        cur = self.power.currentData()
        self.power.clear()
        for lvl, text in vtx.power_choices(levels):
            self.power.addItem(text, lvl)
        i = self.power.findData(cur)
        self.power.setCurrentIndex(i if i >= 0 else 0)

    def _tick(self) -> None:
        self._update_video()
        sess = self._sess()
        for b in (self.btn_read, self.btn_apply, self.btn_scan):
            b.setEnabled(sess is not None)
            b.setToolTip("" if sess else NOT_CONNECTED)
        if sess is None:
            _status(self.vtx_status, NOT_CONNECTED, WARN); _status(self.scan_status, NOT_CONNECTED, WARN)
        else:
            if self.vtx_status.text() == NOT_CONNECTED:
                _status(self.vtx_status, "Connected. Press Read to get the VTX settings.", DIM)
            if self.scan_status.text() == NOT_CONNECTED:
                _status(self.scan_status, "Connected. Press Scan.", DIM)
            self._update_scan()

    # ---- VTX
    def _do_read(self):
        sess = self._sess()
        if sess is None:
            return None
        reply = sess.request_msp(vtx.commands.MSP_VTX_CONFIG)
        return vtx.parse_config(reply["payload"]) if reply else None

    def read_vtx(self) -> None:
        if self._sess() is None:
            _status(self.vtx_status, NOT_CONNECTED, WARN); return
        _status(self.vtx_status, "Reading the VTX settings from the FC...", DIM)
        self.btn_read.setEnabled(False)
        threading.Thread(target=lambda: self.config_ready.emit(self._do_read()), daemon=True).start()

    def _on_config(self, cfg) -> None:
        self.btn_read.setEnabled(self._sess() is not None)
        if not cfg:
            _status(self.vtx_status, "No reply from the FC. Check that a VTX is set up on it (Betaflight VTX table) and the link is up.", BAD); return
        self._cfg = cfg
        self._fill_power(cfg["table_power_levels"] if cfg["table_available"] else None)
        if cfg["band_letter"]:
            self.band.setCurrentIndex(self.band.findData(cfg["band_letter"]))
        if 1 <= cfg["channel"] <= 8:
            self.channel.setCurrentIndex(cfg["channel"] - 1)
        i = self.power.findData(cfg["power_level"])
        if i >= 0:
            self.power.setCurrentIndex(i)
        ready = "" if cfg["device_ready"] else " VTX device not ready."
        _status(self.vtx_status, f"VTX: band {cfg['band_letter'] or '?'} channel {cfg['channel']}, {cfg['frequency_mhz']} MHz, power level {cfg['power_level']}.{ready}",
                GOOD if cfg["device_ready"] else WARN)

    def apply_vtx(self) -> None:
        sess = self._sess()
        if sess is None:
            _status(self.vtx_status, NOT_CONNECTED, WARN); return
        band, ch, lvl = self.band.currentData(), self.channel.currentData(), self.power.currentData()
        try:
            for f in vtx.set_frames(band, ch, lvl):
                sess.send_frame(f)
        except (ValueError, OSError) as e:
            _status(self.vtx_status, f"Not sent: {e}", BAD); return
        _status(self.vtx_status, f"Sent band {band} channel {ch} ({vtx.freq_mhz(band, ch)} MHz), power {self.power.currentText()}. Press Read to confirm what the VTX took.", GOOD)

    # ---- VRX
    def scan(self) -> None:
        sess = self._sess()
        if sess is None:
            _status(self.scan_status, NOT_CONNECTED, WARN); return
        try:
            sess.send_frame(vtx.scan_frame())
        except OSError as e:
            _status(self.scan_status, f"Not sent: {e}", BAD); return
        _status(self.scan_status, "Scan requested. Results arrive after the receiver finishes a pass.", DIM)

    def _update_scan(self) -> None:
        d = getattr(self.win.model.state, "decoded", {}).get("vrx_top_channels")
        if not d:
            return
        payload = bytes(d["rssi_by_freq_order"])
        if self.chart.rows is not None and bytes(r[3] for r in self.chart.rows) == payload:
            return
        self.chart.set_scan(payload)
        b = self.chart.best
        if b:
            _status(self.scan_status, f"Best channel: band {b[0]} channel {b[1]} ({b[2]} MHz), strength {b[3]}/255. Order of the bars is inferred (UNVERIFIED).", GOOD)
        else:
            _status(self.scan_status, "Scan received but every channel reads 0: no receiver signal.", WARN)

    # ---- video
    def _kind(self) -> str:
        return "network" if self.source.currentData() == "dji" else "usb"

    def _target(self) -> str:
        return self.url.text().strip() if self._kind() == "network" else (self.device.currentData() or "")

    def _source_changed(self, *_a) -> None:
        mode = self.source.currentData()
        b = self.seg.button(self.source.currentIndex())
        if b is not None: b.setChecked(True)
        self.url.setVisible(mode == "dji"); self.device.setVisible(mode != "dji")
        self.top.setVisible(mode == "analog")
        self.src.set_source(self._kind(), self._target(), analog=(mode == "analog"))
        self._tick()

    def refresh_devices(self) -> None:
        self.device.clear()
        for path in sorted(glob.glob("/dev/video*")):
            self.device.addItem(path, path)

    def start_video(self) -> None:
        self.src.set_source(self._kind(), self._target(), analog=(self.source.currentData() == "analog"))
        self.src.start(); self._tick()

    def stop_video(self) -> None:
        self.src.stop(); self._tick()

    def snapshot(self) -> None:
        if self.src.latest() is None:
            _status(self.video_status, "No frame to save: start the video first.", WARN); return
        os.makedirs(SNAP_DIR, exist_ok=True)
        path = os.path.join(SNAP_DIR, time.strftime("%Y-%m-%d_%H%M%S") + "_snapshot.png")
        if self.src.snapshot_png(path):
            _status(self.video_status, f"Saved {path}", GOOD)
        else:
            _status(self.video_status, "Could not write the snapshot.", BAD)

    def _update_video(self) -> None:
        st = self.src.state; run = self.src.running
        self.btn_start.setEnabled(not run); self.btn_stop.setEnabled(run)
        self.btn_snap.setEnabled(self.src.latest() is not None)
        if st == "live":
            _status(self.video_status, f"Live: {self.src.fps:.0f} fps, frame age {self.src.frame_age():.1f} s.", GOOD)
        elif st == "stalled":
            _status(self.video_status, f"Stalled: no frame for {self.src.frame_age():.0f} s. Reconnecting.", WARN)
        elif st == "connecting":
            _status(self.video_status, "Connecting\u2026", DIM)
        elif st.startswith("error") or st.startswith("OpenCV"):
            _status(self.video_status, st[:1].upper() + st[1:], BAD if st.startswith("error") else WARN)
        else:
            hint = {"dji": "Enter the stream address, e.g. udp://0.0.0.0:3000 (the port CosmoStreamer sends to; raw H.264/H.265 is detected and handled here), then press Start.",
                    "usb": "Choose the capture device and press Start." if self.device.count() else "No video device found. Plug in a UVC capture dongle.",
                    "analog": "Choose the analog receiver's capture device and press Start."}[self.source.currentData()]
            _status(self.video_status, hint, DIM)
        self.video_card.set_meta(f"{st.upper()}  {self.src.fps:.0f} FPS" if st in ("live", "stalled") else st.upper()[:24])
        self.view.set_frame(self.src.latest(), f"{st}  {self.src.fps:.0f} fps  age {self.src.frame_age():.1f} s" if st in ("live", "stalled") else st)

    def closeEvent(self, e) -> None:
        super().closeEvent(e)
