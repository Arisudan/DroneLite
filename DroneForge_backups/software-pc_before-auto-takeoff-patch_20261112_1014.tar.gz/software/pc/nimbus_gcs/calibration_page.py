"""Calibration page (SETUP > Calibration): level, gyro and battery cards. Status + one button + inline result line each.
No dialogs, no tick boxes; refusals appear inline and buttons are disabled when not allowed."""
from __future__ import annotations

import dataclasses

from PyQt6.QtCore import QTimer
from PyQt6.QtWidgets import QHBoxLayout, QLabel, QPushButton, QVBoxLayout, QWidget

from . import theme
from .components import Card

from nimbus_core.battery_cal import calibrate_battery_scale
from nimbus_core.calibration import Calibrator, LEVEL_UNAVAILABLE
from nimbus_gcs.model import battery_percent

_COL = {"green": theme.ACC, "amber": theme.AMB, "red": theme.RED, "grey": theme.DIM}
_TILT = {"green": theme.ACC, "amber": theme.AMB, "red": theme.RED}


def _card(title: str, hint: str):
    f = Card(title); v = f.body
    h = QLabel(hint); h.setWordWrap(True); h.setObjectName("dim")
    v.addWidget(h)
    return f, v


def _label() -> QLabel:
    l = QLabel(""); l.setWordWrap(True); return l


class CalibrationPage(QWidget):
    def __init__(self, win):
        super().__init__()
        self.win = win
        self.cal = Calibrator(win.model.core)
        root = QVBoxLayout(self); root.setContentsMargins(0, 0, 0, 0); root.setSpacing(16)

        f, v = _card("Level (accelerometer)", "Place the drone on a level surface, battery connected, FC disarmed.")
        self.lbl_tilt = _label(); self.btn_level = QPushButton("Calibrate level"); self.btn_level.setObjectName("primary"); self.res_level = _label()
        v.addWidget(self.lbl_tilt); v.addWidget(self.btn_level); v.addWidget(self.res_level)
        self.btn_level.clicked.connect(lambda _=False: self._level())
        root.addWidget(f)

        f, v = _card("Gyro", "Keeps the drone still for a few seconds. Disarmed only; the throttle stays at minimum.")
        self.lbl_gyro = _label(); self.btn_gyro = QPushButton("Calibrate gyro (keep the drone still)"); self.btn_gyro.setObjectName("primary"); self.res_gyro = _label()
        v.addWidget(self.lbl_gyro); v.addWidget(self.btn_gyro); v.addWidget(self.res_gyro)
        self.btn_gyro.clicked.connect(lambda _=False: self._gyro())
        root.addWidget(f)

        f, v = _card("Battery", "With a fully charged, resting pack plugged in, set the correction factor so the reading matches 4.16 V per cell.")
        self.lbl_batt = _label(); self.res_batt = _label()
        row = QHBoxLayout()
        self.btn_cal = QPushButton("Pack is fully charged: calibrate"); self.btn_cal.setObjectName("primary"); self.btn_cal_reset = QPushButton("Reset factor")
        row.addWidget(self.btn_cal); row.addWidget(self.btn_cal_reset); row.addStretch(1)
        v.addWidget(self.lbl_batt); v.addLayout(row); v.addWidget(self.res_batt)
        self.btn_cal.clicked.connect(lambda _=False: self._calibrate())
        self.btn_cal_reset.clicked.connect(lambda _=False: self._reset())
        root.addWidget(f); root.addStretch(1)

        self._timer = QTimer(self); self._timer.setInterval(500); self._timer.timeout.connect(self.refresh)
        self.refresh()

    # --- helpers ------------------------------------------------------------------------------
    @staticmethod
    def _say(lbl: QLabel, text: str, ok: bool) -> None:
        lbl.setText(text); lbl.setStyleSheet(f"color:{_COL['green'] if ok else _COL['red']}; font-weight:600;")

    def _core(self):
        return self.win.model.core

    def _cells(self) -> int:
        return getattr(getattr(getattr(self._core(), "safety", None), "cfg", None), "cells", 4)

    def _scale(self) -> float:
        try:
            return float(self._core().autonomy.settings.battery_scale)
        except (AttributeError, TypeError, ValueError):
            return 1.0

    # --- refresh ------------------------------------------------------------------------------
    def refresh(self) -> None:
        s = self.cal.level_status()
        if s["pitch"] is None:
            self.lbl_tilt.setText("Rest tilt: no attitude data yet"); self.lbl_tilt.setStyleSheet(f"color:{_COL['grey']};")
        else:
            self.lbl_tilt.setText(f"Rest tilt: pitch {s['pitch']:+.1f} deg, roll {s['roll']:+.1f} deg  (level is within 0.5 deg)  " + {"green": "LEVEL", "amber": "SLIGHTLY TILTED", "red": "TILTED"}[s['colour']])
            self.lbl_tilt.setStyleSheet(f"color:{_TILT[s['colour']]}; font-weight:700;")
        self.btn_level.setEnabled(bool(s["available"]))
        if not s["available"] and not self.res_level.text():
            self._say(self.res_level, LEVEL_UNAVAILABLE, False)

        why = self.cal.refusal() if not self.cal.running else None
        self.btn_gyro.setEnabled(why is None and not self.cal.running)
        if self.cal.running or self.cal.result:
            self._say(self.res_gyro, self.cal.result, not self.cal.result.startswith(("Gyro calibration stopped", "Gyro calibration failed")))
        elif why:
            self._say(self.res_gyro, why, False)
        else:
            self.res_gyro.setText(""); 
        self.lbl_gyro.setText("Ready." if why is None and not self.cal.running else "")

        m = self.win.model
        raw = m.raw_vbat() if hasattr(m, "raw_vbat") else None
        f = self._scale()
        if raw is None:
            self.lbl_batt.setText(f"Reading: no battery telemetry   Factor: {f:.2f}")
        else:
            cv = raw * f
            self.lbl_batt.setText(f"Raw reading {raw:.2f} V   Factor {f:.2f}   Corrected {cv:.2f} V ({battery_percent(cv, self._cells()):.0f} %)")
        sim = getattr(m, "is_sim", False)
        self.btn_cal.setEnabled(raw is not None and not sim)
        self.btn_cal_reset.setEnabled(abs(f - 1.0) > 1e-9)

    # --- actions ------------------------------------------------------------------------------
    def _level(self) -> None:
        ok, msg = self.cal.calibrate_level(); self._say(self.res_level, msg, ok)

    def _gyro(self) -> None:
        ok, msg = self.cal.calibrate_gyro(); self._say(self.res_gyro, msg, ok); self.refresh()

    def _apply(self, **values) -> bool:
        core = self._core()
        res = core.director.apply_settings(dataclasses.replace(core.autonomy.settings, **values))
        if not res.ok:
            self._say(self.res_batt, str(res.message), False)
        self.refresh()
        return bool(res.ok)

    def _calibrate(self) -> None:
        m = self.win.model
        if getattr(m, "is_sim", False):
            return self._say(self.res_batt, "Cannot calibrate: this is the simulator, not a real battery reading.", False)
        raw, cells = (m.raw_vbat() if hasattr(m, "raw_vbat") else None), self._cells()
        if raw is None:
            return self._say(self.res_batt, "Cannot calibrate: no battery telemetry (connect with the pack plugged in).", False)
        if raw < 3.0 * cells:
            return self._say(self.res_batt, f"Cannot calibrate: the FC reads {raw:.1f} V, too low for a charged {cells}S pack "
                             f"(needs at least {3.0 * cells:.1f} V). Charge the pack first.", False)
        f = round(calibrate_battery_scale(raw, cells), 2)
        if self._apply(battery_scale=f):
            self._say(self.res_batt, f"Factor {f:.2f}: {raw:.1f} V reads as {raw * f:.1f} V ({raw * f / cells:.2f} V/cell)", True)

    def _reset(self) -> None:
        if self._apply(battery_scale=1.0):
            self._say(self.res_batt, "Factor reset to 1.00", True)

    def showEvent(self, e):
        self._timer.start(); self.refresh(); super().showEvent(e)

    def hideEvent(self, e):
        self._timer.stop(); super().hideEvent(e)
