"""UDP video input for the GCS: type in `udp://0.0.0.0:3000` (or just `3000`) and press Start.

CosmoStreamer / DJI O4 send RAW H.264 or H.265 over UDP: no container, no timing. OpenCV cannot open that by itself, so this module
  1. listens on the port for a moment and recognises the stream: MPEG-TS, raw H.264, raw H.265 (RTP is reported as unsupported),
  2. for raw video starts a managed `ffmpeg -c copy` helper (no re-encoding, lowest latency, wall-clock timestamps) that re-wraps it as MPEG-TS on a free
     localhost port, and opens that with OpenCV; the helper is stopped when the capture is released,
  3. for MPEG-TS opens the port directly.
No separate relay terminal is needed. Qt-free; the unit tests inject packets, so no network or ffmpeg is needed for the classifier.
"""
from __future__ import annotations

import re
import shutil
import socket
import subprocess
import time
from typing import Iterable, List, Optional, Tuple

try:
    import cv2                                               # type: ignore
except Exception:                                            # noqa: BLE001
    cv2 = None

CAPTURE_OPTIONS = "fflags;nobuffer|flags;low_delay|probesize;32768|analyzeduration;0|max_delay;0|timeout;5000000"


# --------------------------------------------------------------------------------------------- address parsing
def parse_udp_target(target: str) -> Optional[int]:
    """`udp://host:port`, `host:port` or `port` -> the UDP port to listen on (we always bind all interfaces); None if it is not a UDP address."""
    t = target.strip()
    m = re.fullmatch(r"(?:udp://)?(?:[\w.\-\[\]:*]*:)?(\d{2,5})(?:\?.*)?", t, re.I)
    if not m or not (t.lower().startswith("udp://") or re.fullmatch(r"(?:[\d.*]+:)?\d{2,5}", t)):
        return None
    port = int(m.group(1))
    return port if 1 <= port <= 65535 else None


# --------------------------------------------------------------------------------------------- classifier
def _nal_headers(data: bytes) -> Iterable[Tuple[int, int]]:
    """Yield (byte0, byte1) after every Annex-B start code (00 00 01)."""
    i = 0
    while True:
        i = data.find(b"\x00\x00\x01", i)
        if i < 0 or i + 4 >= len(data):
            return
        yield data[i + 3], data[i + 4]
        i += 3


def classify(packets: List[bytes]) -> str:
    """'mpegts' | 'rtp' | 'h264' | 'hevc' | 'unknown' from the first UDP payloads."""
    if not packets:
        return "unknown"
    ts = sum(1 for p in packets if len(p) >= 188 and len(p) % 188 == 0 and all(p[k] == 0x47 for k in range(0, len(p), 188)))
    if ts >= max(1, len(packets) // 2):
        return "mpegts"
    if sum(1 for p in packets if len(p) > 12 and p[0] >> 6 == 2 and p[1] & 0x7F in (96, 97, 98, 99, 100, 101, 102, 103)) >= max(1, len(packets) // 2) \
            and not any(p[:3] == b"\x00\x00\x01" or p[:4] == b"\x00\x00\x00\x01" for p in packets):
        return "rtp"
    blob = b"".join(packets)
    h264 = h265 = 0
    for b0, b1 in _nal_headers(blob):
        if b0 & 0x80 == 0:
            t = b0 & 0x1F
            if t in (7, 8):
                h264 += 3
            elif t in (5, 1, 6, 9):
                h264 += 1
        if b0 & 0x81 == 0 and (b1 & 0x07) == 1:
            t = (b0 >> 1) & 0x3F
            if t in (32, 33, 34):
                h265 += 3
            elif t in (19, 20, 21, 1, 0, 35, 39, 40):
                h265 += 1
    if h264 == h265 == 0:
        return "unknown"
    return "hevc" if h265 > h264 else "h264"


# --------------------------------------------------------------------------------------------- helpers
def local_addresses() -> List[str]:
    try:
        out = subprocess.run(["hostname", "-I"], capture_output=True, text=True, timeout=2).stdout.split()
        return [a for a in out if ":" not in a]
    except Exception:                                        # noqa: BLE001
        return []


def sniff(port: int, seconds: float = 6.0, want: int = 40) -> Tuple[str, int]:
    """Listen on `port`; returns (kind, packets_seen). Stops early once the kind is certain (SPS/PPS or TS sync seen)."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        s.bind(("0.0.0.0", port))
    except OSError as e:
        s.close()
        raise RuntimeError(f"UDP port {port} is busy ({e.strerror}): close ffplay / another relay using it") from e
    s.settimeout(0.5); pk: List[bytes] = []; t0 = time.monotonic()
    try:
        while time.monotonic() - t0 < seconds:
            try:
                d, _a = s.recvfrom(65535)
            except socket.timeout:
                continue
            pk.append(d)
            if len(pk) >= 8 and len(pk) % 8 == 0:
                k = classify(pk)
                if k in ("mpegts", "rtp") or (k in ("h264", "hevc") and len(pk) >= 16):
                    return k, len(pk)
            if len(pk) >= want:
                break
    finally:
        s.close()
    return classify(pk), len(pk)


def _free_port() -> int:
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close()
    return p


class RelayedCapture:
    """cv2-like capture that also owns the ffmpeg helper process."""

    def __init__(self, cap, proc: Optional[subprocess.Popen]) -> None:
        self.cap, self.proc = cap, proc

    def isOpened(self) -> bool:
        return bool(self.cap is not None and self.cap.isOpened())

    def read(self):
        return self.cap.read()

    def get(self, *a):
        return self.cap.get(*a)

    def set(self, *a):
        return self.cap.set(*a)

    def release(self) -> None:
        try:
            if self.cap is not None:
                self.cap.release()
        finally:
            if self.proc is not None and self.proc.poll() is None:
                self.proc.terminate()
                try:
                    self.proc.wait(2)
                except Exception:                            # noqa: BLE001
                    self.proc.kill()


def _open_cv(url: str):
    import os
    os.environ.setdefault("OPENCV_FFMPEG_CAPTURE_OPTIONS", CAPTURE_OPTIONS)
    cap = cv2.VideoCapture(url, cv2.CAP_FFMPEG)
    try:
        cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
    except Exception:                                        # noqa: BLE001
        pass
    return cap


def open_udp(port: int, sniffer=sniff, popen=subprocess.Popen, opener=None):
    """Return a capture for the UDP stream on `port` or raise RuntimeError with a plain-words reason (injectable parts for tests)."""
    if cv2 is None and opener is None:
        raise RuntimeError("OpenCV (cv2) is not installed")
    kind, n = sniffer(port)
    if n == 0:
        ips = ", ".join(local_addresses()) or "this PC's address"
        raise RuntimeError(f"no data on UDP port {port}: set the streamer's destination to this PC ({ips}) port {port}, and join the streamer's Wi-Fi")
    if kind == "rtp":
        raise RuntimeError("the stream is RTP: choose raw H.264/H.265 or MPEG-TS in the streamer (RTP needs an SDP file)")
    if kind == "unknown":
        raise RuntimeError(f"UDP data on port {port} is not H.264, H.265 or MPEG-TS ({n} packets seen)")
    opener = opener or _open_cv
    if kind == "mpegts":
        return RelayedCapture(opener(f"udp://0.0.0.0:{port}?fifo_size=1000000&overrun_nonfatal=1"), None)
    ff = shutil.which("ffmpeg")
    if not ff:
        raise RuntimeError("ffmpeg is not installed (sudo apt install ffmpeg): needed to read raw H.264/H.265")
    local = _free_port()
    cmd = [ff, "-hide_banner", "-loglevel", "error", "-fflags", "nobuffer", "-flags", "low_delay", "-probesize", "32768", "-analyzeduration", "0",
           "-use_wallclock_as_timestamps", "1", "-f", kind, "-i", f"udp://0.0.0.0:{port}?fifo_size=1000000&overrun_nonfatal=1",
           "-c", "copy", "-f", "mpegts", f"udp://127.0.0.1:{local}?pkt_size=1316"]
    proc = popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(0.4)
    if proc.poll() is not None:
        raise RuntimeError("the ffmpeg helper stopped at once (is another program using UDP port %d?)" % port)
    cap = opener(f"udp://127.0.0.1:{local}")
    if cap is None or not cap.isOpened():
        RelayedCapture(cap, proc).release()
        raise RuntimeError(f"raw {kind} stream seen ({n} packets) but no picture decoded: wrong codec setting in the streamer, or waiting for a key frame")
    return RelayedCapture(cap, proc)
