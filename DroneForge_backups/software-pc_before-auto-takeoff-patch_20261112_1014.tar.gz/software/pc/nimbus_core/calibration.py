"""Qt-free sensor calibration helpers: level status, gyro calibration gesture, level calibration (not available over the radio).

The only controls this module ever produces are Controls() (everything at minimum, arm LOW) and the gyro-cal gesture
Controls(pitch=-1, yaw=-1) (throttle minimum, arm LOW). It never requests arm.
"""
from __future__ import annotations

import math
import threading
import time
from typing import Optional

from nimbus_pc.sender import Controls

GYRO_GESTURE_S = 1.6            # same as the start sequence (autonomy / throttle_ramp): pitch=-1 yaw=-1 for 1.6 s ...
GYRO_STILL_S = 4.0              # ... then stillness; autonomy.GYRO_CAL_S
LEVEL_UNAVAILABLE = ("Level calibration over the radio is not available yet: "
                     "use tools_scripts/fc_config (acc level calibration script)")
GREEN_DEG, AMBER_DEG = 0.5, 1.5


def tilt_colour(deg: Optional[float]) -> str:
    if deg is None:
        return "grey"
    d = abs(deg)
    return "green" if d < GREEN_DEG else "amber" if d < AMBER_DEG else "red"


class Calibrator:
    def __init__(self, core, clock=time.monotonic, sleep=time.sleep) -> None:
        self.core, self._clock, self._sleep = core, clock, sleep
        self._thread: Optional[threading.Thread] = None
        self.running = False
        self.result = ""                      # last gyro result line
        self.last_controls = Controls()       # what the last gyro gesture step produced (for tests)

    # --- level --------------------------------------------------------------------------------
    def level_status(self) -> dict:
        """Rest tilt in degrees from the FC attitude: {'pitch','roll','colour','available','reason'}."""
        att = None
        try:
            att = self.core.state.decoded.get("attitude")
        except AttributeError:
            pass
        p = math.degrees(att["pitch_rad"]) if att else None
        r = math.degrees(att["roll_rad"]) if att else None
        worst = None if p is None else max(abs(p), abs(r))
        return {"pitch": p, "roll": r, "colour": tilt_colour(worst), "available": False, "reason": LEVEL_UNAVAILABLE}

    def calibrate_level(self) -> tuple[bool, str]:
        # The FC's accelerometer-calibration stick command is not verified for this firmware, and some Betaflight
        # variants need throttle HIGH for it, which is forbidden here. No safe radio path: refuse, send nothing.
        return False, LEVEL_UNAVAILABLE

    # --- gyro ---------------------------------------------------------------------------------
    def refusal(self) -> Optional[str]:
        c = self.core
        if not getattr(c, "connected", False):
            return "Not connected: connect to the drone first."
        if getattr(c, "state_source", "live") in ("sim", "bench"):
            return "Not available in the simulator or bench mode: there is no real gyro."
        au = getattr(c, "autonomy", None)
        if au is not None and (getattr(au, "fc_armed", False)):
            return "The FC is armed: disarm first."
        if au is not None and getattr(au, "phase", "idle") != "idle":
            return "Autonomy is busy: stop it first."
        if getattr(getattr(c, "ramp", None), "phase", "idle") not in ("idle", "done"):
            return "A throttle ramp is running: stop it first."
        if self.running:
            return "Gyro calibration is already running."
        if getattr(c, "source", "idle") not in ("idle", "external"):
            return "Controls are in use by another source: set the source to idle first."
        return None

    def calibrate_gyro(self) -> tuple[bool, str]:
        why = self.refusal()
        if why:
            return False, why
        self.running, self.result = True, "Gyro calibration: keep the drone still (4 s)"
        self._prev_source = getattr(self.core, "source", "idle")
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        return True, self.result

    def gesture(self, el: float) -> Controls:
        """Controls for el seconds into the calibration: the gesture for 1.6 s, then everything at rest. Never arms."""
        return Controls(pitch=-1.0, yaw=-1.0) if el < GYRO_GESTURE_S else Controls()

    def _run(self) -> None:
        c = self.core
        try:
            if getattr(c, "source", "idle") != "external":
                c.set_source("external")
            t0 = self._clock()
            while True:
                el = self._clock() - t0
                if el >= GYRO_STILL_S:
                    break
                au = getattr(c, "autonomy", None)
                if getattr(au, "fc_armed", False) or not getattr(c, "connected", False):
                    self.result = "Gyro calibration stopped: the drone armed or the link dropped."
                    return
                self.last_controls = self.gesture(el)
                c.set_external_controls(self.last_controls)
                self._sleep(0.02)
            self.result = "Gyro calibrated: the gyro offset was re-zeroed. Keep the drone still a moment longer."
        except Exception as e:                                  # noqa: BLE001
            self.result = f"Gyro calibration failed: {e}"
        finally:
            self.last_controls = Controls()
            try:
                c.set_external_controls(Controls())
                if getattr(self, "_prev_source", "idle") != "external":
                    c.set_source(self._prev_source)
            except Exception:                                   # noqa: BLE001
                pass
            self.running = False
