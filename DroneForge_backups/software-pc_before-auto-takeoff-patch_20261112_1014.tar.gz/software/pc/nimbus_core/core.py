"""NimbusCore: owns the serial link (Session), the controls source and the stale/arm/watchdog supervision, and publishes everything on the bus.
Clients (the Qt GCS, later recorder, autonomy, a ZMQ bridge) only subscribe to topics and call the command methods; none of them touches the port."""
from __future__ import annotations

import math
import time
from typing import Optional

import math as _m

from nimbus_pc.gamepad import GamepadInput
from nimbus_pc.sender import Controls
from nimbus_pc.session import Session
from nimbus_pc.watchdog import NAMES as WATCHDOG_NAMES

from . import topics as T
from . import settings as S
from .autonomy import HoverAutonomy
from .bus import TopicBus
from .radio_fc import RadioFcProbe
from .recorder import FlightRecorder
from .throttle_ramp import ThrottleRamp
from .simsession import SimSession
from .bench import BenchPlant
from nimbus_pc.sender import CRSF_MAX
from .safety import SafetyConfig, SafetyMonitor
from .director import FlightDirector
from .link_supervisor import LinkSupervisor
from .notifications import Notifications

SOURCES = ("idle", "sweep", "gamepad", "external")      # "external": an autonomy module (hover controller, mission) feeds set_external_controls()


class NimbusCore:
    def __init__(self, bus: Optional[TopicBus] = None) -> None:
        self.bus = bus or TopicBus()
        self.notifications = Notifications(self)       # before anything can call event()
        self.sess: Optional[Session] = None
        self.port = ""
        self.source = "idle"
        self.allow_arm = False
        self.watch_optrange = True
        self.gamepad_path = ""
        self.pad: Optional[GamepadInput] = None
        self.last_controls = Controls()
        self.external_controls = Controls()
        self._t0 = time.monotonic()
        self._prev = {"arm": False, "fs": False, "wd": 0, "pad": True, "latched": None}
        self.safety = SafetyMonitor(SafetyConfig())
        self.bus.subscribe(T.TELEMETRY, self._feed_safety)
        self.state_source = "live"
        self.bench: Optional[BenchPlant] = None
        self.probe: Optional[RadioFcProbe] = None
        self._fc_reader = None
        self.bench_scale = 0.4
        self.last_sent = Controls()
        self.autonomy = HoverAutonomy(self)
        self.ramp = ThrottleRamp(self)
        self.link = LinkSupervisor(self)
        self.director = FlightDirector(self)          # the GUI's only flight interface
        self.recorder = FlightRecorder(self)

    def _feed_safety(self, msg) -> None:
        name, d = msg
        now = time.monotonic()
        if name == "attitude":
            self.safety.feed_attitude(now, _m.degrees(d["pitch_rad"]), _m.degrees(d["roll_rad"]))
        elif name == "battery":
            self.safety.feed_battery(now, d["voltage_v"])
        elif name == "optrange":
            self.safety.feed_range(now, d["distance_m"])
        elif name == "link":
            self.safety.feed_link(now, d["up_lq"])

    # --- helpers -----------------------------------------------------------------------------
    def event(self, text: str) -> None:
        self.bus.publish(T.EVENT, text, cache=False)       # Notifications turns every event line into a notice

    def notify(self, text: str, level: str = "info", source: str = "") -> None:
        self.notifications.add(text, level, source)

    def _publish_source(self) -> None:
        self.bus.publish(T.SOURCE, {"source": self.source, "allow_arm": self.allow_arm})

    @property
    def connected(self) -> bool:
        return self.sess is not None

    # --- connection --------------------------------------------------------------------------
    def connect(self, port: str, hz: float = 100.0, log_path: Optional[str] = None, bench_fc_port: Optional[str] = None, fc=None) -> None:
        """bench_fc_port (or an injected `fc` reader) = BENCH MODE: props OFF, real FC + link, simulated sensors from the FC's motor outputs."""
        self.disconnect()
        self._t0 = time.monotonic()
        self._prev.update(arm=False, fs=False, wd=0, pad=True)
        bus = self.bus
        sess = Session(port, hz=hz, allow_arm=self.allow_arm, ping=True, watch_optrange=self.watch_optrange, log_path=log_path,
                       on_telemetry=lambda name, d: (None if (self.bench is not None and name in ("optrange", "attitude")) else bus.publish(T.TELEMETRY, (name, d), cache=False)),
                       on_frame=lambda f: bus.publish(T.FRAME_IN, f, cache=False))
        sess.link.on_write = lambda data: bus.publish(T.FRAME_OUT, data, cache=False)
        if bench_fc_port or fc is not None:
            if fc is None:
                from nimbus_pc.hover.hil import FcReader
                fc = FcReader(bench_fc_port)
            self._fc_reader = fc
            self.bench = BenchPlant(fc, scale=self.bench_scale, params=S.plant_params(self.autonomy.settings), on_telemetry=lambda n, d: bus.publish(T.TELEMETRY, (n, d), cache=False))
        sess.start()                                     # raises OSError if the port cannot be opened
        self.sess, self.port = sess, port
        if self.bench is not None:
            self.bench.start()
        else:                                            # live link: read the FC's motor outputs over the radio (read-only MSP, own thread, 2 Hz) for the log
            self.probe = RadioFcProbe(sess, period_s=0.5); self.probe.start(); self.recorder.probe = self.probe
        self.state_source = "bench" if self.bench is not None else "live"
        self.bus.publish(T.CONNECTION, {"connected": True, "port": port, "source": self.state_source})
        self.event(f"connected to {port}" + ("  [BENCH MODE: props OFF, sensors simulated from the FC's motor outputs, throttle x%.1f]" % self.bench_scale if self.bench is not None else ""))

    def connect_sim(self, params=None, seed: int = 1) -> None:
        """State source = Sim: the physics simulator instead of the radio link (no hardware)."""
        self.disconnect()
        self._t0 = time.monotonic()
        self._prev.update(arm=False, fs=False, wd=0, pad=True)
        bus = self.bus
        params = params or S.plant_params(self.autonomy.settings)           # the Sim plant has this drone's measured numbers
        sess = SimSession(params, seed, on_telemetry=lambda name, d: bus.publish(T.TELEMETRY, (name, d), cache=False),
                          on_frame=lambda f: bus.publish(T.FRAME_IN, f, cache=False))
        sess.link.on_write = lambda data: bus.publish(T.FRAME_OUT, data, cache=False)
        sess.sender.allow_arm = self.allow_arm
        sess.start()
        self.sess, self.port, self.state_source = sess, "SIM", "sim"
        self.bus.publish(T.CONNECTION, {"connected": True, "port": "SIM", "source": "sim"})
        self.event("connected to the SIMULATOR (state source = Sim)")

    def disconnect(self) -> None:
        if self.sess:
            self.sess.set_controls(Controls())
            self.autonomy.abort()
            self.recorder.probe = None
            if self.probe is not None:
                self.probe.stop(); self.probe = None
            if self.bench is not None:
                self.bench.stop(); self.bench = None
                try: self._fc_reader.close()
                except Exception: pass
                self._fc_reader = None
            try:
                self.sess.stop()
            finally:
                self.sess = None
                self.bus.publish(T.CONNECTION, {"connected": False, "port": self.port})
                self.event("disconnected")
        if self.pad:
            self.pad.close(); self.pad = None

    # --- commands ----------------------------------------------------------------------------
    def set_source(self, name: str, gamepad_path: str = "") -> None:
        assert name in SOURCES
        if self.pad:
            self.pad.close(); self.pad = None
        self.source = name
        if name == "gamepad":
            self.gamepad_path = gamepad_path or self.gamepad_path
            self.pad = GamepadInput(self.gamepad_path)
        self.event(f"controls source -> {name}")
        self._publish_source()

    def set_allow_arm(self, allow: bool) -> None:
        """Takes effect on the running sender too (allow_arm gates the arm channel in CrsfSender)."""
        self.allow_arm = allow
        if self.sess:
            self.sess.sender.allow_arm = allow
        self.event("arming ALLOWED (props off!)" if allow else "arming disabled")
        self._publish_source()

    def safe_now(self) -> None:
        """Big red button: arm channel low, throttle minimum, source idle, arming disallowed."""
        self.allow_arm = False
        self.source = "idle"
        if self.pad:
            self.pad.close(); self.pad = None
        if self.sess:
            self.sess.sender.allow_arm = False
            self.sess.set_controls(Controls())
        self.event("SAFE pressed: disarm + throttle min + source idle")
        self._publish_source()

    def set_external_controls(self, c: Controls) -> None:
        self.external_controls = c

    # --- control tick (~50 Hz, driven by the caller: a Qt timer now, the core's own loop later) ---
    def tick(self) -> None:
        self.link.update()
        self.director.housekeeping()
        if not self.sess:
            return
        t = time.monotonic() - self._t0
        if self.source == "gamepad" and self.pad:
            self.pad.poll()
            c = self.pad.controls() if (self.pad.connected and self.pad.ready) else Controls()
            if not self.pad.connected and self._prev["pad"]:
                self.event("gamepad LOST -> safe frames")
            self._prev["pad"] = self.pad.connected
        elif self.source == "external":
            if self.ramp.phase in ("arming", "ramping"):
                c = self.ramp.tick(time.monotonic())
            else:
                c = self.autonomy.controls(time.monotonic()) if self.autonomy.phase in ("arming", "armed", "flying", "fcflight") else self.external_controls
        elif self.source == "sweep":
            c = Controls(roll=0.5 * math.sin(2 * t), pitch=0.5 * math.sin(1.4 * t), yaw=0.5 * math.sin(t))
        else:
            c = Controls()
        # --- safety layer: tilt/inverted disarm overrides every source (a land request is for the active controller; pilots get the warning)
        req_arm = bool(c.arm and self.sess.sender.allow_arm)
        if not req_arm:
            self.safety.reset()
        turtle = c.aux3 > 1400                                          # CRSF raw; AUX3 high = flip-over (turtle) mode on this FC
        for ev in self.safety.check(time.monotonic(), armed=req_arm, turtle=turtle):
            self.event(f"SAFETY [{ev.level}] {ev.text}")
            self.bus.publish(T.SAFETY, dict(self.safety.status(), event=ev))
        if self.safety.disarm_latched:
            c = Controls()                                              # arm low, throttle minimum, sticks centred
            if self._prev["latched"] != self.safety.disarm_latched:
                self.event(f"SAFETY: arm forced LOW ({self.safety.disarm_latched}); flip the arm switch off to re-arm")
        self._prev["latched"] = self.safety.disarm_latched
        self.last_controls = c
        send = c
        if self.bench is not None:                                       # props OFF: slow motors, ACRO (no I-term wind-up on the still IMU)
            self.bench.set_controls(c)
            send = Controls(roll=c.roll, pitch=c.pitch, yaw=c.yaw, throttle=(c.throttle * self.bench_scale) if c.arm else 0.0, arm=c.arm,
                            aux2=CRSF_MAX, aux3=c.aux3)
        self.last_sent = send
        self.sess.set_controls(send)
        self.bus.publish(T.CONTROLS, c)
        arm = bool(c.arm and self.sess.sender.allow_arm)
        if arm != self._prev["arm"]:
            self.event("arm channel " + ("HIGH" if arm else "low")); self._prev["arm"] = arm
            self.bus.publish(T.ARM, {"channel_high": arm})
        fs = self.sess.sender.failsafe_active
        if fs != self._prev["fs"]:
            self.event("stale-input failsafe " + ("ON" if fs else "off")); self._prev["fs"] = fs
            self.bus.publish(T.FAILSAFE, {"active": fs})
        wd = self.sess.watchdog.state if self.sess.watchdog else 0
        if wd != self._prev["wd"]:
            self.event("sensor watchdog -> " + WATCHDOG_NAMES[wd]); self._prev["wd"] = wd
            self.bus.publish(T.WATCHDOG, {"state": WATCHDOG_NAMES[wd]})
