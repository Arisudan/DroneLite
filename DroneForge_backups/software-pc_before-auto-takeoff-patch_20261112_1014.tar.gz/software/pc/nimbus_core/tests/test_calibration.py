import math
import unittest
from types import SimpleNamespace

from nimbus_core.calibration import Calibrator, LEVEL_UNAVAILABLE, tilt_colour, GYRO_GESTURE_S


class FakeCore:
    def __init__(self, **kw):
        self.connected, self.state_source, self.source = True, "live", "idle"
        self.autonomy = SimpleNamespace(fc_armed=False, phase="idle")
        self.ramp = SimpleNamespace(phase="idle")
        self.state = SimpleNamespace(decoded={"attitude": {"pitch_rad": math.radians(0.3), "roll_rad": math.radians(-1.0)}})
        self.sent = []
        self.__dict__.update(kw)

    def set_source(self, s): self.source = s
    def set_external_controls(self, c): self.sent.append(c)


class TestCalibrator(unittest.TestCase):
    def test_level_status_and_colours(self):
        s = Calibrator(FakeCore()).level_status()
        self.assertAlmostEqual(s["pitch"], 0.3); self.assertAlmostEqual(s["roll"], -1.0); self.assertEqual(s["colour"], "amber")
        self.assertEqual((tilt_colour(0.2), tilt_colour(-1.6), tilt_colour(None)), ("green", "red", "grey"))

    def test_level_never_sends(self):
        c = FakeCore(); ok, msg = Calibrator(c).calibrate_level()
        self.assertFalse(ok); self.assertEqual(msg, LEVEL_UNAVAILABLE); self.assertEqual(c.sent, [])

    def test_refusals(self):
        for kw, word in ((dict(connected=False), "connect"), (dict(state_source="sim"), "simulator"),
                         (dict(autonomy=SimpleNamespace(fc_armed=True, phase="idle")), "disarm"),
                         (dict(autonomy=SimpleNamespace(fc_armed=False, phase="flying")), "Autonomy"),
                         (dict(source="gamepad"), "source")):
            c = FakeCore(**kw); ok, msg = Calibrator(c).calibrate_gyro()
            self.assertFalse(ok); self.assertIn(word.lower(), msg.lower()); self.assertEqual(c.sent, [])

    def test_gyro_gesture_timing_and_no_arm(self):
        c = FakeCore(); t = [0.0]
        def sleep(d): t[0] += d
        cal = Calibrator(c, clock=lambda: t[0], sleep=sleep)
        cal.running = True; cal._prev_source = "idle"; cal._run()
        self.assertFalse(cal.running); self.assertEqual(c.source, "idle"); self.assertIn("calibrated", cal.result)
        self.assertTrue(c.sent)
        for x in c.sent:
            self.assertFalse(x.arm); self.assertEqual(x.throttle, 0.0)
        g = [x for x in c.sent if x.pitch == -1.0 and x.yaw == -1.0]
        self.assertTrue(0.7 * GYRO_GESTURE_S / 0.02 < len(g) <= GYRO_GESTURE_S / 0.02 + 2)
        self.assertEqual(c.sent[-1].pitch, 0.0)
        self.assertEqual(cal.gesture(1.7).pitch, 0.0)

    def test_start_runs_thread(self):
        c = FakeCore(); cal = Calibrator(c, sleep=lambda d: None, clock=iter(i * 0.5 for i in range(100)).__next__)
        ok, _ = cal.calibrate_gyro(); self.assertTrue(ok); cal._thread.join(3); self.assertFalse(cal.running)


if __name__ == "__main__":
    unittest.main()
