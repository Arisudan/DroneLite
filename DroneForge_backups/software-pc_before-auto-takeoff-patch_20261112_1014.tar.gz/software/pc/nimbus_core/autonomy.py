"""Hover autonomy inside the core (Nimbus: AutonomyRequest Takeoff / Land, AutonomyStatus). Wraps nimbus_pc.hover.HoverController.

Flow: idle -> (takeoff) arming [arm HIGH at ZERO throttle until the FC reports armed; the real Betaflight refuses otherwise]
      -> flying [HoverController: takeoff, sign check, hover, land] -> idle.
The core calls controls() each tick while the control source is "external" and the phase is arming/flying. Telemetry (range/flow/attitude/battery)
comes from the topic bus, so it works the same on the live link and on the Sim state source. Safety land requests are honoured here."""
from __future__ import annotations

import math
import threading
import time
from typing import Optional

from nimbus_pc.hover.controller import HoverConfig, HoverController, HoverState
from nimbus_pc.hover.sim import Sample
from nimbus_pc.sender import Controls

from . import settings as S
from . import topics as T


def to_sample(name: str, d: dict, now: float) -> Optional[Sample]:
    if name == "optrange":
        return Sample(now, "optrange", {"distance_m": d["distance_m"], "flow_vx": d["velocity_forward"], "flow_vy": d["velocity_right"], "quality": d["flow_quality"]})
    if name == "attitude":
        return Sample(now, "attitude", {"pitch_deg": math.degrees(d["pitch_rad"]), "roll_deg": math.degrees(d["roll_rad"]), "yaw_deg": math.degrees(d["yaw_rad"])})
    if name == "kinematic" and d.get("valid"):
        att = d.get("yaw_rad", 0.0)
        return Sample(now, "fcxy", {"vx_mps": d["vx_mps"], "vy_mps": d["vy_mps"], "yaw_deg": math.degrees(att), "valid": True})
    if name == "battery":
        return Sample(now, "battery", {"voltage_v": d["voltage_v"]})
    return None


class HoverAutonomy:
    ARM_TIMEOUT_S = 8.0
    GYRO_CAL_S = 4.0                         # gyro-calibration gesture + stillness before the arm command
    COUNTDOWN_S = 3.0                        # 3-2-1 before the arm command on the real drone (Nimbus Start sequence: gyro cal -> countdown -> estimator reset -> arm)

    def __init__(self, core, cfg: Optional[HoverConfig] = None) -> None:
        self.core = core
        self.cfg = cfg or HoverConfig()
        self.settings = S.load()
        S.apply_to_config(self.settings, self.cfg)
        core.safety.cfg.max_height_m = self.settings.ceiling_m
        self.ctl = HoverController(self.cfg)
        self.flight_mode = "pos_hold"            # not saved: back to pos_hold when a flight ends
        self.phase = "idle"                      # idle | arming | armed | flying   ("armed" = FC armed at zero throttle, motors at idle, waiting for take-off)
        self._arm_only = False; self._t_armlost = None
        self.fc_mode = ""
        self.fc_flight = self.settings.flight_controller == "fc"   # (2026-11-06: OFF by default): the first FC take-off lifted off within 0.75 s and climbed violently because the hover reference it received was ~17 % too high (wrong FC voltage reading). Opt-in only, after the firmware fix and a tethered test.
        self._t_fc = None; self._fc_landing = False; self._fc_seen = False; self._fc_warned = False; self._est_reset = False
        self.fc_hold = self.settings.flight_controller == "fc"     # ask the FC to hold the height itself from lift-off on (FC firmware with flight/height_hold.c); the PC keeps computing its own throttle as the fallback
        self.gyro_cal_before_arm = True           # recalibrate the FC gyro right before every arming (stick gesture, disarmed)
        self.att_deg = None                      # (pitch, roll, time) the FC reports: at rest on the ground this is the "rest tilt"
        self.fc_hold_state = ""                  # "", "active", "fault" as reported by the FC in the flight-mode text (" HH" / " HF")
        self._t_hold_req = None
        self._hold_warned = False
        self.message = ""
        self._lock = threading.RLock()
        self._buf: list = []
        self._t_last: Optional[float] = None
        self._t_arm: Optional[float] = None
        core.bus.subscribe(T.TELEMETRY, self._on_telemetry)

    # --- inputs -------------------------------------------------------------------------------
    def _on_telemetry(self, msg) -> None:
        name, d = msg
        if name == "attitude":
            import math as _m
            self.att_deg = (_m.degrees(d["pitch_rad"]), _m.degrees(d["roll_rad"]), time.monotonic())
        if name == "flight_mode":
            self.fc_mode = d.get("mode", "")
            new = "active" if " HH" in self.fc_mode else ("takeoff" if " HT" in self.fc_mode else ("landing" if " HL" in self.fc_mode else ("fault" if " HF" in self.fc_mode else "")))
            if new != self.fc_hold_state:
                self.fc_hold_state = new
                if new == "takeoff":
                    self.core.event("FC TAKE-OFF: the FC is creeping the throttle up")
                elif new == "landing":
                    self.core.event("FC LANDING: the FC is descending")
                elif new == "active":
                    self.core.event("FC height hold ACTIVE: the FC controls the height now")
                elif new == "fault":
                    self.core.event("FC height hold LET GO (estimator/range problem or ceiling): the PC throttle is in control")
            return
        now = time.monotonic()
        s = to_sample(name, d, now)
        if s is None:
            return
        with self._lock:
            if self.phase == "flying":
                self._buf.append(s)
            else:
                self.ctl.observe(now, [s])            # keeps the telemetry-rate/battery judgement fresh for the preflight

    @property
    def fc_armed(self) -> bool:
        return bool(self.fc_mode) and not self.fc_mode.endswith("*")

    # --- commands -----------------------------------------------------------------------------
    def preflight(self, for_ramp: bool = False) -> tuple[bool, list]:
        """for_ramp=True skips only the 'hover throttle must be measured' rule (the ramp is what measures it)."""
        with self._lock:
            ok, why = self.ctl.preflight(time.monotonic())
        if not self.core.connected:
            ok, why = False, ["not connected"] + why
        if not self.core.allow_arm:
            ok, why = False, ["arming is not permitted (the flight director grants it)"] + why
        if self.core.safety.disarm_latched:
            ok, why = False, [f"safety disarm latched ({self.core.safety.disarm_latched})"] + why
        if not for_ramp and not self.settings.measured and not (self.core.state_source in ("sim", "bench")):
            ok, why = False, ["hover throttle is UNMEASURED: set the hover throttle and reference voltage from a real lift-off, then set Settings > Controller > Hover throttle status to Measured"] + why
        if self.core.source != "external":
            ok, why = False, [f"controls source is '{self.core.source}', not external"] + why
        return ok, why

    def set_settings(self, s: S.FlightSettings, persist: bool = True) -> list:
        """Validate, apply to the hover config and (optionally) save. Refused while a flight is running."""
        if self.phase not in ("idle", "armed"):
            return ["not while flying"]
        bad = s.validate()
        if bad:
            return bad
        self.settings = s
        self.fc_hold = self.fc_flight = s.flight_controller == "fc"
        S.apply_to_config(s, self.cfg)
        self.core.safety.cfg.max_height_m = s.ceiling_m
        old = self.ctl
        self.ctl = HoverController(self.cfg)
        for a in ("opt_times", "_raw_hist", "last_optrange", "batt_v", "ground", "pitch_deg", "roll_deg", "imu_az", "t_imu"):   # keep the live telemetry judgement: applying settings must not blind the preflight
            setattr(self.ctl, a, getattr(old, a))
        if persist:
            S.save(s)
        self.core.event(f"AUTONOMY settings: hover {s.hover_height:.2f} m, hover throttle {s.thr_hover0:.3f} ({'measured' if s.measured else 'UNMEASURED default'}), cap {s.thr_max:.2f}")
        return []

    def set_height(self, h: float) -> list:
        """Change the hold height NOW (not saved as the default). Idle/arming: used by the next takeoff. Flying: the drone glides to the new height."""
        from dataclasses import replace
        h = round(float(h), 3)
        with self._lock:
            new = replace(self.settings, hover_height=h)
            bad = new.validate()
            if bad:
                return bad
            if self.phase == "idle":
                return self.set_settings(new, persist=False)
            if self.phase == "flying" and not self.ctl.command_height(time.monotonic(), h):
                return ["not while landing / after a sensor loss"]
            self.settings = new
            self.cfg.hover_height = h
            self.cfg.ceiling = max(self.cfg.ceiling, h + 0.3)
            self.core.event(f"AUTONOMY hold height -> {h:.2f} m")
            return []

    def arm(self) -> bool:
        """ARM only: gyro calibration (disarmed), then the FC is armed at ZERO throttle (motors at idle) and stays armed until disarm() or take-off."""
        if self.phase != "idle":
            self.message = "already running"; return False
        why = []
        if not self.core.connected: why.append("not connected")
        if not self.core.allow_arm: why.append("arming is not permitted (the flight director grants it)")
        if self.core.safety.disarm_latched: why.append(f"safety disarm latched ({self.core.safety.disarm_latched})")
        if self.core.source != "external": why.append(f"controls source is '{self.core.source}', not external")
        if why:
            self.message = "arming refused: " + "; ".join(why); self.core.event("AUTONOMY " + self.message); return False
        with self._lock:
            self.phase, self._t_arm, self._t_last, self._buf, self._arm_only, self._t_armlost, self._est_reset = "arming", time.monotonic(), None, [], True, None, False
        self.message = "arming at zero throttle (motors will idle)"
        self.core.event("AUTONOMY ARM requested: arming at zero throttle")
        return True

    def _reset_estimator(self) -> None:
        """New hover controller (fresh filters) that keeps the live telemetry history, like set_settings does."""
        old = self.ctl
        self.ctl = HoverController(self.cfg)
        for a in ("opt_times", "_raw_hist", "last_optrange", "batt_v", "ground", "pitch_deg", "roll_deg", "imu_az", "t_imu"):
            setattr(self.ctl, a, getattr(old, a))

    def set_flight_mode(self, mode: str) -> bool:
        if mode not in HoverController.MODES:
            return False
        self.flight_mode = mode
        self.ctl.set_flight_mode(mode)
        return True

    def disarm(self) -> None:
        with self._lock:
            if self.phase in ("arming", "armed"):
                self.phase = "idle"; self._arm_only = False; self.message = "disarmed"
        self.core.event("AUTONOMY disarm requested")

    def takeoff(self) -> bool:
        ok, why = self.preflight()
        if self.phase not in ("idle", "armed"):
            self.message = "already running"; return False
        if not ok:
            self.message = "takeoff refused: " + "; ".join(why)
            self.core.event("AUTONOMY " + self.message)
            return False
        with self._lock:
            if self.phase == "armed" and self._fc_flies:
                self.phase, self._arm_only = "fcflight", False
                self._t_fc, self._fc_landing, self._fc_seen, self._fc_warned = time.monotonic(), False, False, False
                self.message = "FC take-off requested"; self.core.event("AUTONOMY FC take-off requested from the armed state: the FC creeps, lifts and holds")
                return True
            if self.phase == "armed":                                  # already armed: straight into the take-off
                if self.ctl.start(time.monotonic()):
                    self.phase, self._t_last, self._buf, self._arm_only = "flying", None, [], False
                    self.message = "flying"; self.core.event("AUTONOMY take-off from the armed state: hover controller started")
                    return True
                self.message = "takeoff refused: " + "; ".join(self.ctl.refused); self.core.event("AUTONOMY " + self.message)
                return False
            self.phase, self._t_arm, self._t_last, self._buf, self._arm_only, self._est_reset = "arming", time.monotonic(), None, [], False, False
        self.message = "arming at zero throttle"
        self.core.event("AUTONOMY takeoff requested: arming at zero throttle")
        return True

    def land(self, why: str = "operator") -> None:
        with self._lock:
            if self.phase == "arming":
                self.phase = "idle"; self.message = "cancelled before arming"
            elif self.phase == "fcflight":
                if not self._fc_landing:
                    self._fc_landing, self._t_fc = True, time.monotonic(); self.message = f"FC landing ({why})"
            elif self.phase == "flying":
                self.ctl.land(time.monotonic(), why)
                self.message = f"landing ({why})"
        self.core.event(f"AUTONOMY land requested ({why})")

    def abort(self) -> None:
        with self._lock:
            self.phase = "idle"; self._buf = []
            self.ctl = HoverController(self.cfg); self.flight_mode = "pos_hold"
        self.message = "aborted"

    # --- control tick (called by the core while source == external and phase in arming/flying) --
    def controls(self, now: float) -> Controls:
        with self._lock:
            if self.phase == "arming":
                real = self.core.state_source not in ("sim", "bench")
                gc = 0.0 if (not self.gyro_cal_before_arm or not real) else self.GYRO_CAL_S
                cd = self.COUNTDOWN_S if (real and not self.fc_armed) else 0.0           # no countdown if the FC is somehow already armed
                el = now - (self._t_arm or now)
                if el < gc:                                 # 1) re-zero the gyro offset right before arming (disarmed, throttle at minimum: the motors cannot spin)
                    self.message = f"Gyro calibration: keep the drone still ({gc - el:.0f} s)"
                    if el < 1.6 and not self.fc_armed:
                        return Controls(pitch=-1.0, yaw=-1.0)
                    return Controls()
                if el < gc + cd:                            # 2) countdown, still disarmed
                    self.message = f"Starting in {max(1, math.ceil(gc + cd - el))}..."
                    return Controls()
                if cd and not self._est_reset:              # 3) fresh estimator state right before the arm command (keeps the live telemetry judgement)
                    self._reset_estimator(); self._est_reset = True
                    self.core.event("AUTONOMY start sequence: gyro calibrated, countdown done, estimator reset: arming")
                gc += cd
                if self.fc_armed and self._arm_only:
                    self.phase, self.message, self._t_armlost = "armed", "ARMED: motors at idle, ready to take off", None
                    self.core.event("AUTONOMY ARMED: the FC is armed at zero throttle (motors idle)")
                    return Controls(arm=True)
                if self.fc_armed and self._fc_flies:
                    self.phase, self.message = "fcflight", "FC take-off requested"
                    self._t_fc, self._fc_landing, self._fc_seen, self._fc_warned = now, False, False, False
                    self.core.event("AUTONOMY armed: asking the FC to take off, hold and land by itself")
                    return Controls(arm=True)
                if self.fc_armed:
                    if self.ctl.start(now):
                        self.phase, self.message = "flying", "flying"
                        self.core.event("AUTONOMY armed: hover controller started")
                    else:
                        self.phase, self.message = "idle", "takeoff refused: " + "; ".join(self.ctl.refused)
                        self.core.event("AUTONOMY " + self.message)
                        return Controls()
                elif el - gc > self.ARM_TIMEOUT_S:
                    self.phase, self.message = "idle", "FC did not arm within 8 s (gyro calibration needs the drone STILL; check the arming blockers / Boxer SA / SC)"
                    self.core.event("AUTONOMY " + self.message)
                    return Controls()
                return Controls(arm=True)             # zero throttle
            if self.phase == "armed":
                if self.fc_armed:
                    self._t_armlost = None
                else:                                                 # the FC dropped out of armed (safety, failsafe, link): go back to idle
                    self._t_armlost = self._t_armlost if self._t_armlost is not None else now
                    if now - self._t_armlost > 1.5:
                        self.phase, self.message = "idle", "the FC is no longer armed"; self.core.event("AUTONOMY " + self.message)
                        return Controls()
                return Controls(arm=True)
            if self.phase == "fcflight":
                return self._fc_flight(now)
            if self.phase != "flying":
                return Controls()
            dt = 0.02 if self._t_last is None else min(max(now - self._t_last, 0.005), 0.1)
            self._t_last = now
            if self.core.safety.land_request and self.ctl.state in (HoverState.TAKEOFF, HoverState.SIGN_CHECK, HoverState.HOVER):
                self.ctl.land(now, "safety: " + self.core.safety.land_request)
                self.message = f"landing (safety: {self.core.safety.land_request})"
            samples, self._buf = self._buf, []
            self.ctl.set_flight_mode(self.flight_mode)
            cmd = self.ctl.update(now, samples, dt)
            if self.ctl.state == HoverState.DONE:
                self.core.event(f"AUTONOMY finished: {self.ctl.reason or 'landed'}")
                self.message = f"finished: {self.ctl.reason or 'landed'}"
                self.phase = "idle"
                self.ctl = HoverController(self.cfg); self.flight_mode = "pos_hold"
                return Controls()
            return self._with_fc_hold(now, cmd)

    FC_TAKEOFF_WAIT_S, FC_TAKEOFF_MAX_S, FC_LAND_MAX_S = 8.0, 40.0, 45.0   # WAIT_S only WARNS (Nimbus has no "FC silent -> disarm" rule; our 8 s disarm ended the 2026-11-06 tethered runs before the slow creep could lift); MAX_S ends the flight

    @property
    def _fc_flies(self) -> bool:
        """The FC flies take-off/landing only on the real drone: the simulator and the bench have no FC flight code, so they keep the PC controller."""
        return self.fc_flight and self.core.state_source not in ("sim", "bench")

    def _fc_flight(self, now: float) -> Controls:
        """The FC flies (take-off creep, hold, landing); the PC sends the target height / LAND on CH9 and the hover reference on CH10, zero throttle on the stick, and supervises."""
        from nimbus_pc.mapper import AUX5_LAND, height_to_aux5, throttle01_to_crsf
        self._buf = []
        st = self.fc_hold_state
        if st in ("takeoff", "active", "landing"):
            self._fc_seen = True
        elapsed = now - (self._t_fc or now)
        if self.core.safety.land_request and not self._fc_landing:
            self._fc_landing, self._t_fc = True, now; self.message = f"FC landing (safety: {self.core.safety.land_request})"
            self.core.event("AUTONOMY " + self.message)
        why = None
        if not self.fc_armed:
            why = "the FC is no longer armed"
        elif st == "fault":
            why = "the FC let go (take-off did not lift, tilt, estimator/range problem or ceiling): disarming"
        elif not self._fc_seen and not self._fc_landing and elapsed > self.FC_TAKEOFF_MAX_S:
            why = f"no sign of the FC take-off within {self.FC_TAKEOFF_MAX_S:.0f} s (the FC's take-off creep takes 15-30 s; firmware with FC take-off flashed? USER1 mode on AUX5? CH10 hover reference?)"
        elif not self._fc_seen and not self._fc_landing and elapsed > self.FC_TAKEOFF_WAIT_S and not self._fc_warned:
            self._fc_warned = True                                       # a warning, not a disarm: the creep is slow and telemetry may be missing
            self.message = "waiting for the FC take-off (no take-off flag from the FC yet; the creep takes 15-30 s). SAFE disarms."
            self.core.event("AUTONOMY " + self.message)
        elif self._fc_landing and self._fc_seen and st == "" and elapsed > 2.0:
            why = "landed"
        elif self._fc_landing and elapsed > self.FC_LAND_MAX_S:
            why = "landing took too long"
        elif not self._fc_landing and elapsed > self.FC_TAKEOFF_MAX_S and st == "takeoff":
            why = "take-off took too long"
        if why:
            self.phase, self.message = "idle", ("finished: landed" if why == "landed" else why)
            self.core.event("AUTONOMY FC flight ended: " + why)
            return Controls()
        try:
            hover_ref = self.ctl._thr_hover_now()
        except Exception:
            hover_ref = self.settings.thr_hover0
        aux5 = AUX5_LAND if self._fc_landing else height_to_aux5(self.cfg.hover_height)
        return Controls(arm=True, aux5=aux5, aux6=throttle01_to_crsf(hover_ref))

    def _with_fc_hold(self, now: float, cmd: Controls) -> Controls:
        """Once the PC controller is in HOVER and fc_hold is on, ask the FC to hold the height (CH9 carries switch + target). Everywhere else the switch is off."""
        from dataclasses import replace
        from nimbus_pc.mapper import height_to_aux5, throttle01_to_crsf
        tgt = self.ctl.fc_target_height() if self.fc_hold else None
        if tgt is None:
            self._t_hold_req = None; self._hold_warned = False
            return cmd
        if self._t_hold_req is None:
            self._t_hold_req = now
        elif now - self._t_hold_req > 4.0 and self.fc_hold_state == "" and not self._hold_warned:
            self._hold_warned = True
            self.core.event("FC height hold did not engage within 4 s (USER1 mode on AUX5 set? firmware with the hold?): the PC keeps the height")
        return replace(cmd, aux5=height_to_aux5(tgt), aux6=throttle01_to_crsf(self.ctl._thr_hover_now()))

    # --- what the flight director needs (no GUI knowledge) -----------------------------------
    @property
    def flight_controller(self) -> str:
        """'pc' or 'fc': who does take-off and hold (from the settings)."""
        return "fc" if self.fc_flight else "pc"

    @property
    def busy(self) -> bool:
        return self.phase != "idle"

    @property
    def in_flight(self) -> bool:
        return self.phase in ("flying", "fcflight")

    def height_m(self) -> Optional[float]:
        """Latest height estimate in metres (None before any range data)."""
        with self._lock:
            return self.ctl.z if self.ctl.z is not None else None

    def public_phase(self) -> str:
        """arming|armed|takeoff|climbing|holding|landing|landed|ready|fault (connection state is the director's business)."""
        with self._lock:
            if self.phase == "arming": return "arming"
            if self.phase == "armed": return "armed"
            if self.phase == "fcflight":
                if self._fc_landing: return "landing"
                return {"takeoff": "climbing", "active": "holding", "fault": "fault"}.get(self.fc_hold_state, "takeoff")
            if self.phase == "flying":
                st = self.ctl.state
                if st == HoverState.LAND: return "landing"
                if st == HoverState.HOVER: return "holding"
                if st == HoverState.SENSOR_LOSS: return "fault"
                return "takeoff" if (self.ctl.z or 0.0) < 0.10 else "climbing"
            return "landed" if self.message.startswith("finished") else "ready"

    # --- status for the UI --------------------------------------------------------------------
    def status(self) -> dict:
        with self._lock:
            now = time.monotonic()
            rate, gap = self.ctl.telemetry_health(now)
            return {"phase": self.phase, "state": self.ctl.state.value, "z_m": self.ctl.z, "range_hz": rate, "gap_s": gap,
                    "batt_v": self.ctl.batt_v, "reason": self.ctl.reason, "message": self.message,
                    "events": [str(e[1]) for e in self.ctl.events[-4:]], "fc_armed": self.fc_armed,
                    "fc_hold": self.fc_hold, "fc_hold_state": self.fc_hold_state, "fc_flight": self.fc_flight, "xy_source": self.ctl.xy_active,
                    "rest_tilt": (None if (self.att_deg is None or now - self.att_deg[2] > 3.0) else (self.att_deg[0], self.att_deg[1]))}
